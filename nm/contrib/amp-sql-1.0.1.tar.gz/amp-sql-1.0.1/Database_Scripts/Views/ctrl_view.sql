use amp_core;
CREATE OR REPLACE VIEW `vw_ctrl_definition` AS
    SELECT 
        obj_metadata.obj_metadata_id,
        obj_name,
        namespace_id,
        obj_formal_definition_id,
        use_desc
    FROM
        obj_metadata
            JOIN
        (SELECT 
            obj_formal_definition.obj_formal_definition_id,
                obj_metadata_id,
                use_desc,
                fp_spec_id
        FROM
            obj_formal_definition
        JOIN control_formal_definition ON control_formal_definition.obj_formal_definition_id = obj_formal_definition.obj_formal_definition_id) join2 ON join2.obj_metadata_id = obj_metadata.obj_metadata_id;


CREATE OR REPLACE VIEW `vw_ctrl_actual` AS
    SELECT 
        obj_metadata.obj_metadata_id,
        obj_name,
        namespace_id,
        obj_formal_definition_id,
        obj_actual_definition_id,
        ap_spec_id,
        use_desc
    FROM
        obj_metadata
            INNER JOIN
        (SELECT 
            obj_formal_definition.obj_formal_definition_id,
                obj_formal_definition.obj_metadata_id,
                view1.use_desc,
                obj_actual_definition_id,
                ap_spec_id
        FROM
            obj_formal_definition
        JOIN (SELECT 
            obj_actual_definition.obj_actual_definition_id,
            obj_actual_definition.obj_metadata_id,
                use_desc,
                ap_spec_id
        FROM
            amp_core.obj_actual_definition
        JOIN amp_core.control_actual_definition ON obj_actual_definition.obj_actual_definition_id = control_actual_definition.obj_actual_definition_id) AS view1 ON view1.obj_metadata_id = amp_core.obj_formal_definition.obj_metadata_id) join2 ON join2.obj_metadata_id = obj_metadata.obj_metadata_id;