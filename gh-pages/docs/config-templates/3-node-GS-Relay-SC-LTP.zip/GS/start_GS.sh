#!/bin/bash
#  FILE:  start_GS.sh
#  NODE:  GS [ipn:23]
#  DESC:  GS ION node on GS
#  DATE:  2023-11-22T11:22
host=`uname -n`
wdir=`pwd`
echo "Clearing old ion.log"
echo > ion.log
echo "Starting ION node ipn:23 on $host from $wdir"
ionadmin  GS.ionrc
sleep  1
ionsecadmin  GS.ionsecrc
sleep  1
bpadmin  GS.bpv7rc
sleep  1
# global contact graph
ionadmin  3node-rhel-graph.cg
echo "Startup of ION node ipn:23 on $host complete!"
echo "Starting bpecho on ipn:23.3."
bpecho   ipn:23.3 &
