#!/usr/bin/env python

# JHU/APL
# Description: Entrypoint into the CAmpPython program. Creates c and h files
# from JSON of different ADMs for use by protocols in DTN
#
# Modification History:
#   YYYY/MM/DD	    AUTHOR	   DESCRIPTION
#   ----------	  ------------	 ---------------------------------------------
#   2017-08-10	  David		 First implementation
#   2017-08-15	  Evana		 Clean up
#   2017-08-17	  David		 fixed mid converter
#   2017-08-23	  David		 Started convertion to command line tool
#   2017-11-01	  Sarah		 Documentation and minor fixups
##################################################################### 


import os
import argparse
import json
import re

from generators import create_gen_h
from generators import create_agent_c
from generators import create_mgr_c
from generators import create_impl_h
from generators import create_impl_c
from generators import create_mysql
from generators import create_ace
from generators.lib.common import campsettings
from generators.lib.common.camputil import Retriever

from util import name_registry as NR

#
# Sets up the format of command line arguments for CAmpPython,
# validates and returns arguments input on the command line
#
# Return value is a tuple (args, jsonfilename)
#
def handle_command_line_arguments():
	p = argparse.ArgumentParser(description = 'C code generator for Asychronous management protocols')

	# camp [-o PATH] [-s FILE] [-b B] [-n N] [-u] json
	
	p.add_argument('-o', '--out',         help="The ouput directory",                          default="./")
	p.add_argument('-c', '--scrapeC',     help="Previously generated c file to be scraped",    default=None)
	p.add_argument('-s', '--scrapeH',     help="Previously generated h file to be scraped",    default=None)
	
	p.add_argument('-n', '--nickname',    help="The integer nickname to use for this file",    default=-1, type=int)
	p.add_argument('-u', '--update-nn',   help="If this flag is set, nickname will be updated in name registry. Requires Root", action='store_true')
	
	p.add_argument('json',                help="JSON file to use for file generation")

	args = p.parse_args()	

	return args

#
# Makes the output directory if it doesn't already exist
# d_name is the path to the output directory
#
def set_up_outputdir(d_name):
	if(not os.path.isdir(d_name)):
		try:
			os.makedirs(d_name)
		except OSError, e:
			print "[ Error ] Failed to make output directory\n",
			print e
			raise

	
#
# Main function of CAmpPython
#
# Calls helper functions to initialize settings, read command line arguments,
# parse the input JSON file, and generate c and h files
#
def main():
	try:
		args = handle_command_line_arguments()

		# Initialize settings and output dir with the options returned 
		campsettings.init()

		set_up_outputdir(args.out)
		passed_nn = args.nickname

		print "Loading ", args.json, " ... "
		retriever = Retriever(args.json, True)

	except Exception, e:
		print "[ ERROR ] ", e
		return -1

	try:
		nn = NR.handle_nickname(retriever.get_ns(), passed_nn, args.update_nn)
	except Exception, e:
		print e
		return -1

	print "[ DONE ]"
	
	# Generate files for the JSON
	print "Generating files ..."
	create_ace.create(retriever, args.out, nn)
	create_impl_h.create(retriever, args.out, args.scrapeH)
	create_impl_c.create(retriever, args.out, args.scrapeC)
	create_mysql.create(retriever, args.out)
	create_gen_h.create(retriever, args.out, nn)
	create_mgr_c.create(retriever, args.out)
	create_agent_c.create(retriever, args.out)

	print "[ End of CAmpPython Execution ]\n"

	


if __name__ == '__main__':
	main()	
