/******************************************************************************
 **                           COPYRIGHT NOTICE
 **      (c) 2012 The Johns Hopkins University Applied Physics Laboratory
 **                         All rights reserved.
 ******************************************************************************/

/*****************************************************************************
 **
 ** \file ctrl.h
 **
 ** Description: This module contains the functions, structures, and other
 **              information used to capture both controls and macros.
 **
 **
 ** Assumptions:
 **
 ** Modification History:
 **  MM/DD/YY  AUTHOR         DESCRIPTION
 **  --------  ------------   ---------------------------------------------
 **  01/10/13  E. Birrane     Initial Implementation (JHU/APL)
 **  05/17/15  E. Birrane     Redesign around DTNMP v0.1 (Secure DTN - NASA: NNX14CS58P)
 *****************************************************************************/
#ifndef _CTRL_H
#define _CTRL_H

#include "../adm/adm.h"
#include "../utils/utils.h"
#include "../utils/nm_types.h"


/*
 * +--------------------------------------------------------------------------+
 * |							  CONSTANTS  								  +
 * +--------------------------------------------------------------------------+
 */

#define AMP_RULE_EXEC_ALWAYS (-1)

// Control parameters not filled out yet.
#define CONTROL_INIT     (0)

// Control initialized and ready.
#define CONTROL_ACTIVE   (1)

// Control initialized, but disabled.
#define CONTROL_INACTIVE (2)


#define CTRL_SUCCESS (0)
#define CTRL_FAILURE (1)

#define CTRL_MAX_CTRL_DEFS (100)

/*
 * +--------------------------------------------------------------------------+
 * |							  	MACROS  								  +
 * +--------------------------------------------------------------------------+
 */


/*
 * +--------------------------------------------------------------------------+
 * |							  DATA TYPES  								  +
 * +--------------------------------------------------------------------------+
 */



typedef tnvc_t* (*ctrldef_run_fn)(eid_t *def_mgr, tnvc_t params, int8_t *status);

/**
 * Describes an ADM Control in the system.
 *
 * This structure captures general information about a control, including
 * its name an associated MID.
 */
typedef struct
{
    ari_t *ari;			  /**> The MID identifying this def.        */

    uint8_t num_parms;    /**> # params needed to complete this MID.*/
    uint8_t adm_info;     /**> The ADM defining this CTRL. */

    ctrldef_run_fn run;  /**> Function implementing the control.   */

    db_desc_t desc;
} ctrldef_t;

typedef struct
{
	tnvc_t *parms;
	ctrldef_t *def; /**> Always a shallow pointer. Never delete. */
	db_desc_t desc;
} ctrl_t;


typedef struct
{
	ari_t *ari;     /* The name of the macro. */
	vector_t ctrls; /* Of type ctrl_t*/
	db_desc_t desc;
} mac_t;

/*
 * +--------------------------------------------------------------------------+
 * |						  FUNCTION PROTOTYPES  							  +
 * +--------------------------------------------------------------------------+
 */

void ctrl_cb_del_fn(void *item);
int  ctrl_cb_comp_fn(void *i1, void *i2);

ctrl_t *ctrl_copy_ptr(ctrl_t *src);
ctrl_t* ctrl_create(ari_t *ari);
ctrl_t* ctrl_deserialize_ptr(CborValue *it, int *success);
ctrl_t* ctrl_deserialize_raw(blob_t *data, int *success);
void    ctrl_release(ctrl_t *ctrl, int destroy);
blob_t* ctrl_serialize_wrapper(ctrl_t *ctrl);

int     ctrldef_create(ari_t *ari);
void    ctrldef_del_fn(void *key, void *value);

void    ctrldef_release(ctrldef_t *def, int destroy);



int     mac_append(mac_t *mac, ctrl_t *ctrl);

void    mac_cb_del_fn(void *item);
int     mac_cb_comp_fn(void *i1, void *i2);

void    mac_clear(mac_t *mac);

mac_t   mac_copy(mac_t *src, int *success);

mac_t*  mac_create(size_t num);

mac_t*  mac_deserialize_ptr(CborValue *it, int *success);
mac_t*  mac_deserialize_raw(blob_t *data, int *success);

ctrl_t* mac_get(mac_t* mac, uint8_t index);
uint8_t mac_get_count(mac_t* mac);

void    mac_release(mac_t *mac, int destroy);

CborError mac_serialize(CborEncoder *encoder, mac_t *mac);
blob_t*   mac_serialize_wrapper(mac_t *mac);



#endif // _CTRL_H
