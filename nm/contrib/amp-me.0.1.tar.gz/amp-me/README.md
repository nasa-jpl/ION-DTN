AMP.me - A Prototype NM User Interface & Utilities
=====================================
AMP.me is a collection of utilities and tools to assist NM Manager users and developers.  It includes both command-line utilities and a browser-based interface.  All tools are written entirely in Javascript, with shared library code that can be executed in any modern browser or with NodeJS (command-line).  Note: The browser interface includes several placeholders serving as a proof of concept for future development.

Key features curently available include:
- Conversion of AMP messages between a variety of supported types, including CBOR-encoded Hex strings, URIs, and visual representations.  
  - Browser: The 'amp.me' tab, http://localhost:3000#amp.me 
  - Command line 'amp.js $uri'
  - Sample inputs include "ari:/IANA:amp.agent/Ctrl.gen_rpts([ari:/IANA:bp.agent/Rptt.full_report()],[])" or "ari:/0xc11541050502252382871819410087182d410000"
- Command-line tools to insert and view messages in the MySQL database.  
  - UI wrappers will be added soon.
  - ./sql_msgs_insert.js --agent ipn:3.64 --msg "ari:/IANA:amp.agent/Ctrl.gen_rpts([ari:/IANA:bp.agent/Rptt.full_report()],[])"
  - ./sql_show.js --id 1
- Listing of known agents
  - The UI can query both the ION NM Manager's REST API (build ION with --enable-nmrest) and the MySQL database.
- ADM Listing.  This  page primarily provides reference links to the source JSON definition files and IETF reference pages.

This interface (when complete) will support operating with any combination of the following connectivity modes;
- Standalone. Simply open the htdocs/index.html file in your browser (a local server may be required) to access basic features for interpreting and building ARIs in various formats (TBD).
- Interface to AMP SQL Database.  This requires a server-side component from node.js which can be configured to access the available MySQL AMP database.  See NodeJS Quick Start below.
- Interface to ION NM Manager's REST API.  This requires the manager to be running.  It can be configured to be hosted directly from the embedded server in NM Manager, hosted externally, or through the NodeJS server.

This version can be considered a 'debug' view, which will display all available options at all times.  The final version will be configurable to hide features not currently used (ie: SQL vs REST API).  In some cases, where SQL and REST API options are both valid, the SQL interface would take precedence and the Manager REST interface will be hidden when not in the debug view.


NOTE: This UI makes no attempt at user authentication or security at this stage of development.  It is recommended to use an Apache (or similar) server as a proxy configured as appropriate to provide desired user authentication as needed.  

# Web UI Configuration
NodeJS is required to host if utilizing the MySQL interfaces. 

If not using the MySQL database, the htdocs folder may be served from any web server, such as Apache or ION Managers embedded server.  To do so, copy the lib/shared folder into htdocs/lib/shared -- the embedded NodeJS server automatically provides this as a virtual mapping.  To interface directly with the manager REST API in this configuration, you will need to modify the nmrest_base config in htdocs/index.js.  

To adjust the server port, or NM REST API url, start the server manually with the appropriate command-line arguments.  Fro available options see "node server.js --help"


## NM REST API URI
The default configuration points the browser to the NodeJS server, which will wrap requests to a Mgr at http://localhost:8089

To change the nm_rest API

# NodeJS Quick Start (UI)

- Install NodeJS (nodejs.org)
- cd into this directory
- npm init     # Installs all dependencies
- npm start   # Start the provided ExpressJS server at the configured port (will be shown in the terminal). 

# Command Line Utilities
- npm run generate-docs  - Run jsdocs to generate documentation.
- ./amp.js $URI  - amp.me command line utility for parsing URI formats. Initial version is limited to CBOR and CBOR-encoded objects.
- ./sql_msgs_insert.js  – Tool to insert messages into the database.  Run with “--help” for usage information.
- ./sql_show.js --type $type --id $id    - Tool to display records from the DB.  For example --type msgs --id 1 to show message group 1.
- npm test - Run Test scripts
