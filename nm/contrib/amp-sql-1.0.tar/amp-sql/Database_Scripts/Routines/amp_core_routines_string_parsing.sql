USE amp_core;

-- STORED PROCEDURE(S)


-- ==
-- function for string processing used by other sp
-- help make inserting large sets of data more user friendly 
-- ==
DROP PROCEDURE IF EXISTS SP__get_delimiter_position; 
DELIMITER //
CREATE PROCEDURE SP__get_delimiter_position(IN p_str varchar(255), p_delimiter varchar(255), p_start_position int unsigned, OUT r_found_position int unsigned)
BEGIN
	IF (p_str IS NOT NULL) && (p_start_position IS NOT NULL)THEN 
		BEGIN
			SET @length = CHAR_LENGTH(p_str); 
			SET @position_index = p_start_position; 
            SET @iterator_index = p_start_position; 
            SET @char_value = ''; 
            SET @delimiter_found = FALSE; 
            SET r_found_position = NULL; 
			WHILE (@position_index != @length) && (@delimiter_found != TRUE) DO 
				BEGIN
					SET @char_value = SUBSTRING(p_str, @iterator_index, 1);
                    IF @char_value LIKE p_delimiter THEN 
						SET @position_index = @iterator_index;
                        SET r_found_position = @position_index; 
                        SET @delimiter_found = TRUE; 
                    END IF; 
                    SET @iterator_index = @iterator_index + 1; 
				END;
			END WHILE; 
		END; 
    ELSE 
		BEGIN
			SET r_found_position = NULL; 
        END; 
    END IF; 
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS SP__null_string_check; 
DELIMITER //
CREATE PROCEDURE SP__null_string_check(INOUT p_string varchar(255))
BEGIN
	IF (p_string LIKE 'null') || (p_string LIKE 'NULL') || (p_string LIKE 'Null') THEN
		BEGIN
			SET p_string = NULL; 
        END; 
    END IF; 
END //
DELIMITER ;