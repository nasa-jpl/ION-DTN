# JHUAPL
# Description: Creates the c file for the implementation version of the adm

# Modification History:
#   YYYY-MM-DD   AUTHOR         DESCRIPTION
#   ----------   ------------   ---------------------------------------------
#   2017-08-10   David          First implementation
#   2017-11-15   Sarah          Made long strings more readable, added error checks
#   2017-12-28   David 			Metadata is in constants now
#   2017-12-19   Evana			Insert table functionality	
#   2018-06-27   David 			Changed mids to aris	
##################################################################### 

import os
import re
import errno

from lib import campch
from lib import campch_roundtrip as rt
from lib.common import camputil as cu
 
#
# Constructs and returns a filename for this generated file.
# Also creates the agent directory in the out directory if
# it doesn't exist
#
# outpath is the path to the output directory
# 
def initialize_file(name, outpath):
	# Make the agent dir, only want to allow the 'directory exists' error
	try:
		os.mkdir(outpath + "/agent/")
	except OSError as ose:
		if (not ose.errno == errno.EEXIST):
			print "[ Error ] Failed to create subdirectory in ", outpath
			print ose
			exit(-1)
	
	filename = outpath + "/agent/" + name + "_impl.c"
	return filename

#
# Writes the metadata functions to the file passed
# new_c is an open file descriptor to write to
# name is the value returned from get_adm_names()
# metadata is a list of metadata to include
#
def write_metadata_functions(new_c, name, metadata):
	new_c.write("\n/* Metadata Functions */\n\n")
			   
	metadata_funct_str = (
		"\n{0}"
		"\n{{"
		"\n\treturn tnv_from_str(\"{1}\");"
		"\n}}"
		"\n\n")

	for i in metadata:
		try:
			_,_,signature = campch.make_meta_function(name, i)
			new_c.write(metadata_funct_str.format(signature, i["value"]))
		except KeyError, e:
			print "[ Error ] Badly formatted metadata. Key not found:"
			print e
			raise

#
# Writes the constant functions to the file passed
# new_c is an open file descriptor to write to
# name is the value returned from get_adm_names()
# constants is a list of constants to include
#
def write_constant_functions(new_c, name, constants):
	new_c.write("\n/* Constant Functions */")

	const_function_str = (
		"\n{0}"
		"\n{{"
		"\n\treturn tnv_from_uvast({1});"
		"\n}}"
		"\n")

	for i in constants:
		try:
			basename,_,signature = campch.make_constant_function(name, i)
			new_c.write(const_function_str.format(signature, i["value"]))
		except KeyError, e:
			print "[ Error ] Badly formatted constant. Key not found:"
			print e
			raise		

#
# Helper function to correctly format and return a string for the column
# conditional in the table functions
#
def make_column_conditional(columns):
	if(columns == []):
		return "" 

	cout = "\tif("
	
	table_function_ari_str = "\n\t\t(tblt_add_col(table, {0}, \"{1}\") == ERROR){2}"
	
	items_left = len(columns) - 1

	for pair in columns:
		type_name = cu.make_amp_type_name(pair)
		if items_left == 0:
			cout = cout + table_function_ari_str.format(type_name, pair["name"], ")")
		else:
			cout = cout + table_function_ari_str.format(type_name, pair["name"], " ||")
		items_left -= 1
			
	return cout
			
#
# writes the table functions to the file passed
# new_c is an open file descriptor to write to
# name is the value returned from get_adm_names()
# table is a list of tables to include
#
def write_table_functions(new_c, name, table, custom):
 	new_c.write("\n/* Table Functions */\n\n")	
	
	table_function_begin_str = (
		"\n{0}"
		"\n{1}"
		"\n{{"
		"\n\ttbl_t *table = NULL;"
		"\n\tif((table = tbl_create(id)) == NULL)"
		"\n\t{{"
		"\n\t\treturn NULL;"
		"\n\t}}"
		"\n\n")

	conditional_body_str = (
		"\n\t{"
		"\n\t\treturn NULL;"
		"\n\t}"
		"\n\n")
	
	table_function_end_str = "\treturn table;\n}\n\n"
	
	for i in table:
		try:
			basename,_,signature = campch.make_table_function(name,  i)
			description          = campch.multiline_comment_format(i["description"])

			new_c.write(table_function_begin_str.format(description, signature))
#			new_c.write(make_column_conditional(i["columns"]))
#			new_c.write(conditional_body_str)
		except KeyError, e:
			print "[ Error ] Badly formatted table. Key not found:"
			print e
			raise
		
		# Add custom body tags and any scrapped lines found
		rt.write_custom_body(new_c, basename, custom.get(basename, []))

		# Close out the function
		new_c.write(table_function_end_str)

#
# Writes the edd functions to the file passed
# new_c is an open file descriptor to write to
# name is the value returned from get_adm_names()
# edds is a list of edds to include
# custom is a dictionary of custom function bodies to include, in the
# form {"function_name":["line1", "line2",...], ...}
#
def write_edd_functions(new_c, name, edds, custom):
	new_c.write("\n/* Collect Functions */")

	edd_function_begin_str = (
		"\n{0}"
		"\n{1}"
		"\n{{"
		"\n\ttnv_t *result = NULL;"
		"\n")
	edd_function_end_str = "\treturn result;\n}\n\n"

	for i in edds:
		try:
			basename,_,signature = campch.make_collect_function(name, i)
			description          = campch.multiline_comment_format(i["description"])

			new_c.write(edd_function_begin_str.format(description, signature))
		except KeyError, e:
			print "[ Error ] Badly formatted edd. Key not found:"
			print e
			raise
		
		# Add custom body tags and any scrapped lines found
		rt.write_custom_body(new_c, basename, custom.get(basename, []))

		# Close out the function
		new_c.write(edd_function_end_str)

#
# Writes the control functions to the file passed
# new_c is an open file descriptor to write to
# name is the value returned from get_adm_names
# controls is a list of controls to include
# custom is a dictionary of custom function bodies to include, in the
# form {"function_name":["line1", "line2",...], ...}
#
def write_control_functions(new_c, name, controls, custom):
	new_c.write("\n\n/* Control Functions */\n")
	
	ctrl_function_begin_str = (
		"\n{0}"
		"\n{1}"
		"\n{{"
		"\n\ttnv_t *result = NULL;"
		"\n\t*status = CTRL_FAILURE;"
		"\n")
	ctrl_function_end_str = "\treturn result;\n}\n\n"
	
	for i in controls:
		try:
			basename,_,signature = campch.make_control_function(name, i)
			description          = campch.multiline_comment_format(i["description"])
			new_c.write(ctrl_function_begin_str.format(description, signature))
		except KeyError, e:
			print "[ Error ] Badly formatted control. Key not found:"
			print e
			raise

		rt.write_custom_body(new_c, basename, custom.get(basename, []))

		new_c.write(ctrl_function_end_str)

#
# Writes the operator functions to the file passed
# new_c is an open file descriptor to write to
# name is the value returned from get_adm_names
# operators is a list of operators to include
# custom is a dictionary of custom function bodies to include, in the
# form {"function_name":["line1", "line2",...], ...}
#
def write_operator_functions(new_c, name, operators, custom):
	new_c.write("\n\n/* OP Functions */\n")

	op_function_begin_str = (
		"\n{0}"
		"\n{1}"
		"\n{{"
		"\n\ttnv_t *result = NULL;"
		"\n")
	op_function_end_str = "\treturn result;\n}\n\n"
	
	for i in operators:
		try: 
			basename,_,signature = campch.make_operator_function(name, i)
			description          = campch.multiline_comment_format(i["description"])
			new_c.write(op_function_begin_str.format(description, signature))
		except KeyError, e:
			print "[ Error ] Badly formatted operator. Key not found:"
			print e
			raise
		
		rt.write_custom_body(new_c, basename, custom.get(basename, []))

		new_c.write(op_function_end_str)

#
# function for writting the setup function and 
# custom body if present 
#
# body: the scraped function bodies
#
def write_setup(new_c, name, body):
	new_c.write("void {}_setup()\n{{\n\n".format(name))

	rt.write_custom_body(new_c, "setup", body.get("setup", []))

	new_c.write("}\n\n")

#
# function for writting the cleanup function and 
# custom body if present 
#
# body: the scraped function bodies
#
def write_cleanup(new_c, name, body):
	new_c.write("void {}_cleanup()\n{{\n\n".format(name))
	
	rt.write_custom_body(new_c, "cleanup", body.get("cleanup", []))

	new_c.write("}\n\n")

#
# Main function of this file, which calls helper functions to
# orchestrate the creation of the generated file
#
# data: the dictionary made from a parsed JSON file
# outpath: the output directory
# scrape_file: file name of the file to be scraped for roundtripping
#
def create(data, out, scrape_file):
	# Scrape the previous file if included
	includes = ["/*             TODO              */\n"]
	custom_func = ["/*             TODO              */\n"]
	func_bods = {}
	if scrape_file is not None:
		print "Scraping ", scrape_file, " ... ",
		includes, custom_func, func_bods = rt.scrape(scrape_file)
		print "\t[ DONE ]"
		
		# Sanity Check. If scraping was requested and returned nothing, let the user know
		if (len(includes) == 0 and len(custom_func) == 0 and len(func_bods) == 0):
			print "\t[ Warning ] No custom input found to scrape in ", scrape_file	

	try:
		name, ns = cu.get_adm_names(data)
		filename = initialize_file(name, out)
		new_c = open(filename,"w")
	except KeyError, e:
		print "[ Error ] JSON does not include valid metadata"
		print e
		return
	except IOError, e:
		print "[ Error ] Failed to open ", filename, " for writing."
		print e
		return		


			
	# Create the new file
	print "Working on ", filename,
	campch.write_c_file_header(new_c, filename)

	# Custom includes tag
	rt.write_custom_includes(new_c, includes)
	new_c.write(campch.make_includes(["../shared/adm/adm.h",
					  "{}_impl.h".format(name)]))
	
	# Add any custom functions scraped
	rt.write_custom_functions(new_c, custom_func)
	
	write_setup(new_c, ns, func_bods)
	write_cleanup(new_c, ns, func_bods)

	try:
		write_metadata_functions(new_c, ns, cu.get_metadata(data))
		write_constant_functions(new_c, ns, cu.get_constants(data))
		write_table_functions(   new_c, ns, cu.get_tables(data),    func_bods)
		write_edd_functions(     new_c, ns, cu.get_edds(data),      func_bods)
		write_control_functions( new_c, ns, cu.get_controls(data),  func_bods)	
		write_operator_functions(new_c, ns, cu.get_operators(data), func_bods)
	except KeyError, e:
		return
	finally:
		new_c.close()

	print "\t[ DONE ]"
