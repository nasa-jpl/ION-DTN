/******************************************************************************
 **                           COPYRIGHT NOTICE
 **      (c) 2012 The Johns Hopkins University Applied Physics Laboratory
 **                         All rights reserved.
 ******************************************************************************/

/*****************************************************************************
 **
 ** \file msg_admin.c
 **
 ** Description:
 **
 ** Notes:
 **
 ** Assumptions:
 **
 **
 ** Modification History:
 **  MM/DD/YY  AUTHOR         DESCRIPTION
 **  --------  ------------   ---------------------------------------------
 **  10/21/12  E. Birrane     Initial Implementation (JHU/APL)
 **  08/31/18  E. Birrane     Cleanup. Match latest Spec. (JHU/APL)
 *****************************************************************************/

#include "platform.h"
#include "ion.h"

#include "../utils/utils.h"
#include "../utils/nm_types.h"
#include "../msg/msg_admin.h"


/**
 * \brief serializes a register agent message into a buffer.
 *
 * \author Ed Birrane
 *
 * \note The returned message must be de-allocated from the memory pool.
 *
 * \return NULL - Failure
 *         !NULL - The serialized message.
 *
 * \param[in]  msg  The message to serialize.
 * \param[out] len  The length of the serialized message.
 */
uint8_t *msg_serialize_reg_agent(adm_reg_agent_t *msg, uint32_t *len)
{
	Sdnv id;

	uint8_t *result = NULL;
	uint8_t *cursor = NULL;

	AMP_DEBUG_ENTRY("msg_serialize_reg_agent","(0x%x, 0x%x)",
			          (unsigned long)msg, (unsigned long) len);

	/* Step 0: Sanity Checks. */
	if((msg == NULL) || (len == NULL))
	{
		AMP_DEBUG_ERR("msg_serialize_reg_agent","Bad Args",NULL);
		AMP_DEBUG_EXIT("msg_serialize_reg_agent","->NULL",NULL);
		return NULL;
	}

	/*
	 * STEP 1: Figure out the size of the entire message. That includes the
	 *         length of the header, acl list, SDNV holding length, and data.
	 */
	int id_len = strlen(msg->agent_id.name);
	encodeSdnv(&id,id_len);
	*len = id.length + id_len;

	/* STEP 4: Allocate the serialized message. */
	if((result = (uint8_t*)STAKE(*len)) == NULL)
	{
		AMP_DEBUG_ERR("msg_serialize_reg_agent","Can't alloc %d bytes", *len);
		*len = 0;

		AMP_DEBUG_EXIT("msg_serialize_reg_agent","->NULL",NULL);
		return NULL;
	}

	/* Step 5: Populate the serialized message. */
	cursor = result;

	memcpy(cursor, id.text, id.length);
	cursor += id.length;

	memcpy(cursor, msg->agent_id.name, id_len);
	cursor += id_len;

	/* Step 6: Last sanity check. */
	if((cursor - result) != *len)
	{
		AMP_DEBUG_ERR("msg_serialize_reg_agent","Wrote %d bytes but allcated %d",
				(unsigned long) (cursor - result), *len);
		*len = 0;
		SRELEASE(result);

		AMP_DEBUG_EXIT("msg_serialize_reg_agent","->NULL",NULL);
		return NULL;
	}

	AMP_DEBUG_EXIT("msg_serialize_reg_agent","->0x%x",(unsigned long)result);
	return result;
}




/******************************************************************************
 *
 * \par Function Name: msg_create_reg_agent
 *
 * \par Convenience function to build Register Agent message.
 *
 * \retval NULL - Failure
 * 		   !NULL - Created message.
 *
 * \param[in]  eid   THe identifier of the Agent
 *
 * \par Notes:
 *		1. - We shallow copy information into the message. Do not release
 *		     anything provided as an argument to this function.
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  01/17/13  E. Birrane     Initial implementation (JHU/APL)
 *  06/30/16  E. Birrane     Doc Update. (Secure DTN - NASA: NNX14CS58P)
 *****************************************************************************/

adm_reg_agent_t *msg_create_reg_agent(eid_t eid)
{
	adm_reg_agent_t *result = NULL;

	AMP_DEBUG_ENTRY("msg_create_reg_agent","(%s)", eid.name);

	/* Step 1: Allocate the message. */
	if((result = (adm_reg_agent_t*) STAKE(sizeof(adm_reg_agent_t))) == NULL)
	{
		AMP_DEBUG_ERR("msg_create_reg_agent","Can't alloc %d bytes.",
				        sizeof(adm_reg_agent_t));
		AMP_DEBUG_EXIT("msg_create_reg_agent","->NULL",NULL);
		return NULL;
	}

	/* Step 2: Populate the message. */
	result->agent_id = eid;

	AMP_DEBUG_EXIT("msg_create_reg_agent","->0x%x",result);
	return result;
}



/******************************************************************************
 *
 * \par Function Name: msg_release_reg_agent
 *
 * \par Release Register Agent message.
 *
 * \param[in,out] msg  The message being released.
 *
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  01/17/13  E. Birrane     Initial implementation (JHU/APL)
 *  06/30/16  E. Birrane     Doc Update. (Secure DTN - NASA: NNX14CS58P)
 *****************************************************************************/

void msg_release_reg_agent(adm_reg_agent_t *msg)
{
	AMP_DEBUG_ENTRY("msg_release_reg_agent","(0x%x)",
			          (unsigned long) msg);

	if(msg != NULL)
	{
		SRELEASE(msg);
	}

	AMP_DEBUG_EXIT("msg_release_reg_agent","->.",NULL);
}



/* Deserialize functions. */

/**
 * \brief Creates a register agent message from a buffer.
 *
 * \author Ed Birrane
 *
 * \note
 *   - On failure (NULL return) we do NOT de-allocate the passed-in header.
 *
 * \return NULL - failure
 *         !NULL - message.
 *
 * \param[in]  cursor      The buffer holding the message.
 * \param[in]  size        The remaining buffer size.
 * \param[out] bytes_used  Bytes consumed in the deserialization.
 */
adm_reg_agent_t *msg_deserialize_reg_agent(uint8_t *cursor,
		                                   uint32_t size,
		                                   uint32_t *bytes_used)
{
	adm_reg_agent_t *result = NULL;

	AMP_DEBUG_ENTRY("msg_deserialize_reg_agent","(0x%x, %d, 0x%x)",
			          (unsigned long)cursor, size, (unsigned long) bytes_used);

	/* Step 0: Sanity Checks. */
	if((cursor == NULL) || (bytes_used == 0))
	{
		AMP_DEBUG_ERR("msg_deserialize_reg_agent","Bad Args.",NULL);
		AMP_DEBUG_EXIT("msg_deserialize_reg_agent","->NULL",NULL);
		return NULL;
	}

	/* Step 1: Allocate the new message structure. */
	if((result = (adm_reg_agent_t*)STAKE(sizeof(adm_reg_agent_t))) == NULL)
	{
		AMP_DEBUG_ERR("msg_deserialize_reg_agent","Can't Alloc %d Bytes.",
				        sizeof(adm_reg_agent_t));
		*bytes_used = 0;
		AMP_DEBUG_EXIT("msg_deserialize_reg_agent","->NULL",NULL);
		return NULL;
	}
	else
	{
		memset(result,0,sizeof(adm_reg_agent_t));
	}

	/* Step 2: Deserialize the message. */

	/* Grab and check the size, as an SDNV */
	int sdnv_len = 0;
	uvast sdnv_tmp = 0;

	sdnv_len = decodeSdnv(&(sdnv_tmp), cursor);
	if(sdnv_len > AMP_MAX_EID_LEN)
	{
		AMP_DEBUG_ERR("msg_deserialize_reg_agent", "EID size %d > max %d.",
				        sdnv_tmp, AMP_MAX_EID_LEN);

		msg_release_reg_agent(result);
		*bytes_used = 0;

		AMP_DEBUG_EXIT("msg_deserialize_reg_agent","->NULL",NULL);
		return NULL;
	}
	else
	{
		cursor += sdnv_len;
		size -= sdnv_len;
		*bytes_used += sdnv_len;
	}

	// Copy EID.
	memcpy(result->agent_id.name,cursor,sdnv_tmp);
	cursor += sdnv_tmp;
	size -= sdnv_tmp;
	*bytes_used += sdnv_tmp;

	AMP_DEBUG_EXIT("msg_deserialize_reg_agent","->0x%x",(unsigned long)result);
	return result;
}



