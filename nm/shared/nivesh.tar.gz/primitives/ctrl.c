/******************************************************************************
 **                           COPYRIGHT NOTICE
 **      (c) 2012 The Johns Hopkins University Applied Physics Laboratory
 **                         All rights reserved.
 ******************************************************************************/

/*****************************************************************************
 **
 ** \file ctrl.c
 **
 ** Description: This module contains the functions, structures, and other
 **              information used to capture both control objects and
 **              macro objects.
 **
 **
 ** Assumptions:
 **
 ** Modification History:
 **  MM/DD/YY  AUTHOR         DESCRIPTION
 **  --------  ------------   ---------------------------------------------
 **  01/10/13  E. Birrane     Initial Implementation (JHU/APL)
 **  05/17/15  E. Birrane     Redesign around DTNMP v0.1 (Secure DTN - NASA: NNX14CS58P)
 **  09/01/18  E. Birrane     Updated to encoding and data structures (JHU/APL)
 *****************************************************************************/

#include "ctrl.h"

#include "../primitives/ari.h"


void ctrl_cb_del_fn(void *item)
{
	ctrl_t *ctrl = (ctrl_t *)item;

	CHKVOID(ctrl);

	ctrl_release(ctrl, 1);
}

int  ctrl_cb_comp_fn(void *i1, void *i2)
{
	ctrl_t *c1 = (ctrl_t *)i1;
	ctrl_t *c2 = (ctrl_t *)i2;
	int result = 0;

	CHKUSR(c1, -1);
	CHKUSR(c2, -1);

	result = ari_compare(c1->def->ari, c2->def->ari);

	/*
	 * If ARIs mismatch, or we are comparing liters, or we have no
	 * parameters then the ARI compare is enough.
	 */
	if((result != 0) ||
	   (c1->def->ari->type == AMP_TYPE_LIT) ||
	   (ARI_GET_FLAG_PARM(c1->def->ari->as_reg.flags) == 0))
	{
		return result;
	}

	/* Otherwise, ARIs match but need to check parameters. */
	return tnvc_compare(c1->parms, c2->parms);;
}



ctrl_t *ctrl_copy_ptr(ctrl_t *src)
{
	ctrl_t *result = NULL;

	CHKNULL(src);

	if((result = STAKE(sizeof(ctrl_t))) == NULL)
	{
		return NULL;
	}

	result->def = src->def;
	result->parms = tnvc_copy(src->parms);
	return result;
}


/******************************************************************************
 *
 * \par Function Name: ctrl_create
 *
 * \par Constructs a control instance given a MID and information about the
 *      execution of the control.
 *
 * \retval NULL - Error in creating the control.
 *        !NULL - The control instance
 *
 * \param[in] time      The timestamp to be associated with this control.
 * \param[in] id        The MID defining this control instance.
 * \param[in] sender    Control requester.
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  01/10/13  E. Birrane     Initial implementation. (JHU/APL)
 *  05/17/15  E. Birrane     Moved to ctrl.c, updated to DTNMP V0.1 (Secure DTN - NASA: NNX14CS58P)
 *  09/20/18  E. Birrane     Updated to latest AMP spec. Optimizations. (JHU/APL)
 *****************************************************************************/

ctrl_t *ctrl_create(ari_t *ari)
{
	ctrl_t *result = NULL;

	if((result = STAKE(sizeof(ctrl_t))) == NULL)
	{
		AMP_DEBUG_ERR("ctrl_create","Wrong ARI type %d.", ARI_GET_FLAG_TYPE(ari->as_reg.flags));
		return NULL;
	}

	if(ari == NULL)
	{
		return result;
	}

	/* Step 0: Sanity checks */
	if(ARI_GET_FLAG_TYPE(ari->as_reg.flags) != AMP_TYPE_CTRL)
	{
		AMP_DEBUG_ERR("ctrl_create","Wrong ARI type %d.", ARI_GET_FLAG_TYPE(ari->as_reg.flags));
		return NULL;
	}


	/* Step 1: Grab the basic information for this control. */
	if((result->def = VDB_FINDKEY_CTRLDEF(ari)) == NULL)
	{
		AMP_DEBUG_ERR("ctrl_create","Can't find base ARI.", NULL);
		SRELEASE(result);
		return NULL;
	}

    /* Store any parameters needed for this control. */
    if(ARI_GET_FLAG_TYPE(ari->as_reg.flags) != AMP_TYPE_CTRL)
    {
    	result->parms = tnvc_copy(&(ari->as_reg.parms));
    }
    else
    {
    	result->parms = NULL;
    }

	AMP_DEBUG_EXIT("ctrl_create","->"ADDR_FIELDSPEC".",(uaddr)result);
	return result;
}


ctrl_t*    ctrl_deserialize_ptr(CborValue *it, int *success)
{
	ctrl_t *result = NULL;
	ari_t *ari = ari_deserialize_ptr(it, success);

	CHKNULL(ari);

	result = ctrl_create(ari);
	ari_release(ari, 1);
	return result;
}

ctrl_t* ctrl_deserialize_raw(blob_t *data, int *success)
{
	CborParser parser;
	CborValue it;

	CHKNULL(success);
	*success = AMP_FAIL;
	CHKNULL(data);

	if(cbor_parser_init(data->value, data->length, 0, &parser, &it) != CborNoError)
	{
		return NULL;
	}

	return ctrl_deserialize_ptr(&it, success);
}

/*
 * Do not release the ctrldef. That is a shallow pointer.
 */
void ctrl_release(ctrl_t *ctrl, int destroy)
{
	CHKVOID(ctrl);

	tnvc_release(ctrl->parms, 1);

	if(destroy)
	{
		SRELEASE(ctrl);
	}
}


blob_t*   ctrl_serialize_wrapper(ctrl_t *ctrl)
{
	blob_t *result = NULL;
	ari_t *tmp_ari = NULL;

	CHKNULL(ctrl);

	tmp_ari = ari_copy_ptr(*(ctrl->def->ari));
	CHKNULL(tmp_ari);

	if(ari_add_parms(tmp_ari, ctrl->parms) == AMP_OK)
	{
		result = ari_serialize_wrapper(tmp_ari);
	}

	ari_release(tmp_ari, 1);
	return result;

}



ctrldef_t *ctrldef_create(ari_t *ari, uint8_t num, uint8_t adm, ctrldef_run_fn run)
{
	ctrldef_t *result = NULL;

	CHKNULL(ari);
	CHKNULL(run);

	if((result = STAKE(sizeof(ctrldef_t))) == NULL)
	{
		return NULL;
	}

	result->ari = ari_copy_ptr(*ari);
	result->num_parms = num;
	result->adm_info = adm;
	result->run =run;

	return result;
}

void ctrldef_del_fn(void *key, void *value)
{
	ctrldef_t *def = (ctrldef_t*)value;
	CHKVOID(def);

	ctrldef_release(def, 1);
}

void    ctrldef_release(ctrldef_t *def, int destroy)
{
	CHKVOID(def);

	ari_release(def->ari, 1);
	if(destroy)
	{
		SRELEASE(def);
	}
}


/* shallow copies ctrl */

int mac_append(mac_t *mac, ctrl_t *ctrl)
{
	CHKUSR(mac, AMP_FAIL);
	CHKUSR(ctrl, AMP_FAIL);

	return vec_push(mac->ctrls, ctrl, NULL);
}

void    mac_cb_del_fn(void *item)
{
	mac_release((mac_t*)item, 1);
}

int     mac_cb_comp_fn(void *i1, void *i2)
{
	mac_t *m1 = (mac_t *)i1;
	mac_t *m2 = (mac_t *)i2;
	CHKUSR(m1, -1);
	CHKUSR(m2, -1);
	return ari_cb_comp_fn(m1->ari, m2->ari);
}


void    mac_clear(mac_t *mac)
{
	CHKVOID(mac);
	vec_clear(mac->ctrls);
}

mac_t mac_copy(mac_t *src, int *success)
{
	mac_t result;

	result.ari = ari_copy_ptr(src->ari);
	result.ctrls = vec_copy(&(src->ctrls), success);
	if(success != VEC_OK)
	{
		ari_release(result.ari, 1);
		*success = AMP_FAIL;
	}
	else
	{
		*success = AMP_OK;
	}

	return result;
}

mac_t*  mac_create(size_t num, ari_t *ari)
{
	mac_t *result = NULL;
	int success;

	if((result = STAKE(sizeof(mac_t))) == NULL)
	{
		return NULL;
	}
	result->ari = ari_copy_ptr(*ari);
	result->ctrls = vec_create(num, ctrl_cb_del_fn, ctrl_cb_comp_fn, VEC_FLAG_AS_STACK, success);

	if(success != AMP_OK)
	{
		mac_release(result, 1);
		result = NULL;
	}

	return result;
}


mac_t*  mac_deserialize_ptr(CborValue *it, int *success)
{
	mac_t *result = NULL;
	ari_t *new_ari = NULL;
	int i;

	CborError err;
	CborValue array_it;
	size_t array_len = 0;


	AMP_DEBUG_ENTRY("mac_deserialize_ptr","(0x"ADDR_FIELDSPEC",0x"ADDR_FIELDSPEC")", (uaddr) it, (uaddr) success);

	*success = AMP_OK;

	if(((err = cbor_value_is_array(it)) != CborNoError) ||
	   ((err = cbor_value_get_array_length(it, &array_len)) != CborNoError) ||
	   (array_len <= 1))
	{
		AMP_DEBUG_ERR("mac_deserialize_ptr","CBOR Array Error %d with length %ld", err, array_len);
		*success = AMP_FAIL;
		return NULL;
	}

	if((err = cbor_value_enter_container(it, &array_it)) != CborNoError)
	{
		AMP_DEBUG_ERR("mac_deserialize_ptr","Unable to enter array. Error %d.", err);
		*success = AMP_FAIL;
		return NULL;
	}

	if((new_ari = ari_deserialize_ptr(it, success)) == NULL)
	{
		AMP_DEBUG_ERR("mac_deserialize_ptr","Unable to get Macro ARI.", NULL);
		*success = AMP_FAIL;
		return NULL;
	}


	if((result = mac_create(array_len, new_ari)) == NULL)
	{
		AMP_DEBUG_ERR("mac_deserialize_ptr","Unable to create mac with %d ctrls.", array_len);
		cbor_value_leave_container(it, &array_it);
		*success = AMP_FAIL;
		return NULL;
	}

	for(i = 0; i < array_len; i++)
	{
		ctrl_t* ctrl = ctrl_deserialize_ptr(&array_it, &success);
		if((success = mac_append(result, ctrl)) != AMP_OK)
		{
			AMP_DEBUG_ERR("mac_deserialize_ptr","Unable to create mac with %d ctrls.", array_len);
			cbor_value_leave_container(it, &array_it);
			*success = AMP_FAIL;
			mac_release(result, 1);
			return NULL;
		}
	}

	cbor_value_leave_container(it, &array_it);
	return result;
}


mac_t* mac_deserialize_raw(blob_t *data, int *success)
{
	CborParser parser;
	CborValue it;

	CHKNULL(success);
	*success = AMP_FAIL;
	CHKNULL(data);

	if(cbor_parser_init(data->value, data->length, 0, &parser, &it) != CborNoError)
	{
		return NULL;
	}

	return mac_deserialize_ptr(&it, success);
}

ctrl_t* mac_get(mac_t* mac, uint8_t index)
{
	int success;
	ctrl_t *result = NULL;
	CHKNULL(mac);

	result = (ctrl_t*) vec_at(mac->ctrls, index, &success);
	if(success != AMP_OK)
	{
		return NULL;
	}
	return result;
}

uint8_t mac_get_count(mac_t* mac)
{
	CHKZERO(mac);
	return vec_size(mac->ctrls);
}

void    mac_release(mac_t *mac, int destroy)
{
	CHKVOID(mac);

	ari_release(mac->ari, 1);
	vec_release(mac->ctrls, 1);

	if(destroy)
	{
		SRELEASE(mac);
	}
}


CborError mac_serialize(CborEncoder *encoder, mac_t *mac)
{
	CborError err;
	blob_t *result;
	int success;
	vec_idx_t max;
	vec_idx_t i;
	CborEncoder array_enc;

	CHKUSR(encoder, CborErrorIO);
	CHKUSR(mac, CborErrorIO);


	err = ari_serialize(encoder, mac->ari);

	CHKUSR(((err != CborNoError) && (err != CborErrorOutOfMemory)), err);

	max = vec_size(mac->ctrls);

	err = cbor_encoder_create_array(encoder, &array_enc, max);
	CHKUSR(((err != CborNoError) && (err != CborErrorOutOfMemory)), err);


	for(i = 0; i < vec_size(mac->ctrls); i++)
	{
		ctrl_t *cur_ctrl = vec_at(mac->ctrls, i, success);
		result = ctrl_serialize_wrapper(cur_ctrl);
		err = blob_serialize(array_enc, result);
		blob_release(result, 1);
		CHKUSR(((err != CborNoError) && (err != CborErrorOutOfMemory)), err);
	}

	err = cbor_encoder_close_container(encoder, &array_enc);

	return err;
}


blob_t*  mac_serialize_wrapper(mac_t *mac)
{
	blob_t *result = NULL;
	CborEncoder encoder;
	CborError err;

	CHKNULL(mac);

	if((result = blob_create(NULL, 0, (vec_size(mac->ctrls) + 1) * ARI_DEFAULT_ENC_SIZE)) == NULL)
	{
		AMP_DEBUG_ERR("mac_serialize_wrapper","Can't alloc encoding space",NULL);
		return NULL;
	}

	cbor_encoder_init(&encoder, result->value, result->alloc, 0);
	err = mac_serialize(&encoder, mac);

	/* If we didn't have enough memory, calculate how much we need and try again.*/
	if(err == CborErrorOutOfMemory)
	{
		size_t size = cbor_encoder_get_extra_bytes_needed(&encoder);

		if(blob_grow(result, size) != AMP_OK)
		{
			AMP_DEBUG_ERR("mac_serialize_wrapper", "Can't grow by %d", size);
			blob_release(result, 1);
			return NULL;
		}

		cbor_encoder_init(&encoder, result->value, result->alloc, 0);
		err = mac_serialize(&encoder, mac);
	}

	/* If we failed to serialize, free resources. */
	if(err != CborNoError)
	{
		AMP_DEBUG_ERR("mac_serialize_wrapper","Cbor Error: %d", err);
		blob_release(result, 1);
		return NULL;
	}

	return result;
}
