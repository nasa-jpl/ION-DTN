#!/usr/bin/env node
// TODO: Cleanup

import { CBOR } from "./lib/shared/cbor.js";
import * as AMP from "./lib/shared/amp.js";

// For this test application, we only accept one argument.  Use Yargs library if more complex parsing is needed later
var input = process.argv[2];

if (!input) {
    throw "Error: Expected an input string";
    // TODO: Prompt for input instead
}

var reg = await AMP.Registry.getInstance("lib/shared/adms");
console.log("AMP Parsing Test.  Input: ", input);

var obj = AMP.parseUri(input, true);
if (typeof obj == "object") {
    if (obj.constructor.name == "CBOR") {
        var log = obj.parse();
        console.log("Decoded CBOR Input.  Trace log is:", log);

        var obj2 = new CBOR();
        for(let i = 0; i < log.length; i++) {
            obj2.encode(log[i].value);
        }
        var hex2 = '0x'+obj2.toString();
        console.log("Re-encoded to " + hex2);
        if (hex != hex2) {
            console.warn("Re-encoded value differs from original");
        }

    } else { // An AMP-derived object
        console.log("Decode Tracing Log:", AMP.trace.get());
        
        var outCbor = '0x'+obj.toCbor(new CBOR()).toString();
        console.log("CBOR Re-Encoding", outCbor );
        
        if (obj.toUri) {
            console.log("URI: ", obj.toUri() );
        }
        
    }
} else {
    console.log(`Decoded to ${typeof obj} => ${obj}`);
}

