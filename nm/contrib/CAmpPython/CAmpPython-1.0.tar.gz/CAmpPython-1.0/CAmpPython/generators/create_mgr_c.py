# JHU/APL
# Description: creates the c file for the public version of the adm
# Modification History:
#   YYYY-MM-DD     AUTHOR            DESCRIPTION
#   ----------     ---------------   -------------------------------
#   2017-08-11		Evana
#	2017-12-28      David 			Metadata is in constants now
#   2018-06-27      David 			Changed mids to aris	

###############################################

import re
import os
import errno

from lib import campch
from lib.common import camputil as cu
from lib.common import campsettings as cs

#
# Constructs and returns the filename for this generated file.
#
# Also creates the mgr directory in the out directory if
# it doesn't exist
#
def initialize_file(name, outpath):
	# Make the mgr dir, only allow the 'directory exists' error
	try:
		os.mkdir(outpath+"/mgr/")
	except OSError as ose:
		if(not ose.errno == errno.EEXIST):
			print "[ Error ] Failed to create subdirectory in ", outpath
			print ose
			exit(-1)
			
	filename = outpath + "/mgr/" + name + "_mgr.c"
	return filename

#
# Writes the #includes to the open file descriptor passed, c_file
# ns is the ns value returned by get_adm_names()
#
def write_includes(c_file, name):
	files = ["ion.h", "platform.h",
		 "../shared/adm/{}.h".format(name),
		 "../shared/utils/utils.h", "../shared/primitives/report.h",
		 "../shared/primitives/blob.h",
		 "metadata.h", "nm_mgr_ui.h"]

	c_file.write(campch.make_includes(files))

#
#
#
def write_uses_includes(c_file, uses):
	c_file.write(campch.make_includes(cu.get_uses_files(uses)))

#
# Write the #defines to the open file descriptor passed, c_file
# short name is the short name value returned by get_adm_names()
#
def write_defines(c_file, ns):
	ns_upper = ns.upper()
	define_str = (
		"\n#define _HAVE_{0}_ADM_"
		"\n#ifdef _HAVE_{0}_ADM_"
		"\n")
	c_file.write(define_str.format(ns_upper))

#
# Writes the top-level init function that calls all of the other ones
# c_file is an open file descriptor to write to
# name is the name returned from get_adm_names()
#
# TODO: should the init function names not be hardcoded?
#
def write_init_function(c_file, name, g_var_idx, data):
	nupper = name.upper()

	vdb_adds = "\tadm_add_adm_info(\"" + name + "\", ADM_ENUM_"+name.upper()+");\n"

	init_calls = ""

	vdb_add_template = "\n\tVDB_ADD_NN(((ADM_ENUM_"+name.upper()+" * 20) + ADM_{0}_IDX), &({1}[ADM_{0}_IDX]));"
	init_funct_template = "\n\t"+name+"_init_{0}();"
	
	# Only generate NN's for elements that appear in the ADM
	for coll in data.keys():
		if coll.lower() == "uses": continue

		# Get the enum version of the coll instead of string
		coll = cs.name_get_coll(coll)
		# XXX: need to fix the inconsistencies in naming
		if(coll == cs.META):
			vdb_adds = vdb_adds + vdb_add_template.format(cs.get_sname(coll).upper(), g_var_idx)
		else :
			vdb_adds = vdb_adds + vdb_add_template.format(cs.get_lname(coll).upper(), g_var_idx)

	# must call initialization functions in correct order
	for coll in [cs.META, cs.CONST, cs.EDD, cs.OP, cs.VAR, cs.CTRL, cs.MACRO, cs.RPT, cs.TBL]:
		init_calls = init_calls + init_funct_template.format(cs.get_sname(coll).lower())
	
	body = vdb_adds + "\n\n" + init_calls
	
	campch.write_formatted_init_function(c_file, name, None, body)

#
#
#
def make_add_parm_template():
	return "\n\tmeta_add_parm(meta, \"{0}\", {1});"

#
# Iterates through all of the parameters owned by an item and returns
# a string with the meta_add_parm(...) calls for all parameters.
# Caller needs to generate `metadata_t *meta` string.
#
# item is the item to generate parameter calls for
#
def make_add_parms_str(item):
	add_parms_str = ""
	template = make_add_parm_template()
	
	params = cu.item_get_params(item)
	for p in params:
		try:
			p_type = cu.make_amp_type_name(p)
			add_parms_str = add_parms_str + template.format(p["name"], p_type)
		except KeyError, e:
			print "[ Error ] Badly formatted parameter. Key not found:"
			print e
			raise

	return add_parms_str


# Builds a template for the
# ```
# id = adm_build_ari(...)
# adm_add_...
# ```
# calls with passed collection type and adm name. Should be formatted in the calling
# function with:
# return_str.format([0|1](for whether params are present or not), ari_name, ari_amp_type, item[name], item[description])
#
# The intention behind this function is to only have to construct these parts once for each
# collection. Subset of formatted values that need to be substituted for_each_ item in the
# collection is much smaller.
#
# XXX needs refactored along with rest of this code. Ex: ADM_ENUM_ shouldn't be hardcoded
#
def make_std_meta_adm_build_template(coll, g_var_idx):
	add_str = campch.make_adm_build_ari_template(coll, g_var_idx, True)
	add_str = add_str + "\n\tadm_add_"  + cs.get_sname(coll).lower() + "(id, NULL);" 

	return add_str



#
# A lot of the collections in the mgr file follow the same pattern for their init
# function. This method encapsulates that.
#
# c_file is the file to write to, name is the name of the adm,
# g_var_idx is the g_*_idx variable created in the main function
# coll_type is the type of collection we're working with (cs.META, etc)
# coll is the actual collection list (all of the metadata for example)
#
def write_mgr_std_init_funct(c_file, name, g_var_idx, coll_type, coll):
	body = ""
	coll_decl_str = "\n\tari_t *id = NULL;\n"
	parm_decl_str = "\n\tmetadata_t *meta = NULL;\n"
	add_str_template = make_std_meta_adm_build_template(coll_type, g_var_idx)
	meta_add_template = campch.make_std_meta_add_coll_template(coll_type, name)

	added_coll = False
	added_parm = False
	
	for i in coll:
		try:
			ari = cu.make_ari_name(name, coll_type, i)
			amp_type = cu.make_amp_type_name(i)
			parms_tf = "0"

			add_parms_str = make_add_parms_str(i)
			if(add_parms_str != ""):
				parms_tf = "1"
				added_parm = True
			
			body = body + add_str_template.format(parms_tf, ari)

			if(add_parms_str != ""):
				body = body + "\n\tmeta = " + meta_add_template.format(amp_type, i["name"], i["description"])
			else:
				body = body + "\n\t" + meta_add_template.format(amp_type, i["name"], i["description"])
				
			body = body + add_parms_str
			
			added_coll = True		
				
		except KeyError, e:
			print "[ Error ] Badly formatted " + cs.get_lname(coll_type) + ". Key not found:"
			print e
			raise
		
	# This ensures that the ari_t *id variable is only declared if it is going to be used.
        # Avoids compiler warnings for unused variables
	if (added_parm):
		body = parm_decl_str + body
	if (added_coll) :
		body = coll_decl_str + body
		
	campch.write_formatted_init_function(c_file, name, coll_type, body)

#
# Writes the init_metadata() function to the open file descriptor passed as c_file
# name and ns are the values returned from get_adm_names()
# metadata is a list of the metadata to include
#
# XXX: could use standard init function, except for inconsistancies in naming
# (AMP_TYPE_CONST, but ADM_META_IDX, and AMP_AGENT_META_<name>
#
def write_init_metadata(c_file, name, g_var_idx, metadata):
	body = ""
	coll_decl_str = "\n\tari_t *id = NULL;\n"
	parm_decl_str = "\n\tmetadata_t *meta = NULL;\n"
	add_str_template = make_std_meta_adm_build_template(cs.CONST, g_var_idx).replace("ADM_CONST_IDX", "ADM_META_IDX")
	meta_add_template = campch.make_std_meta_add_coll_template(cs.CONST, name)

	added_coll = False
	added_parm = False
	
	for i in metadata:
		try:
			ari = cu.make_ari_name(name, cs.META, i)
			amp_type = cu.make_amp_type_name(i)
			parms_tf = "0"

			add_parms_str = make_add_parms_str(i)
			if(add_parms_str != ""):
				parms_tf = "1"
				added_parm = True
			
			body = body + add_str_template.format(parms_tf, ari)

			if(add_parms_str != ""):
				body = body + "\n\tmeta = " + meta_add_template.format(amp_type, i["name"], i["description"])
			else:
				body = body + "\n\t" + meta_add_template.format(amp_type, i["name"], i["description"])
				
			body = body + add_parms_str
			
			added_coll = True		
				
		except KeyError, e:
			print "[ Error ] Badly formatted " + cs.get_lname(cs.META) + ". Key not found:"
			print e
			raise
		
	# This ensures that the ari_t *id variable is only declared if it is going to be used.
        # Avoids compiler warnings for unused variables
	if (added_parm):
		body = parm_decl_str + body
	if (added_coll) :
		body = coll_decl_str + body
		
	campch.write_formatted_init_function(c_file, name, cs.META, body)

#
# Writes the init_constants() function to the open file descriptor passed as c_file
# name is the value returned from get_adm_names()
# constants is a list of constants to include
#
def write_init_constants(c_file, name, g_var_idx, constants):
	write_mgr_std_init_funct(c_file, name, g_var_idx, cs.CONST, constants)

#
# Writes the init_edds function to the passed open file c_file
# name and ns are the values returned by get_adm_names()
# edds is a list of edds to include
#
def write_init_edd_function(c_file, name, g_var_idx, edds):
	write_mgr_std_init_funct(c_file, name, g_var_idx, cs.EDD, edds)

	
#
# Writes the init_operators() function to the open file descriptor passed as c_file
# name is the value returned from get_adm_names()
# operators is a list of the operators to include
#
def write_init_ops(c_file, name, g_var_idx, operators):
	body = ""
	coll_decl_str = "\n\tari_t *id = NULL;\n"
	parm_decl_str = "\n\tmetadata_t *meta = NULL;\n"
	build_str_template = campch.make_adm_build_ari_template(cs.OP, g_var_idx, True)
	# XXX names are not consistant between types (use of ns vs longname)
	# This is not ideal, but a fix for now that keeps it using the standard function.
	# need to revisit
	meta_add_template = campch.make_std_meta_add_coll_template(cs.OP, name).replace("meta_add_oper", "meta_add_op")

	add_parm_template = make_add_parm_template()
	
	added_coll = False
	added_parm = False

	for i in operators:
		try:
			parms_tf = "0"
			ari = cu.make_ari_name(name, cs.OP, i)
			amp_type = cu.make_amp_type_name_from_str(i["result-type"])
			meta_str = meta_add_template.format(amp_type, i["name"], i["description"])

			parms = i.get("in-type", [])
			if parms :
				parms_tf = "1"
				added_parm = True
				meta_str = "meta = " + meta_str

			body = body + "\n" + build_str_template.format(parms_tf, ari)		
			body = body + "\n\tadm_add_op_ari(id, {}, NULL);".format(len(parms))
			body = body + "\n\t" + meta_str
			
			for idx,p in enumerate(parms):
				parm_type = cu.make_amp_type_name_from_str(p)
				body = body + add_parm_template.format("O{}".format(idx+1), parm_type)
			
			added_coll = True			
				
		except KeyError, e:
			print "[ Error ] Badly formatted " + cs.get_lname(cs.OP) + ". Key not found:"
			print e
			raise
		
	# This ensures that the ari_t *id variable is only declared if it is going to be used.
        # Avoids compiler warnings for unused variables
	if (added_parm):
		body = parm_decl_str + body
	if (added_coll) :
		body = coll_decl_str + body
		
	campch.write_formatted_init_function(c_file, name, cs.OP, body)

#
# Writes the init_variables() function to the open file descriptor passed as c_file
# name is the value returned from get_adm_names()
# variables is a list of variables to include
#
def write_init_variables_function(c_file, name, g_var_idx, variables, data, uses):
	campch.write_init_var_function(c_file, name, g_var_idx, variables, data, uses, True)

#
# Writes the init_controls() function to the open file descriptor passed as c_file
# name is the value returned from get_adm_names()
# controls is a list of controls to include
#
def write_init_controls_function(c_file, name, g_var_idx, controls):
	body = ""
	coll_decl_str = "\n\tari_t *id = NULL;\n"
	parm_decl_str = "\n\tmetadata_t *meta = NULL;\n"
	build_str_template = campch.make_adm_build_ari_template(cs.CTRL, g_var_idx, True)
	meta_add_template =  "meta_add_" + cs.get_sname(cs.CTRL).lower() + "(id, ADM_ENUM_" + name.upper() + ", \"{0}\", \"{1}\");\n"

	add_parm_template = make_add_parm_template()
	
	added_coll = False
	added_parm = False

	for i in controls:
		try:
			parms_tf = "0"
			ari = cu.make_ari_name(name, cs.CTRL, i)
			meta_str = meta_add_template.format(i["name"], i["description"])

			parms = i.get("parmspec", [])
			if parms :
				parms_tf = "1"
				added_parm = True
				meta_str = "meta = " + meta_str

			body = body + "\n\n\t/* {} */".format(i["name"].upper())
			body = body + "\n" + build_str_template.format(parms_tf, ari)		
			body = body + "\n\tadm_add_ctrldef_ari(id, {}, NULL);".format(len(parms))
			body = body + "\n\t" + meta_str
			
			for p in parms:
				parm_type = cu.make_amp_type_name(p)
				body = body + add_parm_template.format(p["name"], parm_type)
			
			added_coll = True			
				
		except KeyError, e:
			print "[ Error ] Badly formatted " + cs.get_lname(cs.CTRL) + ". Key not found:"
			print e
			raise
		
	# This ensures that the ari_t *id variable is only declared if it is going to be used.
        # Avoids compiler warnings for unused variables
	if (added_parm):
		body = parm_decl_str + body
	if (added_coll) :
		body = coll_decl_str + body
		
	campch.write_formatted_init_function(c_file, name, cs.CTRL, body)


#
# Writes the init_macros() function to the open file descriptor passed as c_file
# name is the value returned from get_adm_names()
# macros is a list of macros to include
#
def write_init_macros(c_file, name, g_var_idx, macros, data, uses):
	campch.write_init_macro_function(c_file, name, g_var_idx, macros, data, uses, True)


#
# Writes the init_reports() function to the open file descriptor passed as c_file
# name is the value returned from get_adm_names()
# data is the JSON dictionary of values
# uses is the dictionary of files pulled in with the 'uses' construct
#
def write_init_reports(c_file, name, g_var_idx, data, uses):
	campch.write_parameterized_init_reports_function(c_file, name, g_var_idx, data, uses, True)

#
#
#
def write_init_tables(c_file, name, g_var_idx, tables):
	campch.write_init_tables_function(c_file, name, g_var_idx, tables, True)
	
#
# Main function of this file, which calls helper functions to
# orchestrate the creation of the generated file
#
# data: the dictionary made from a parsed JSON file
# outpath: the output directory
# uses: the dictionary of the imported JSON files
#
def create(data, outpath, uses):
	try:
		name, ns = cu.get_adm_names(data)
		filename = initialize_file(name, outpath)
		c_file = open(filename,"w")
	except KeyError, e:
		print "[ Error ] JSON does not include valid metadata"
		print e
		return
	except IOError, e:
		print "[ Error ] Failed to open ", filename, " for writing."
		print e
		return

	print "Working on ", filename,
	
	campch.write_c_file_header(c_file, filename)

	# calling each of the helper functions to handle the writing of
	# various functions in this file
	write_includes(c_file, name)
	write_uses_includes(c_file, cu.get_uses(data))
	
	write_defines(c_file, ns)

	g_var_idx = cu.make_g_var_idx(ns)
	c_file.write("vec_idx_t {}[11];\n\n".format(g_var_idx))
	
	write_init_function(c_file, ns, g_var_idx, data);
	try:
		write_init_metadata(    c_file, ns, g_var_idx, cu.get_metadata(data))
		write_init_constants(   c_file, ns, g_var_idx, cu.get_constants(data))
		write_init_edd_function(c_file, ns, g_var_idx, cu.get_edds(data))
		write_init_ops(         c_file, ns, g_var_idx, cu.get_operators(data))

		write_init_variables_function(c_file, ns, g_var_idx, cu.get_variables(data), data, uses)
		write_init_controls_function( c_file, ns, g_var_idx, cu.get_controls(data))

		write_init_macros( c_file, ns, g_var_idx, cu.get_macros(data), data, uses)
		write_init_reports(c_file, ns, g_var_idx, data, uses)
		write_init_tables( c_file, ns, g_var_idx, cu.get_tables(data))
	except KeyError, e:
		print "[ Error ] Create_Mgr_C. Key not found:"
		print e
	except Exception, e:
		print "[ Error ] Create_Mgr_C"
		print e
	finally:
		c_file.write("#endif // _HAVE_"+ns.upper()+"_ADM_\n")
		c_file.close()
	
	print "\t[ DONE ]"
