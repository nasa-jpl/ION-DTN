from setuptools import setup, find_packages
import CAmpPython


setup(name='CAmpPython',
      version='1.0',
      author='David and Evana',
      author_email='',
      description="C code generator for the Asychronous Management Protocol",
      long_description="The camp command takes in a JSON file which models a protocol and returns c and h files. These files are created by using the formatted information of the different data types that are described in the JSON. Can create the implemented files and then general files.",
      url='',
      license='',
      classifiers=[],
      keywords='AMP converter',
      packages=find_packages(),
      install_requires=['configobj'],
      package_data={'':['data/name_registry.cfg']},
      entry_points = {
            'console_scripts':[
                  'camp=CAmpPython.CAmpPython:main',
            ],
      },
)

