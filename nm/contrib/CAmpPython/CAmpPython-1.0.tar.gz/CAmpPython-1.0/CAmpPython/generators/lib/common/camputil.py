# JHU/APL
#
# Description: library file for utility functions related to parsing the
#              JSON input file and creating ARIs
#
# Modification History:
#   YYYY-MM-DD     AUTHOR            DESCRIPTION
#   ----------     ---------------   -------------------------------
#   2017-11-30     Sarah             File creation
#   2018-01-02	   Evana	     Added functionality for tables
#   2018-01-05	   David	     Added new method for creating parameterized aris 
#
#############################################################################

import json
import re
import os

import campsettings as cs


############################### ACCESSORS FOR JSON DATA ##############################

#
# Finds and returns a tuple of (string, string) that is the long and short
# names of the adm as found in the JSON-loaded dictionary
#
# Throws a KeyError exception if JSON is incorrectly formatted (missing keys)
#
def get_adm_names(data):
	try:
		metadata = get_metadata(data)
		name = re.sub('\s', '_', metadata[0]["value"]).lower()
		ns = metadata[1]["value"].lower().replace("/", "_")
	except KeyError, e:
		raise
	
	return "adm_" + name, ns

#
# Finds and returns the namespace of the adm as found in the JSON-loaded dictionary
#
# Throws a KeyError exception if the JSON is incorrectly formatted (missing keys)
#
def get_namespace(data):
	try:
		metadata = get_metadata(data)
		namespace = metadata[1]["value"]
	except KeyError, e:
		raise
	return namespace

#
# Takes a list of files pulled in with "uses" and converts them to the
# name expected for #include declarations.
# Returns a list of correctly-formatted files, to be passed to make_includes()
#
def get_uses_files(uses):
	formatted_uses = [f.lower().replace("/", "_") for f in uses]
	files = ["../shared/adm/adm_{}.h".format(f) for f in formatted_uses]
	return files
	
		
#
# Helper function to extract the collection of c from data
# Returns a list, or the empty list if not found or invalid
# XXX: this function seems unnescessary with recent changes. Re-evaluate
#
def get_collection(data, coll):
	#TODO enum and switch would be better
	c_info = {}
	if coll == cs.META:
		return get_metadata(data)
	elif coll == cs.CONST:
		return get_constants(data)
	elif coll == cs.TBL:
		return get_tables(data)
	elif coll == cs.EDD:
		return get_edds(data)		
	elif coll == cs.CTRL:
		return get_controls(data)
	elif coll == cs.OP:
		return get_operators(data)
	elif coll == cs.VAR:
		return get_variables(data)
	elif coll == cs.MACRO:
		return get_macros(data)
	elif coll == cs.RPT:
		return get_reports(data)
	else:
		print "[Error] Invalid ttype"
		return []

#
# Accessor for the 'uses' construct in the data.
# Returns a list of the names of the ADMs this data 'uses', or an empty list if none are present.
#
def get_uses(data):
	return data.get("uses", [])
		
#
# Accessor for the metadata part of the data
# returns a list of the requested data, or an empty list if none are present
#
def get_metadata(data):
	return data.get(cs.get_lname(cs.META), [])


#
# Accessor for the constants portion of the JSON data
# returns a list of the requested data, or an empty list if none are present
#
def get_constants(data):
	return data.get(cs.get_lname(cs.CONST), [])

#
# Accessor for the tables part of the data
# returns a list of the requested data, or an empty list if none are present
#
def get_tables(data):
	return data.get(cs.get_lname(cs.TBL), [])

#
# Accessor for the EDDs part of the JSON data
# returns a list of the requested data, or an empty list if none are present
#
def get_edds(data):
	return data.get(cs.get_lname(cs.EDD), [])

#
# Accessor for the controls portion of the JSON data
# returns a list of the requested data, or an empty list if none are present
#
def get_controls(data):
	return data.get(cs.get_lname(cs.CTRL), [])

#
# Accessor for the operators portion of the JSON data
# returns a list of the requested data, or an empty list if none are present
#
def get_operators(data):
	return data.get(cs.get_lname(cs.OP), [])

#
# Accessor for the variables portion of the JSON data
# returns a list of the requested data, or an empty list if none are present
#
def get_variables(data):
	return data.get(cs.get_lname(cs.VAR), [])

#
# Accessor for the macros portion of the JSON data
# returns a list of the requested data, or an empty list if none are present
#
def get_macros(data):
	return data.get(cs.get_lname(cs.MACRO), [])

#
# Accessor for the report-templates portion of the JSON data
# returns a list of the requested data, or an empty list if none are present
#
def get_reports(data):
	return data.get(cs.get_lname(cs.RPT), [])

#
# Given a @coll (cs.[EDD|VAR|META|...}), a @name for an item in that type,
# and the @data dictionary resulting from json_load(), returns a list of
# the types found in the parmspec dictionary for that item
# checks the @uses dictionary of imported JSON if the item isn't in this ADM
#
def get_parm_types(adm, coll, name, data, uses):
	adm = adm.upper()
	space = get_namespace(data).upper()

	# Figure out if we're looking locally or externally
	haystack = None
	if adm == space:
		haystack = data
	else:
		haystack = uses.get(adm, None)

	if haystack == None:
		print "[ ERROR ] namespace needed by JSON is not loaded: ", adm
		print "Check to make sure that their JSON is formatted correctly and was properly loaded"

		raise Exception

	# find the right collection in the data
	pile = get_collection(haystack, coll)

	# find the item in the collection
	for item in pile:
		try:
			if(item["name"] == name):
				# Fancy way of pulling out all of the keys (types) in each of the parameter dictionaries
				parm_types = [d["type"] for d in item_get_params(item)]
				return parm_types
		except KeyError, e:
			print "[ Error ] Badly formatted %s. Key not found:".format(ttype)
			print e
			return None
		
	return None


def get_default_values(adm, coll, name, data, uses):
	adm = adm.upper()
	space = get_namespace(data).upper()
	
	# Figure out if we're looking locally or externally
	haystack = None
	if adm == space:
		haystack = data
	else:
		haystack = uses.get(adm, None)

	if haystack == None:
		print "[ ERROR ] namespace needed by JSON is not loaded: ", adm
		raise Exception

	# find the right collection in the data
	pile = get_collection(haystack, coll)

	# find the item in the collection
	for item in pile:
		try:
			if(item["name"] == name):
				# Fancy way of pulling out all of the keys (value) in each of the parameter dictionaries
				try:
					parm_types = [d["value"] for d in item_get_params(item)]
				except KeyError:
					return None 

				return parm_types
		except KeyError, e:
			print "[ Error ] Badly formatted %s. Key not found:".format(ttype)
			print e
			return None


#
# Returns the parameters for the passed item as a list.
# Returns the empty list [], if no parameters found.
#
def item_get_params(item):
	return item.get("parmspec", [])

def item_get_in_types(item):
	return item.get("in-type",[])

def item_get_def(item):
	return item.get("definition",[])

def item_get_initializer(item):
	return item.get("initializer",{})

def item_get_postfix(item):
	init = item_get_initializer(item)
	return init.get("postfix-expr",[])

def item_get_columns(item):
	return item.get("columns",[])

#
# Given a @definition entry from the JSON file, returns a
# (string, collection, string, list) tuple of the adm, collection, name,
# and list of parameters for the definition
#
# adm.type.name(param1, param2,...) returns (adm, type, name, [param1, param2,...])
# Returns an empty list for parameters if none are present
#
def parse_definition(entry,default_adm):
	default_adm = default_adm.replace("/","_")
	# if the entry is using the string encoding of ARIs
	if isinstance(entry, unicode):
		parms = []
		match = re.match("^(.+\/)*\/?(.+)\.(\w+)(\((.+)?\))?$",entry)
		
		d_adm = match.group(1)
		d_adm = d_adm[:-1]
		if d_adm == "":
			d_adm = default_adm

		d_coll = cs.name_get_coll(match.group(2))
		d_name = match.group(3)
		if match.group(4):
			m = match.group(5)
			if(m):
				parms = m.split(',')
			else:
				parms = [""]
	# if using the JSON object encoding
	else:
		d_adm = entry.get('ns', default_adm)
		# splits up the entry name 
		d_coll, d_name = str(entry['nm']).split('.')
		d_coll = cs.name_get_coll(d_coll)
		parms = entry.get('ap', [])

	return d_adm, d_coll, d_name, parms


################################## ARI CREATION FUNCTIONS ###########################

# 
#encode integers in cbor  
# 
def cbor_encode_int(val):
    convert = ("{:02x}".format(val))
    if val <= 23:
        return convert
    if val <= 0x0ff:
        return "18" + convert
    if val <= 0x0ffff:
        return "19" + convert    	
    if val <= 0x0ffffffff:
        return "1a" + convert    	
    if val <= 0x0ffffffffffffffff:
        return "1b" + convert

    raise Exception("value too big for CBOR unsigned number: {0!r}".format(val))

# 
#encode byteStrings in cbor  
#
def cbor_encode_byte(ari):
	length = len(ari)/2
	if length <= 15:
		return "4" + "{:01x}".format(length) + ari
	elif length <= 23: 
		return "5" + "{:01x}".format(length-16) + ari
	elif length <= 255:
		return "58" + "{:02x}".format(length) + ari
	else: 
		return "59" + "{:04x}".format(length) + ari

# 
#encode arrays in cbor  
#
def cbor_encode_array(ac):
	length = len(ac)
	encode = ""
	
	if length <= 15:
		encode = "8" + "{:01x}".format(length)
	elif length <= 23:
		encode = "9" + "{:01x}".format(length-16)
	elif length <= 255:
		encode = "98" + "{:02x}".format(length)
	else:
		encode = "99" + "{:04x}".format(length)

	for a in ac:
		encode = encode + a


#
# Creates and returns a string that is the ari for the data object
# nn is the nickname
# coll is the collection type (EDD, VAR, RPT, etc.)
# enum is the enumaration of the object in the json
# data is the data object
# encoded in CBOR as byte string
#
def convert_ari((nn, coll, enum, data)):
	ttype = cs.get_lname(coll).upper()
	
	amp_ari = ""

	# since there will be no issuers or tags present and all the aris are compressed 
 	# only have to worry about if it is parameterized
	# XXX: not sure if this conditional is robust (is it correct to only use c flag for
	# these conditions? (ex: rptt also has definition field. Can a macro have an empty
	# definition list?)
	flag = "8"  
	if data.has_key("parmspec") or (coll is cs.MACRO and data.has_key("definition")):
		flag = "c"

	try:
		# adding the flag byte 
		amp_ari = amp_ari + flag + cs.ari_type_enum[ttype]

		# nicknames
		nickname = (nn * 20) + cs.nn_type_enum[ttype]
		amp_ari = amp_ari + cbor_encode_int(nickname)
	except KeyError, e:
		print "[ ERROR ] ", ttype, " is not supported by convert_ari function"
		raise

	
	# converting the enumeration to cbor
	amp_ari = amp_ari + cbor_encode_int(enum)

	# adding the bytestring header 
	# NOT SURE IF NEEDED 
	amp_ari = cbor_encode_byte(amp_ari) 
	return amp_ari


######################## GENERAL PARAMETER FUNCTIONS ####################
	
#
# Returns True if the passed value is a mapped parameter, False if not.
# Assumes that if a value is NOT in quotes, it is mapped.
#
def is_mapped_param(value):
	first_char = value[:1]
	
	if(first_char == '"' or first_char == "'"):
		return False
	return True

#
# Takes a quoted parameter and returns it in the correct type.
# Assumes that strings can be left as-is, and others just need the
# quotes removed.
#
def quoted_to_type(ttype, value):
	if(ttype == "STR"):
		return value
	return value[1:-1]

#
# Returns a simple default value for a passed type
# (STR returns empty string, else returns 0)
# TODO: support additional types
#
def get_default_for_type(ttype):
	if ttype == "STR":
		return "\"\""
	return "0"

#
# Given a @value and a parmspec list, (@params),
# Finds and returns the index of the passed value in the list
#
def get_index_in_parmspec(value, params):
	value = value.strip()

	param_values = [d["name"] for d in params]

	index = param_values.index(value) if value in param_values else None
	
	return index

#
#
#
def make_g_var_idx(ns):
	name = ns.replace("/", "_")
	return "g_" + name.lower() + "_idx"

#
# Given a name and namespace, constructs and returns the
# ari name for the item
#
def make_ari_name_from_ns_nm(ns, nm):
	# the collection type is the part before the '.'
	coll = cs.name_get_coll(nm.split('.')[0])

	# the name is the part after the '.', but omit anything following in parenthesis
	name = nm.split('.')[1].split('(')[0]
	return make_ari_name_from_str(ns, coll, name)

#
# Formats and returns a string for the ari
# name is the value returned from a call to initialize_names, coll is the
# collection the item belongs to (cs.[EDD|VAR|...]), item is the item to
# make the ari for i_name is the name of the item
#
def make_ari_name_from_str(name, coll, i_name):
	name = name.replace("/", "_")
	template = "{0}_{1}_{2}"
	return template.format(name.upper(), cs.get_sname(coll).upper(), i_name.upper())

#
# Formats and returns a string for the ari
# name is the value returned from a call to initialize_names, coll is the
# collection the item belongs to (VAR, EDD, etc), item is the item to make
# the ari for
# Assumes that the passed item has a valid "name" field
#
def make_ari_name(name, coll, item):
	return make_ari_name_from_str(name, coll, item["name"])

#
# Makes and returns the amp type string for the passed item
# t_name is the name of the type
#
def make_amp_type_name_from_str(t_name):
	return "AMP_TYPE_{}".format(t_name.upper())

#
# Makes and returns the amp type string for the passed item
# Assumes that the item has a valid "type" field
#
def make_amp_type_name(item):
	return make_amp_type_name_from_str(item["type"])


##################################### USES FUNCTIONS ##################################

#
# Returns a list of all of the files ending in .json in the passed directory
#
# XXX: It's not optimal to be searching for these files. Should the user pass in the
# XXX- appropriate JSON file instead? 
#
def find_json_files(path):
	json_files = []
	
	for file in os.listdir(path):
		if file.endswith(".json"):
			json_files.append(file)
			
	return json_files

#
# Loads all of the JSON files that are imported with the 'uses' construct in
# the passed data, and builds a dictionary of ADM_NAME : json_dict pairs.
# path is the path to the directory where the imported files should be found.
#
# Prints an error message if a file can't be found or loaded.
#
def build_uses_dict(data, path):
	uses_dict = {}

	# put self in uses dict
	namespace = get_namespace(data)
	uses_dict[namespace.upper()] = data

	uses = get_uses(data)
	
	if uses == []:
		return uses_dict
	
	# XXX: we currently have to load every JSON file because 'uses' calls them by
	# XXX- name, not filename. Should we switch to importing by filename? 
	json_files = find_json_files(path)
	all_dict = {}
	for file in json_files:
		jfile = open(path+"/"+file, 'r')
		try:
			loaded_json = json.load(jfile)

			jfile.close()

			namespace = get_namespace(loaded_json)
			all_dict[namespace.upper()] = loaded_json
		except Exception, e:
			pass

	# only return the ones that this JSON needs
	for name in uses:
		name = name.upper()
		if name in all_dict:
			uses_dict[name] = all_dict[name]
		else:
			print "[ ERROR ] Failed to load \"", name, "\" used by JSON file, check to make sure it is formatted in accordance with AMA ADM"
			print "Issue my arise from objects that uses this ADM"
			
	return uses_dict
