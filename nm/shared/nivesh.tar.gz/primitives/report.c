/******************************************************************************
 **                           COPYRIGHT NOTICE
 **      (c) 2012 The Johns Hopkins University Applied Physics Laboratory
 **                         All rights reserved.
 ******************************************************************************/
/*****************************************************************************
 **
 ** \file report.c
 **
 **
 ** Description:
 **
 **
 ** Notes:
 **
 ** Assumptions:
 **
 ** Modification History:
 **  MM/DD/YY  AUTHOR         DESCRIPTION
 **  --------  ------------   ---------------------------------------------
 **  01/11/13  E. Birrane     Redesign of primitives architecture. (JHU/APL)
 **  06/24/13  E. Birrane     Migrated from uint32_t to time_t. (JHU/APL)
 **  07/02/15  E. Birrane     Migrated to Typed Data Collections (TDCs) (Secure DTN - NASA: NNX14CS58P)
 **  01/10/18  E. Birrane     Added report templates and parameter maps (JHU/APL)
 **  09/28/18  E. Birrane     Update to latest AMP v0.5. (JHU/APL)
 *****************************************************************************/

#include "platform.h"

#include "../utils/utils.h"

#include "report.h"

#include "tnv.h"



/******************************************************************************
 *
 * \par Function Name: rpt_add_entry
 *
 * \par Add an entry to an existing report.
 *
 * \param[in]  rpt   The report receiving the new entry.
 * \param[in]  entry The new entry.
 *
 * \par Notes:
 *  1. The entry is shallow-copied into the report. It MUST NOT be deallocated
 *     by the calling function.
 *
 * \return SUCCESS or FAILURE
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  07/02/15  E. Birrane     Initial implementation.
 *  09/28/18  E. Birrane     Switched to vectors for entries.
 *****************************************************************************/

int rpt_add_entry(rpt_t *rpt, tnv_t *entry)
{
	CHKUSR(rpt, AMP_FAIL);
	CHKUSR(entry, AMP_FAIL);

	return tnv_insert(&(rpt->entries), entry, NULL);
}


int rpt_cb_comp_fn(void *i1, void *i2)
{
	rpt_t *r1 = (rpt_t*) i1;
	rpt_t *r2 = (rpt_t*) i2;

	CHKUSR(r1, -1);
	CHKUSR(r2, -1);

	return ari_cb_comp_fn(r1->id, r2->id);
}

void rpt_cb_del_fn(void *item)
{
	rpt_release((rpt_t*)item, 1);
}



/******************************************************************************
 *
 * \par Function Name: rpt_clear
 *
 * \par Cleans up a reports.
 *
 * \param[in|out]  rpt     The report whose entries are to be cleared
 *
 * \par Notes:
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  07/02/15  E. Birrane     Report cleanup and transition to TDCs.
 *  09/28/18  E. Birrane     Switched to vectors for entries.
 *****************************************************************************/

void  rpt_clear(rpt_t *rpt)
{
    AMP_DEBUG_ENTRY("rpt_clear_lyst","("ADDR_FIELDSPEC")", (uaddr) rpt);
    CHKVOID(rpt);
    vec_clear(&(rpt->entries));
}



/******************************************************************************
 *
 * \par Function Name: rpt_create
 *
 * \par Create a new report entry.
 *
 * \param[in]  time       The creation timestamp for the report.
 * \param[in]  entries    The list of current report entries
 * \param[in]  recipient  The recipient for this report.
 *
 * \todo
 *  - Support multiple recipients.
 *
 * \par Notes:
 *  1. The entries are shallow-copied into the report, so they MUST NOT
 *     be de-allocated by the calling function.
 *
 * \return The created report, or NULL on failure.
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  07/03/15  E. Birrane     Report cleanup and transition to TDCs.
 *  09/28/18  E. Birrane     Switched to vectors for entries.
 *****************************************************************************/

rpt_t* rpt_create(ari_t *id, time_t timestamp, tnvc_t entries)
{
	rpt_t *result = NULL;

	AMP_DEBUG_ENTRY("rpt_create","("ADDR_FIELDSPEC",%d,entries)",
			        (uaddr) id, time);

	/* Step 1: Allocate the message. */
	if((result = (rpt_t*) STAKE(sizeof(rpt_t))) == NULL)
	{
		AMP_DEBUG_ERR("rpt_create","Can't alloc %d bytes.",
				        sizeof(rpt_t));
		AMP_DEBUG_EXIT("rpt_create","->NULL",NULL);
		return NULL;
	}

	/* Step 2: Populate the report. */
	result->id = id;
	result->time = timestamp;
	result->entries = entries;

	AMP_DEBUG_EXIT("rpt_create","->0x%x",result);
	return result;
}



/******************************************************************************
 *
 * \par Function Name: rpt_deserialize_data
 *
 * \par Extracts a Report from a byte buffer. When serialized, a
 *      Report is a timestamp, the # entries as an SDNV, then a
 *      series of entries. Each entry is of type rpt_entry_t.
 *
 * \retval NULL - Failure
 *         !NULL - The created/deserialized Report.
 *
 * \param[in]  cursor       The byte buffer holding the data
 * \param[in]  size         The # bytes available in the buffer
 * \param[out] bytes_used   The # of bytes consumed in the deserialization.
 *
 * \par Notes:
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  07/02/15  E. Birrane     Report cleanup and transition to TDCs.
 *  09/28/18  E. Birrane     Switched to vectors and CBOR for entries.
 *****************************************************************************/


rpt_t* rpt_deserialize_ptr(CborValue *it, int *success)
{
	rpt_t *result = NULL;
	size_t len;
	time_t timestamp;
	ari_t *id;
	tnvc_t entries;
	CborError err;
	CborValue array_it;

	AMP_DEBUG_ENTRY("rpt_deserialize_ptr",
			        "("ADDR_FIELDSPEC","ADDR_FIELDSPEC")",
					(uaddr)it, (uaddr)success);

	/* Sanity Checks. */
	CHKNULL(success);
	*success = AMP_FAIL;
	CHKNULL(it);

	if(!cbor_value_is_array(it))
	{
		return NULL;
	}

	/* Step 1: Determine how many elements are in the array */
	if(cbor_value_get_array_length(it, &len) != CborNoError)
	{
		return NULL;
	}

	if(cbor_value_enter_container(it, &array_it) != CborNoError)
	{
		return NULL;
	}

	/* Step 2: grab the Id. */
	id = ari_deserialize_ptr(&array_it, success);

	if((id == NULL) || (*success != AMP_OK))
	{
		cbor_value_leave_container(it, &array_it);
		return NULL;
	}

	/* Step 3: Get timestamp, if it was included. 	*/
	if(len == 3)
	{
		if(cut_get_cbor_numeric(&array_it, AMP_TYPE_TS, &timestamp) != AMP_OK)
		{
			cbor_value_leave_container(it, &array_it);
			ari_release(id, 1);
			return NULL;
		}
	}
	else
	{
		timestamp = 0;
	}

	entries = tnvc_deserialize(&array_it, success);

	cbor_value_leave_container(it, &array_it);


	if(*success != AMP_OK)
	{
		ari_release(id, 1);
		return NULL;
	}

	if((result = rpt_create(id, timestamp, entries)) == NULL)
	{
		ari_release(id, 1);
		tnvc_release(entries, 0);
		*success = AMP_FAIL;
	}

	*success = AMP_OK;
	return result;
}


rpt_t*   rpt_deserialize_raw(blob_t *data, int *success)
{
	CborParser parser;
	CborValue it;

	CHKNULL(success);
	*success = AMP_FAIL;
	CHKNULL(data);

	if(cbor_parser_init(data->value, data->length, 0, &parser, &it) != CborNoError)
	{
		return NULL;
	}

	return rpt_deserialize_ptr(&it, success);
}





/******************************************************************************
 *
 * \par Function Name: rpt_release
 *
 *
 * \par Releases all memory allocated in the Report. Clears all entries.
 *
 * \param[in,out]  rpt    The report to be released.
 *
 * \par Notes:
 *      - The report itself is destroyed and MUST NOT be referenced after a
 *        call to this function.
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  07/02/15  E. Birrane     Report cleanup and transition to TDCs.
 *  09/28/18  E. Birrane     Update to latest AMP. (JHU/APL)
 *****************************************************************************/

void rpt_release(rpt_t *rpt, int destroy)
{
	CHKVOID(rpt);

	ari_release(rpt->id, 1);
	tnvc_release(rpt->entries, 0);

	if(destroy)
	{
		SRELEASE(rpt);
	}
}


CborError rpt_serialize(CborEncoder *encoder, rpt_t *rpt)
{
	CborError err;
	CborEncoder array_enc;
	blob_t *result;
	int success;
	size_t num;

	CHKUSR(encoder, CborErrorIO);
	CHKUSR(rpt, CborErrorIO);

	num = (rpt->time == 0) ? 2 : 3;

	/* Start a container. */
	err = cbor_encoder_create_array(encoder, &array_enc, num);
	CHKUSR(((err != CborNoError) && (err != CborErrorOutOfMemory)), err);

	/* Step 1: Encode the ARI. */
	result = ari_serialize_wrapper(rpt->id);
	err = blob_serialize(&array_enc, result);
	blob_release(result, 1);

	if((err != CborNoError) && (err != CborErrorOutOfMemory))
	{
		cbor_encoder_close_container(encoder, &array_enc);
		return err;
	}

	if(num == 3)
	{
		err = cbor_encode_uint(&array_enc, rpt->time);
		if((err != CborNoError) && (err != CborErrorOutOfMemory))
		{
			cbor_encoder_close_container(encoder, &array_enc);
			return err;
		}
	}

	/* Step 3: Encode the entries. */
	result = tnvc_serialize_wrapper(rpt->entries);
	err = blob_serialize(&array_enc, result);
	blob_release(result, 1);

	cbor_encoder_close_container(encoder, &array_enc);
	return err;
}



blob_t*   rpt_serialize_wrapper(rpt_t *rpt)
{
	return cut_serialize_wrapper(RPT_DEFAULT_ENC_SIZE, rpt, rpt_serialize);
}




/******************************************************************************
 *
 * \par Function Name: rpttpl_add_item
 *
 * \par Add an item to a report template.
 *
 * * \retval 1 Success
 *           0 application error
 *           -1 system error
 *
 * \param[in|out]  rpttpl   The report template receiving a new item
 * \param[in]      item     THe item to add.
 *
 * \par Notes:
 *  1. Items are added at the end of the report template.
 *  2. This is a shallow-copy. The item MUST NOT be deleted by the caller.
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  01/10/18  E. Birrane     Initial implementation.
 *  09/28/18  E. Birrane     Updated to AMP V0.5
 *****************************************************************************/

int rpttpl_add_item(rpttpl_t *rpttpl, ari_t *item)
{
	CHKERR(rpttpl);
	CHKERR(item);

	return vec_push(&(rpttpl->contents.values), item, NULL);
}



int rpttpl_cb_comp_fn(void *i1, void *i2)
{
	rpttpl_t *t1 = (rpttpl_t*)i1;
	rpttpl_t *t2 = (rpttpl_t*)i2;

	return ari_cb_comp_fn(t1->id, t2->id);
}

void rpttpl_cb_del_fn(void *item)
{
	rpttpl_release((rpttpl_t*)item, 1);
}


rpttpl_t *rpttpl_copy_ptr(rpttpl_t *rpttpl)
{
	rpttpl_t *result = NULL;
	ari_t *new_ari = NULL;
	ac_t new_ac;

	CHKNULL(rpttpl);

	new_ari = ari_copy_ptr(rpttpl->id);
	new_ac = ac_copy(&(rpttpl->contents));

	if(((result = rpttpl_create(new_ari, new_ac))) == NULL)
	{
		ari_release(new_ari, 1);
		ac_clear(&new_ac);
	}

	return result;
}

/******************************************************************************
 *
 * \par Function Name: rpttpl_create
 *
 * \par Create a new report template.
 *
 * * \retval !NULL - The created report template.
 *            NULL - Error.
 *
 * \param[in]  id   The identifier for the template
 * \param[in]  items The items that comprise the template.
 *
 * \par Notes:
 *  1. Only 256 parameters per report entry are supported.
 *  2. Elements shallow copied in.
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  01/09/18  E. Birrane     Initial implementation.
 *  09/28/18  E. Birrane     Updated to AMP V0.5
 *****************************************************************************/

rpttpl_t* rpttpl_create(ari_t *id, ac_t items)
{
	rpttpl_t *result = NULL;

	CHKNULL(id);

	if((result = (rpttpl_t *) STAKE(sizeof(rpttpl_t))) == NULL)
	{
		AMP_DEBUG_ERR("rpttpl_create","Can't allocate %d bytes.", sizeof(rpttpl_t));
		return NULL;
	}

	result->id = id;
	result->contents = items;

	return result;
}


rpttpl_t* rpttpl_deserialize_ptr(CborValue *it, int *success)
{
	rpttpl_t *result = NULL;
	ari_t *ari = NULL;
	ac_t new_ac;

	CHKNULL(success);
	*success = AMP_FAIL;

	CHKNULL(it);

	ari = ari_deserialize_ptr(it, success);
	if((ari == NULL) || (*success != AMP_OK))
	{
		return NULL;
	}

	new_ac = ac_deserialize(it, success);
	if(*success != AMP_OK)
	{
		ari_release(ari, 1);
		return NULL;
	}

	if(((result = rtptpl_create(ari, new_ac))) == NULL)
	{
		*success = AMP_FAIL;
		ari_release(ari, 1);
		ac_clear(&new_ac);
		return NULL;
	}

	*success = AMP_OK;
	return result;
}

rpttpl_t* rpttpl_deserialize_raw(blob_t *data, int *success)
{
	CborParser parser;
	CborValue it;

	CHKNULL(success);
	*success = AMP_FAIL;
	CHKNULL(data);

	if(cbor_parser_init(data->value, data->length, 0, &parser, &it) != CborNoError)
	{
		return NULL;
	}

	return rpttpl_deserialize_ptr(&it, success);
}



/******************************************************************************
 *
 * \par Function Name: rpttpl_release
 *
 * \par Release resources associated with a report template.
 *
 * \param[in|out]  rpttpl  The template to be released.
 *
 * \par Notes:
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  01/09/18  E. Birrane     Initial implementation.
 *  09/29/18  E. Birrane     Updated to match release pattern.
 *****************************************************************************/

void rpttpl_release(rpttpl_t *rpttpl, int destroy)
{
	CHKVOID(rpttpl);

	ari_release(rpttpl->id, 1);
	ac_clear(&(rpttpl->contents));

	if(destroy)
	{
		SRELEASE(rpttpl);
	}
}



CborError rpttpl_serialize(CborEncoder *encoder, rpttpl_t *rpttpl)
{
	CborError err;
	blob_t *result;
	int success;

	CHKUSR(encoder, CborErrorIO);
	CHKUSR(rpttpl, CborErrorIO);

	/* Step 1: Encode the ARI. */
	result = ari_serialize_wrapper(rpttpl->id);
	err = blob_serialize(encoder, result);
	blob_release(result, 1);

	CHKUSR(((err != CborNoError) && (err != CborErrorOutOfMemory)), err);

	/* Step 2: Encode the type. */
	result = ac_serialize_wrapper(&(rpttpl->contents));
	err = blob_serialize(encoder, result);
	blob_release(result, 1);

	return err;
}



blob_t*   rpttpl_serialize_wrapper(rpttpl_t *rpttpl)
{
	return cut_serialize_wrapper(RPTTPL_DEFAULT_ENC_SIZE, rpttpl, rpttpl_serialize);
}

