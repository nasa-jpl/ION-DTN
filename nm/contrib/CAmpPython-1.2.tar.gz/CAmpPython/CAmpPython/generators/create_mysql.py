# JHU/APL
# Description: creates mysql scripts to populate the manager database.
# If there is also a setup.mysql script in the output directory, this
# generator will attempt to add the 'source' command for the generated
# file to the setup.mysql script.
#
# Modification History:
#   YYYY-MM-DD   AUTHOR         DESCRIPTION
#   ----------   ------------   ---------------------------------------------
#   2020-11-19   Sarah Helble    Full Re-write for updated SQL schema
#
##################################################################### 

import re
import datetime
import os

from lib.common import camputil as cu
from lib.common.camputil import  Retriever
from lib.common import campsettings as cs

######################################################################
# Helper Functions for the main write_*_functions() method
# TODO: Move broadly-useful helper functions to camputils

# Returns the first half of the namespace
def get_highlevel_ns(retriever):
	ns = retriever.get_ns()
	return ns.split('/')[0].lower()

# Escape single quotes in a string (to clean SQL input)
# TODO: Currently only used on descriptions; should update to escape all strings
# TODO: switch to using a library to sanitize input more fully
def escape_description_sql(string):
	return string.replace("'","''")

# Returns the definition id variable name for the passed ari
# uses only a substring of the passed ari, splitting it at the
# first instance of an underscore. This is in order to help keep
# variable names under 64 characters for SQL.
# ari_str : string representation of the ARI
def make_def_id_from_ari(ari):
	# Need to shorten because SQL variables have to be < 64 chard
	first_underscore = ari.find("_")
	if(first_underscore != -1):
		ari = ari[first_underscore+1:]
	
	def_id = "@" + ari + "_did"

	if len(def_id) > 64:
		print "[ ERROR ] Auto-generated SQL variable is longer than 64 characters ("+str(len(def_id))+"): "+ def_id
	return def_id

# Returns a tuple of the (object id, definition id) for a given object
# IDs are similar to ARI strings in c/h code, but use only a substring of
# the ari, splitting it at the first instance of an underscore. This is
# in order to help keep variable names under 64 characters for SQL.
# Retriever: retriever object populated with this ADM
# coll: collection of the item (EDD, VAR, etc.)
# item: object to make the IDs for
def make_mysql_ids(retriever, coll, item):
	ns = retriever.get_ns()
	ari = cu.make_ari_name(ns, coll, item).lower()

	def_id = make_def_id_from_ari(ari)

	# Need to shorten because SQL variables have to be < 64 chard
	first_underscore = ari.find("_")

	if(first_underscore != -1):
		ari = ari[first_underscore+1:]

	obj_id = "@" + ari

	if len(obj_id) > 64:
		print "[ ERROR ] Auto-generated SQL variable is longer than 64 characters ("+str(len(obj_id))+"): "+ obj_id

	return obj_id, def_id

# Makes and returns a  string that will properly link
# all "uses" files from the ADM to the generated sql file
# retriever is a Retriever object loaded with the ADM
def make_uses_str(retriever):
	uses = retriever.get_uses()

	formatted_uses = [f.lower().replace("/", "_") for f in uses]
	files = ["use adm_{};\n".format(f) for f in formatted_uses]

	return "".join(files)

# Helper function for SP__insert_obj_metadata template creation
# retriever is the retriever object loaded with the ADM
# obj_type is the type of the object (EDD, VAR, etc.)
# Returns template, which should be formatted with name of the object and id of the object
def create_insert_obj_metadata_template(retriever, obj_type):
	# format with 0=object type enum, 1={} (to be filled by caller), 2=highlevel namespace, 3={} (to be filled by caller)
	general_template = "CALL SP__insert_obj_metadata({0}, '{1}', @{2}_namespace_id, {3});\n"
	
	highlevel_ns = get_highlevel_ns(retriever)

	# convert to object type enumeration to decimal for function
	obj_type_enum = str(int(cs.ari_type_enum(obj_type), 16))

	return general_template.format(obj_type_enum, "{}", highlevel_ns, "{}")


# Helper function for the parmspec entry template
# description is description format for the entries (default is '{}')
# Returns a tuple of the (insert_formal_parmspec function template, insert_formal_parmspec_entry function template)
# Format the former with number of parmspec, fp_id, format the latter with fp_id, enum of the entry, entry name, entry type
def create_insert_formal_parmspec_templates(desc_template="{}"):
	basic_template = "CALL SP__insert_formal_parmspec({}, '{}', {});\n"
	entry_template = "CALL SP__insert_formal_parmspec_entry({}, {}, '{}', '{}', null, @r_fp_ent);\n"
	return basic_template.format("{}", desc_template, "{}"), entry_template

# Helper function for insert_tnvc_collection template and insert_tnvc_entry template
# obj_type is the type of object in the collection (OP, etc.)
# Returns tuple of (insert_tnvc_collection template, insert_tnvc_entry_template, insert_tnvc_unk_entry_template)
# Format the first with description, the second with entry type, and argument fields, the third with argument fields
def create_insert_tnvc_templates(obj_type):
	obj_type_str = cs.get_sname(obj_type).lower()
	collection_template = "CALL SP__insert_tnvc_collection('{}', @{}_tnvc_id);\n"
	collection_template = collection_template.format("{}", obj_type_str)

	# XXX: unsure how useful this is, because only one {} is formatted here, rest are left for user. 
	entry_template = "CALL SP__insert_tnvc_{0}_entry(@{1}_tnvc_id, {0}, {0}, null, @tnvc_entry{0});\n"
	entry_template = entry_template.format("{}", obj_type_str)

	# One fewer argument than all other insert_tnvc_.*_entry() functions 
	unk_entry_template = "CALL SP__insert_tnvc_unk_entry(@{1}_tnvc_id, {0}, null, @tnvc_entry{0});\n"
	unk_entry_template = unk_entry_template.format("{}", obj_type_str)
	
	return collection_template, entry_template, unk_entry_template

# Helper function for insert_ac functions
# obj_type is the type of object (OP, MACRO, etc.)
# description_format is any formatting you wish to impose on the description
# Returns template for insert_ac_id function, format with number of acs and the description
def create_insert_ac_id_template(obj_type, description_format="{}"):
	function_template = "CALL SP__insert_ac_id({0}, '{1}', {2});\n"
	obj_id_template = "@{}_ac_id"

	obj_type_str = cs.get_lname(obj_type).lower()
	obj_id = obj_id_template.format(obj_type_str)

	return function_template.format("{}", description_format, obj_id)

# Returns a tuple of the (definition id, object id) of the passed postfix object
# retriever: a Retriever object loaded with the ADM
# p: the postfix-expr list entry from the ADM
def make_postfix_ids(retriever, p):
	ari_str = retriever.pfx_get_ari(p).lower()
	def_id = make_def_id_from_ari(ari_str)
	obj_id = def_id[:def_id.find("_did")]	
	return def_id, obj_id

# Returns a tuple of the (definition id,object id) of the passed definition object
# retriever: a Retriever object loaded with the ADM
# d: the definition list entry from the ADM
def make_definition_ids(retriever, d):
	def_id, obj_id = make_postfix_ids(retriever, d)
	return def_id, obj_id

# Returns the fp id, given the passed string representing the
# id of the object.
# obj_id: string representation of the definition id of an object
def make_fp_id(obj_id):
	return obj_id + "_fp"


##################################################################################
# Functions to format and write stored procedures to the SQL file based on the ADM

# Writes the introductory material for the sql file:
# file header comments and sets the adm enum
def write_setup(sql_file, filepath, retriever, nn):
	header_template = (
		"-- -------------------------------------------------------------------\n"
		"--\n"
		"-- File Name: {0}\n"
		"--\n"
		"-- Description: TODO\n"
		"--\n"
		"-- Notes: TODO\n"
		"--\n"
		"-- Assumptions: TODO\n"
		"--\n"
		"-- Modification History: \n"
		"-- YYYY-MM-DD    AUTHOR          DESCRIPTION\n"
		"-- ----------    --------------  ------------------------------------\n"
		"-- {1}    AUTO            Auto-generated SQL file \n"
		"--\n"
		"-- -------------------------------------------------------------------\n")

	sql_file.write(header_template.format(os.path.basename(filepath), str(datetime.datetime.now().date())))

	uses_str = make_uses_str(retriever)
	
	adm_template = "# ADM: '{}'\n"
	
	includes_string = "use amp_core;\n\n"
	includes_string = includes_string + uses_str + "\n"
	
	enum_template = "SET @adm_enum = {};\n"

	ns = retriever.get_ns()
	sql_file.write(adm_template.format(ns) + includes_string + enum_template.format(nn))
	

	
# Writes the necessary stored procedures for the ADM metadata
def write_metadata_function(sql_file, retriever):
	highlevel_ns = get_highlevel_ns(retriever)
	# format with org, namespace, version, name, description from namespace, ns from get_highlevel_ns
	meta_template = "CALL SP__insert_adm_defined_namespace('{}', '{}', '{}', '{}', @adm_enum, NULL, '{}', @{}_namespace_id);\n\n"

	name, ns, version, org = retriever.get_mdat_values()
	
	desc = escape_description_sql(retriever.get_metadata()[1]['description'])
	
	sql_file.write(meta_template.format(org, ns, version, name, desc, highlevel_ns))


# Writes the necessary stored procedures for all of the EDDs in the ADM
# sql_file: is the file descriptor to write to
# retriever: Retriever object loaded with the ADM
def write_edd_functions(sql_file, retriever):
	edds = retriever.get_edds()
	sql_file.write("-- #EDD\n")

	insert_obj_template = create_insert_obj_metadata_template(retriever, cs.EDD)
	insert_formal_parmspec_template, insert_entry_template = create_insert_formal_parmspec_templates("parms for {}")
	
	# Format with edd obj id, edd description, edd type, edd def id
	edd_formal_def_template = "CALL SP__insert_edd_formal_definition({}, '{}', {}, '{}', {});\n"

	# Format with edd obj id and edd name (only used if no parmspec)
	edd_actual_def_template = "CALL SP__insert_edd_actual_definition({0}, 'The singleton value for {1}', NULL, {0}_aid);\n\n"
	
	for i, edd in enumerate(edds):
		edd_obj_id, edd_def_id = make_mysql_ids(retriever, cs.EDD, edd)
		edd_fp_id = make_fp_id(edd_obj_id)
		
		name = edd['name']
		etype = edd['type']
		desc = escape_description_sql(edd['description'])
		parmspec = retriever.item_get_parms(edd)
		num_parmspec = len(parmspec)

		edd_string = insert_obj_template.format(name, edd_obj_id)

		if num_parmspec > 0:
			edd_string = edd_string + insert_formal_parmspec_template.format(num_parmspec, name, edd_fp_id)

		for j, p in enumerate(parmspec):
			edd_string = edd_string + insert_entry_template.format(edd_fp_id, j+1, p['name'], p['type'])

		# Only put actual definition here if no parmspec 
		if num_parmspec == 0:
			edd_string = edd_string + edd_formal_def_template.format(edd_obj_id, desc, "NULL", etype, edd_def_id)
			edd_string = edd_string + edd_actual_def_template.format(edd_obj_id, name)
		else:
			edd_string = edd_string + edd_formal_def_template.format(edd_obj_id, desc, edd_fp_id, etype, edd_def_id) + "\n"

		sql_file.write(edd_string)

# Writes the necessary stored procedures for all of the OPs in the ADM
# sql_file: is the file descriptor to write to
# retriever: Retriever object loaded with the ADM	
def write_op_functions(sql_file, retriever):
	ops = retriever.get_operators()
	sql_file.write("-- #OPER\n")
	
	oper_template = create_insert_obj_metadata_template(retriever, cs.OP)
	tnvc_collection_template,tnvc_entry_template,tnvc_unk_entry_template = create_insert_tnvc_templates(cs.OP)

	# format with formatted obj_id, description, result-type, number of parameters, formatted opr_def_id_template
	actual_def_template = "CALL SP__insert_operator_actual_definition({}, '{}', '{}', {}, @op_tnvc_id, {});\n\n"

	for i, oper in enumerate(ops):
		# TODO: Should be able to call the retriever to get this data instead
		# of calling into the JSON itself -- add a function to the retriever for this
		oper_name = oper['name']
		oper_desc = escape_description_sql(oper['description'])
		in_types = retriever.item_get_in_types(oper)
		result_type = oper['result-type']

		oper_obj_id, oper_def_id = make_mysql_ids(retriever, cs.OP, oper)

		oper_string = oper_template.format(oper_name, oper_obj_id)
		oper_string = oper_string + tnvc_collection_template.format("operands for "+ oper_name)
		
		for j, t in enumerate(in_types) :
			t = t.lower()
			
			# UNK has one fewer parameter
			if t == "unk":
				oper_string = oper_string + tnvc_unk_entry_template.format(j+1, j+1)
			else:
				oper_string = oper_string + tnvc_entry_template.format(t.lower(), j+1, "null", j+1)

		# TODO: UNK is not a valid type, comment the actual_def for this out for now until ADM resolved
		if result_type == 'UNK':
			oper_string = oper_string + "-- " + actual_def_template.format(oper_obj_id, oper_desc, result_type, len(in_types), oper_def_id)
		else:
			oper_string = oper_string + actual_def_template.format(oper_obj_id, oper_desc, result_type, len(in_types), oper_def_id)

		sql_file.write(oper_string)

# Writes the necessary stored procedures for all of the VARs in the ADM
# sql_file: is the file descriptor to write to
# retriever: Retriever object loaded with the ADM	
def write_var_functions(sql_file, retriever):
	var_list = retriever.get_variables()
	sql_file.write("\n-- #VAR\n")

	ac_comment = "-- create ac for expression\n"

	var_template = create_insert_obj_metadata_template(retriever, cs.VAR)
	insert_ac_id_template = create_insert_ac_id_template(cs.VAR, "ac for the expression used by {}")
	
	# format with entry id, enumeration of entry in this var
	insert_actual_entry_template = "CALL SP__insert_ac_actual_entry(@var_ac_id, {0}, {1}, @r_ac_entry_id_{1} );\n"

	# format with var id, description, var def id
	# TODO: should be encoding the out type of the variable instead of passing hardcoded '20' for all
	var_def_template = "CALL SP__insert_variable_definition({}, '{}', 20, @var_ac_id, {});\n"
	
	for i, var in enumerate(var_list):
		var_name = var['name']
		var_desc = escape_description_sql(var['description'])
		postfix = retriever.item_get_postfix(var)

		var_id, var_def_id = make_mysql_ids(retriever, cs.VAR, var)
		
		var_str = ac_comment + insert_ac_id_template.format(len(postfix), var_id)
		
		for j, p in enumerate(postfix):
			pfx_def_id,_ = make_postfix_ids(retriever, p)
			var_str = var_str + insert_actual_entry_template.format(pfx_def_id, j+1)
			
		var_str = var_str + var_template.format(var_name, var_id)
		var_str = var_str + var_def_template.format(var_id, var_desc, var_def_id)

		sql_file.write(var_str)
	

# Writes the necessary stored procedures for all of the TBLTs in the ADM
# sql_file: is the file descriptor to write to
# retriever: Retriever object loaded with the ADM	
def write_tblt_functions(sql_file, retriever):
	tblts = retriever.get_tables()
	sql_file.write("\n-- #TBLT\n")

	insert_obj_template = create_insert_obj_metadata_template(retriever, cs.TBLT)
	add_tnvc_coll_template,insert_column_template,_ = create_insert_tnvc_templates(cs.TBL)

	# Format with table object id (above), table description, tblt definition id
	insert_def_template = "CALL SP__insert_table_template_actual_definition({}, '{}', @tbl_tnvc_id, {});\n"

	for i, t in enumerate(tblts):
		tblt_name = t["name"]
		tblt_desc = escape_description_sql(t["description"])			

		tblt_id, tblt_def_id = make_mysql_ids(retriever, cs.TBLT, t)
		
		table_str = insert_obj_template.format(tblt_name, tblt_id)
		table_str = table_str + add_tnvc_coll_template.format('columns for the '+tblt_name+' table')

		columns = retriever.item_get_columns(t)
		for j, c in enumerate(columns):
			table_str = table_str + insert_column_template.format(c["type"].lower(), j+1, "'"+c["name"]+"'", "")

		table_str = table_str + insert_def_template.format(tblt_id, tblt_desc, tblt_def_id) + "\n"

		sql_file.write(table_str)


# Helper function to handle creation of stored procedures for the
# fps and aps within the reports templates in the ADM
# retriever: Retriever object loaded with the ADM
# d: definition object to produce the stored procedures for
# Returns a string that is a concatenation of all of the stored
# procedures necessary for the definition's aps and fps, to be
# written to the SQL file by the caller. 
def handle_report_fp_ap(retriever, d):
	ret_str = ""
	meta_id_template = "@p_lit_meta_{0}_id"
	actual_id_template = "@r_lit_{0}_id"

	# Format with def_id, enumeration, description
	insert_actual_parmspec_template = "\nCALL SP__insert_actual_parmspec({}, {}, '{}', @ap_spec_id);\n"
	
	# format with value, meta_id
	insert_obj_metadata_template = create_insert_obj_metadata_template(retriever, cs.LIT).format("Literal value {}", '{}')
	
	# Format with meta_id, value, type, actual id
	insert_actual_def_template = "CALL SP__insert_literal_actual_definition({}, '{}', '{}', '{}', {});\n".format("{0}", "literal value {1}", '{2}', '{1}','{3}')

	# Format with enumeration, type, actual_id
	insert_actual_parms_obj_template = "CALL SP__insert_actual_parms_object(@ap_spec_id, {}, '{}', {});\n"

	# Format with coll, obj_id, enum
	# TODO: This likely only works for edd.. do we need it for other object types? 
	insert_coll_actual_def_template = "CALL SP__insert_{0}_actual_definition({1}, NULL, @ap_spec_id, {2}_aid_{3}_{4});\n"

	# Formal with enumeration, type, fp_spec_id
	insert_actual_name_template = "CALL SP__insert_actual_parms_names(@ap_spec_id, {}, '{}', {});\n"
	
	def_id,obj_id = make_definition_ids(retriever, d)
	fp_id = make_fp_id(obj_id)
	_,def_coll,def_name = retriever.def_get_names(d)

	# get types of params
	types = retriever.def_get_params_types(d)

	####### Handle aps
	ap = retriever.def_get_ap(d)
	fp_spec_id = "@fp_spec_id"
	if ap:
		formal_parmspec_template, fp_entry_template = create_insert_formal_parmspec_templates("parms for {}")
		num_ap = len(ap)
		
		ret_str = ret_str + formal_parmspec_template.format(num_ap, def_name, fp_spec_id)
		for i, a in enumerate(ap):
			enum = i+1
			a_type = types[i]
			
			ret_str = ret_str + fp_entry_template.format(fp_spec_id, enum, def_name, a_type)
			ret_str = ret_str + insert_actual_parmspec_template.format(def_id, enum, '')
			ret_str = ret_str + insert_actual_name_template.format(enum, a_type, fp_spec_id)
			ret_str = ret_str + insert_coll_actual_def_template.format(cs.get_sname(def_coll).lower(), def_id, obj_id, a['value'].lower(), enum)


	####### Handle fps
	fp = retriever.def_get_fp(d)
	fp_spec_id = "@fp_spec_id"
	
	if not fp:
		return ret_str

	# For each fp
	for i, p in enumerate(fp):
		lit_meta_id = meta_id_template.format(p)
		lit_actual_id = actual_id_template.format(p)
		enum = i+1
		p_type = types[i]

		ret_str = ret_str + insert_actual_parmspec_template.format(fp_id, enum, "actual parms for "+def_name+" passed "+p)

		ret_str = ret_str + insert_obj_metadata_template.format(p, lit_meta_id)
		ret_str = ret_str + insert_actual_def_template.format(lit_meta_id, p, p_type, lit_actual_id)
		ret_str = ret_str + insert_actual_parms_obj_template.format(enum, p_type, lit_actual_id)
		ret_str = ret_str + insert_coll_actual_def_template.format(cs.get_sname(def_coll).lower(), def_id, obj_id, enum, p)

	return ret_str

# Writes the necessary stored procedures for all of the RPTTs in the ADM
# sql_file: is the file descriptor to write to
# retriever: Retriever object loaded with the ADM			
def write_rptt_functions(sql_file, retriever):
	rptts = retriever.get_reports()
	sql_file.write("\n-- #RPTT\n")

	insert_report_template = "\n"+create_insert_ac_id_template(cs.RPTT, "ac for report template {}")
	insert_obj_template = create_insert_obj_metadata_template(retriever, cs.RPTT)
	
	# Format with entry id name and enum of entry
	insert_entry_template = "CALL SP__insert_ac_actual_entry(@rptt_ac_id, {0}, {1}, @r_ac_rpt_entry_{1});\n"

	# Format with report id, report description, report_def_id
	insert_formal_def_template = "\nCALL SP__insert_report_template_formal_definition({}, '{}', null, @rptt_ac_id, {});\n"

	# Format with report id, report name
	insert_actual_def_template = "CALL SP__insert_report_actual_definition({0}, null, null, 'Singleton value for {1}', {0}_aid);\n"

	for i, r in enumerate(rptts):
		report_name = r["name"]
		report_desc = escape_description_sql(r["description"])
		definitions = retriever.item_get_def(r)
		num_definitions = len(definitions)

		report_id, report_def_id = make_mysql_ids(retriever, cs.RPTT, r)

		report_str =  "\n"+ insert_obj_template.format(report_name, report_id)

		after_report_str = ""
		# For each definition in the rptt template
		for j, d in enumerate(definitions):
			report_str = report_str + handle_report_fp_ap(retriever, d)
			definition_id,_ = make_definition_ids(retriever, d)

			# Keeping this in a separate string because it has to happen
			# after all of the calls to handle_report_fp_ap()
			after_report_str = after_report_str + insert_entry_template.format(definition_id, j+1)

		report_str = report_str + insert_report_template.format(num_definitions, report_name)
		report_str = report_str + after_report_str
		
		report_str = report_str + insert_formal_def_template.format(report_id, report_desc, report_def_id)
		report_str = report_str + insert_actual_def_template.format(report_id, report_name)

		sql_file.write(report_str)


# Writes the necessary stored procedures for all of the CTRLs in the ADM
# sql_file: is the file descriptor to write to
# retriever: Retriever object loaded with the ADM			
def write_ctrl_functions(sql_file, retriever):
	ctrls = retriever.get_controls()
	sql_file.write("\n-- #CTRL\n")

	insert_obj_template = create_insert_obj_metadata_template(retriever, cs.CTRL)
	insert_formal_parmspec_template,insert_entry_template = create_insert_formal_parmspec_templates("parms for the {} control")
	
	# Format with ctrl id, ctrl description, fp_spec_id or null, ctrl definition id
	insert_ctrl_formal_def_template = "CALL SP__insert_control_formal_definition({} , '{}', {}, {});\n\n"

	for i, c in enumerate(ctrls):
		ctrl_name = c['name']
		ctrl_desc = escape_description_sql(c['description'])
		parmspec = retriever.item_get_parms(c)
		num_parmspec = len(parmspec)
		
		ctrl_id, ctrl_def_id = make_mysql_ids(retriever, cs.CTRL, c)
		fp_spec_id = "null"
		ctrl_str = insert_obj_template.format(ctrl_name, ctrl_id)
		
		if num_parmspec > 0:
			fp_spec_id = "@fp_spec_id"
			ctrl_str = ctrl_str + insert_formal_parmspec_template.format(num_parmspec, ctrl_name, fp_spec_id)
			for j, p in enumerate(parmspec):
				ctrl_str = ctrl_str + insert_entry_template.format(fp_spec_id, j+1, p['name'], p['type'])

		ctrl_str = ctrl_str + insert_ctrl_formal_def_template.format(ctrl_id, ctrl_desc, fp_spec_id, ctrl_def_id)

		sql_file.write(ctrl_str)


# Helper function for the META and CONST objects to allow
# code reuse since they use the same stored procedures.
#
# Writes the necessary stored procedures for all of the passed objects.
#
# sql_file: the file descriptor to write to
# retriever: Retriever object loaded with the ADM
# objects: list of objects (CONSTs or METAs) to write the stored procedures for
# coll: type of collection (cs.CONST or cs.META)
def write_gen_const_functions(sql_file, retriever, objects, coll):
	insert_obj_template = create_insert_obj_metadata_template(retriever, coll)

	# Format with const id, definition, type, value, and const def id
	insert_const_actual_def_template = "CALL SP__insert_const_actual_definition({}, '{}', '{}', '{}', {});\n\n"
	for i, c in enumerate(objects):
		c_name = c['name']
		c_desc = escape_description_sql(c['description'])

		const_id, const_def_id = make_mysql_ids(retriever, coll, c)
		const_str = insert_obj_template.format(c_name, const_id)
		
		const_str = const_str + insert_const_actual_def_template.format(const_id, c_desc, c['type'], c['value'], const_def_id)

		sql_file.write(const_str)


# Writes the necessary stored procedures for all of the CONSTs in the ADM
# sql_file: is the file descriptor to write to
# retriever: Retriever object loaded with the ADM			
def write_const_functions(sql_file, retriever):
	sql_file.write("\n-- #CONST\n")
	write_gen_const_functions(sql_file, retriever, retriever.get_constants(), cs.CONST)

# Writes the necessary stored procedures for all of the METAs in the ADM
# sql_file: is the file descriptor to write to
# retriever: Retriever object loaded with the ADM			
def write_meta_functions(sql_file, retriever):
	sql_file.write("\n-- #META\n")
	write_gen_const_functions(sql_file, retriever, retriever.get_metadata(), cs.META)


# Writes the necessary stored procedures for all of the MACROs in the ADM
# sql_file: is the file descriptor to write to
# retriever: Retriever object loaded with the ADM			
def write_mac_functions(sql_file, retriever):
	macs = retriever.get_macros()
	sql_file.write("\n-- #MAC\n")

	insert_obj_template = create_insert_obj_metadata_template(retriever, cs.MACRO)
	insert_formal_parmspec_template, insert_ac_formal_parmspec_entry_template = create_insert_formal_parmspec_templates("parms for the {} macro")
	insert_ac_id_template = create_insert_ac_id_template(cs.MACRO, "ac for {} macro")
	
	# Format with def id, def enumeration in this macro
	insert_ac_formal_entry_template = "CALL SP__insert_ac_formal_entry(@mac_ac_id, {}, {}, @r_ac_entry_id);\n"

	# Format with mac id, description, fp_spec_id, number of parmspec (?), and mac def id
	insert_mac_formal_def_template = "\nCALL SP__insert_macro_formal_definition({}, '{}', {}, {}, @mac_ac_id, {});\n"

	for i, m in enumerate(macs):
		mac_name = m['name']
		mac_desc = escape_description_sql(m['description'])
		definitions = retriever.item_get_def(m)
		parmspec = retriever.item_get_parms(m)
		num_parmspec = len(parmspec)

		mac_id, mac_def_id = make_mysql_ids(retriever, cs.MACRO, m)
		mac_str = insert_obj_template.format(mac_name, mac_id)
		fp_spec_id = "null"

		if num_parmspec > 0:
			fp_spec_id = "@fp_spec_id"
			mac_str = mac_str + insert_formal_parmspec_template.format(num_parmspec, mac_name, fp_spec_id)
			for j, p in enumerate(parmspec):
				mac_str = mac_str + insert_ac_formal_parmspec_entry_template.format(fp_spec_id, j+1, p['name'], p['type'])

		if num_parmspec > 0:
			mac_str = mac_str + insert_ac_id_template.format(num_parmspec, mac_name)

		for j, d in enumerate(definitions):
			def_id,_ = make_definition_ids(retriever, d)
			mac_str = mac_str + insert_ac_formal_entry_template.format(def_id, j+1)

		mac_str = mac_str + insert_mac_formal_def_template.format(mac_id, mac_desc, fp_spec_id, num_parmspec, mac_def_id)

		sql_file.write(mac_str)

# If the setup.mysql file exists in the output dir, and this
# file is not already sourced in the setup script, add it to
# the file. 
# setup_path: full expected path to the setup script
# rel_path: relative path of the new sql file to add (path from setup script)
def add_to_setup_mysql(setup_path, rel_path_sql):
	line_to_add = "\nsource " + rel_path_sql 

	# If the file doesn't exist, do nothing
	if (not os.path.exists(setup_path)):
		return

	print "\tAttempting to add SQL file to " + setup_path + " ...",

	try:
		for line in open(setup_path, "r"):
			if line.find(rel_path_sql) != -1:
				print "\n\t\t"+rel_path_sql + " already present in setup.mysql, skipping."
				return

		# Didn't find the file already sourced in the setup.mysql file, add it

		setup_file = open(setup_path, 'a')
		setup_file.write(line_to_add)
		setup_file.close()			

		print "[ DONE ]"
		
	except Exception, e:
		print e
		return
			
	

#
# Main function for the program. orchestrates calling all helper
# functions to generate the .sql file.
# retriever is a retriever object loaded with the JSON data,
# outpath is the directory for output.
# nn is the nickname of the ADM
#
def create(retriever, outpath, nn):
	try:
		name,_ = retriever.get_adm_names()
	except KeyError, e:
		print "[Error] JSON does not include valid metadata"
		print e
		return

	filename, sql_file = cu.initialize_file(outpath, "/mysql/Agent_Scripts", name, ".sql")

	if not sql_file:
		return
	
	print "Working on ",filename,

	try:
		write_setup(sql_file, filename, retriever, nn)
		write_metadata_function(sql_file, retriever)
		
		write_meta_functions(sql_file, retriever)
		write_edd_functions(sql_file, retriever)
		write_op_functions(sql_file, retriever)
		write_var_functions(sql_file, retriever)
		write_tblt_functions(sql_file, retriever)
		write_rptt_functions(sql_file, retriever)
		write_ctrl_functions(sql_file, retriever)
		write_const_functions(sql_file, retriever)
		write_mac_functions(sql_file, retriever)
		
	except KeyError, e:
		return

	except Exception, e:
	        return

	finally:
		sql_file.close()
		
	print "\t[ DONE ]"

	# Try to add the generated SQL file to the setup.mysql script, if it exists in the output dir
	try:
		add_to_setup_mysql(outpath + "/mysql/setup.mysql", "Agent_Scripts/"+os.path.basename(filename))
	except Exception, e:
	        return

