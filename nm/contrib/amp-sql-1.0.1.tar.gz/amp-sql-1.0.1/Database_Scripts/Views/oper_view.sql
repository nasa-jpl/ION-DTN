use amp_core;
CREATE OR REPLACE VIEW `vw_oper_actual` AS
    SELECT 
        obj_metadata.obj_metadata_id,
        obj_name,
        namespace_id,
        obj_actual_definition_id,
       obj_metadata.data_type_id,
        num_operands,
        tnvc_id,
        use_desc
    FROM
        obj_metadata
            JOIN
        (SELECT 
            obj_actual_definition.obj_actual_definition_id,
                obj_metadata_id,
                use_desc,
                data_type_id,
                num_operands,
                tnvc_id
        FROM
            obj_actual_definition
        JOIN operator_actual_definition ON operator_actual_definition.obj_actual_definition_id = obj_actual_definition.obj_actual_definition_id) join2 ON join2.obj_metadata_id = obj_metadata.obj_metadata_id;

 