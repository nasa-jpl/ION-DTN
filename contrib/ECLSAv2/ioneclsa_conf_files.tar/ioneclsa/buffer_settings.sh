sysctl -w net.core.rmem_max=2621440
sysctl -w net.core.rmem_default=2621440

sysctl -w net.core.wmem_max=2621440
sysctl -w net.core.wmem_default=2621440

sysctl -w net.core.optmem_max=10240
sysctl -w net.ipv4.udp_mem="2621440 2621440 2621440"
sysctl -w net.ipv4.udp_rmem_min=2621440
#sysctl -w net.ipv4.udp_wmem_min=4096
sysctl -w net.ipv4.udp_wmem_min=2621440

echo 50000 > /proc/sys/net/core/netdev_budget
echo 50000 > /proc/sys/net/core/netdev_max_backlog
echo 64001064 >/proc/sys/kernel/shmmax
echo 64001064 >/proc/sys/kernel/shmall
