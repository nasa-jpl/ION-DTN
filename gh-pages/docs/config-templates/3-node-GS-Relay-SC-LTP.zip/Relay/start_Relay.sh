#!/bin/bash
#  FILE:  start_Relay.sh
#  NODE:  Relay [ipn:22]
#  DESC:  Relay ION node on Relay
#  DATE:  2023-11-22T11:22
host=`uname -n`
wdir=`pwd`
echo "Clearing old ion.log"
echo > ion.log
echo "Starting ION node ipn:22 on $host from $wdir"
ionadmin  Relay.ionrc
sleep  1
ionsecadmin  Relay.ionsecrc
sleep  1
ltpadmin  Relay.ltprc
sleep  1
bpadmin  Relay.bpv7rc
sleep  1
# global contact graph
ionadmin  3node-rhel-graph.cg
echo "Startup of ION node ipn:22 on $host complete!"
echo "Starting bpecho on ipn:22.3."
bpecho   ipn:22.3 &
