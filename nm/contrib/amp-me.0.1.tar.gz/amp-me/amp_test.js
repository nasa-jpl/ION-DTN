#!/usr/bin/env node
// TODO: Cleanup

import { CBOR } from "./lib/shared/cbor.js";
import * as AMP from "./lib/shared/amp.js";

// For this test application, we only accept one argument.  Use Yargs library if more complex parsing is needed later
var input = process.argv[2];

if (!input) {
    throw "Error: Expected an input string";
    // TODO: Prompt for input instead
}

var reg = await AMP.Registry.getInstance("lib/shared/adms");
console.log("AMP Parsing Test.  Input: ", input);

/* Parse input URI with named captures for type (prefix), Hex, and remaining URI */
var parts = input.match(/^((?<type>\w+):)?((?<hex>0[xX][\da-fA-F]+)|(?<uri>.*))$/);

if (!parts.groups.type && parts.groups.hex) {
    // CBOR Input
    var hex = parts.groups.hex;
    var obj = new CBOR(hex);
    var log = obj.parse();
    console.log("Decoded CBOR Input.  Trace log is:", log);

    var obj2 = new CBOR();
    for(let i = 0; i < log.length; i++) {
        obj2.encode(log[i].value);
    }
    var hex2 = '0x'+obj2.toString();
    console.log("Re-encoded to " + hex2);
    if (hex != hex2) {
        console.warn("Re-encoded value differs from original");
    }
    
} else if (parts.groups.type && parts.groups.hex) {
    var hex = parts.groups.hex;
    var cbor = new CBOR(hex);
    var type = parts.groups.type;

    // TODO: Should we normalize case of type for consistent parsing?
    var obj;
    AMP.trace.start();

    try {
    
        switch(type) {
        case 'ari':
            obj = new AMP.ARI(cbor);
            break;
        case 'msgs':
            obj = new AMP.MessageGroup(cbor);
            break;
        default:
            throw `ERROR: Unsupported type (${type}) for AMP CBOR decoding`;
        }
        //obj.fromCbor(hex);

        console.log("Decode Tracing Log:", AMP.trace.get());

        if (typeof cbor.bytesRemaining != "number" || cbor.bytesRemaining > 0) {
            console.log(`ERROR: There are ${cbor.bytesRemaining} bytes remaining in buffer after decoding is complete`);
        }
        
        console.log("Output Object: ", JSON.stringify(obj,null,2));

    } catch(err) {
        console.log(`There are ${cbor.bytesRemaining} bytes remaining in buffer after exception`);
        console.log("Decode Tracing Log:", AMP.trace.get());
        console.log(err);
    }

    var outCbor = '0x'+obj.toCbor(new CBOR()).toString();
    console.log("CBOR Re-Encoding", outCbor );
    if (outCbor != hex) {
        console.warn("Possible Parsing Error, Input != Output in CBOR encoding");
    }

    if (obj.toUri) {
        console.log("URI: ", obj.toUri() );
    }
    
} else if (parts.groups.type && parts.groups.uri) {
    console.log("URI Decoding TODO");
} else {
    console.log("ERROR: Invalid/unsupported input");
}
