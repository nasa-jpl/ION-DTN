#!/usr/bin/env node
import * as AMP from "./lib/amp-sql.js";
import yargsInteractive from "yargs-interactive";

const yi_options = {
    interactive: { default: true },
    is_incoming: {
        type: "confirm",
        "describe" : "Is this message incoming (data received from agents)?  Default is outgoing (pending tx to agents)?",
        default: false,
        
    },
    state: {
        type: "input", // TODO: list of ready, pending, error, etc.
        default: "ready",
    },
    agent: {
        type: "input", // TODO: This can be a list with multiple values
        describe: "Agent EID to send message to (or that an incoming message came from), ie: 'ipn:1.2'",
    },
    msg: {
        type: "input", // TODO: This can be a list of one or more messages in URI input form
        describe: "URI Message(s) to send in uri or uri-cbor form. This may be of msgs, msg or ari types",
    },
    timestamp: {
        default: 0,
        type: "number", // Or timestamp?  Depends on intent, since encoding may not always match real timestamp withotu parsing
        describe: "Timestamp for message group"
    }
    // TODO: db connection options
};

await main();

async function main() {
    var cfg = await yargsInteractive()
    .usage("$0 <command> [args]")
        .boolean('is_outgoing').alias('is_outgoing', 'outgoing').alias('no-is_outgoing', 'incoming')
        .alias('timestamp','ts')
    // TODO: Is there a way to define an 'incoming' alias that equates to !outgoing
  .interactive(yi_options);

    
    // TODO: If providing SQL functionality in this test, initialize DB here, AND a transaction

    await AMP.Registry.getInstance("lib/shared/adms");

    var db = await AMP.connectDb(); // todo; cfg options
    console.log("Connection established.  Trying to begin transaction".green);
    await db.beginTransaction(); // Run all tests in a transaction so we can abort if there's ane rror
    AMP.trace.start();

    var grp = new AMP.MessageGroup();
    grp.timestamp = cfg.timestamp;
    
    if (typeof cfg.msg == "string") {
        var obj = AMP.parseUri(cfg.msg);
        if (!obj) {
            throw new Error("Error parsing inputs");
        } else {
            switch(obj.constructor.name) {
            case "MessageGroup":
                grp.messages.push(...obj.messages); // Append all messages in input group to new group
                break;
            case "ARI":
                var msg = new AMP.MessagePerfCtrl();
                msg.ac.ari.push(obj);
                grp.messages.push(msg);
                break;
            case "MessagePerfCtrl":
            case "MessageRegAgent":
            case "MessageRptSet":
            case "MessageTblSet":
                grp.messages.push(obj);
                break;
            default:
                throw new Error(obj.consturctor.name + " is not supported as a message type.");
            }
        }
    } else if (Array.isArray(cfg.msg)) {
        throw new Error("TODO: Parse list of messages");
    }
    var id = await grp.toSql(cfg.agent, !cfg.is_incoming);
    console.log("Created message group with id of ", id);

    // Commit transaction and exit
    await db.commit(); // Or is it awaitCommit?  Should above be awaitBegin? Seems to be working as-is....

    console.log("Done");
    AMP.trace.save();
    db.end();
}
