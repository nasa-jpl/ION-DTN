
## Manager Logging
The table "nm_mgr_log" is provided for logging of debug messages normally output to stderr by the ION NM Manager application.  The types of messages generated are determined by the AMP_DEBUG_LVL that the application was configured with.

This table is not a required part of the AMP database, but is an example of additional implementation-specific information that may be logged with it.  Future implementations may choose to add other companion tables.

### Mgr_log
    - Id - Primary auto-increment key
    - Timestamp
    - Msg varchar
    - Level INT – Nominally matches the value of AMP_DEBUG_LVL
    - Source  – Function or other descriptive name for the source of the error.
    - File - Filename that this message originated from
    - Line - Source line that this message originated from

