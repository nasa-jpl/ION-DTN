/******************************************************************************
 **                           COPYRIGHT NOTICE
 **      (c) 2012 The Johns Hopkins University Applied Physics Laboratory
 **                         All rights reserved.
  ******************************************************************************/

/*****************************************************************************
 **
 ** \file mid.c
 **
 ** Description: This file contains the definitions, prototypes, constants, and
 **              other information necessary for the identification and
 **              processing of DTNMP Managed Identifiers (MIDs).
 **
 ** Notes:
 ** \todo 1. Need to make sure that all serialize and deserialize methods
 **          do regular bounds checking whenever writing and often when
 **          reading.
 **
 ** Assumptions:
 **      1. We limit the size of an OID in the system to reduce the amount
 **         of pre-allocated memory in this embedded system. Non-embedded
 **         implementations may wish to dynamically allocate MIDs as they are
 **         received.
 **
 **
 ** Modification History:
 **  MM/DD/YY  AUTHOR         DESCRIPTION
 **  --------  ------------   ---------------------------------------------
 **  10/21/11  E. Birrane     Code comments and functional updates. (JHU/APL)
 **  10/22/12  E. Birrane     Update to latest version of DTNMP. Cleanup. (JHU/APL)
 **  06/25/13  E. Birrane     New spec. rev. Remove priority from MIDs (JHU/APL)
 **  04/19/16  E. Birrane     Put OIDs on stack and not heap. (Secure DTN - NASA: NNX14CS58P)
 **  08/21/16  E. Birrane     Update to AMP v02 (Secure DTN - NASA: NNX14CS58P)
 *****************************************************************************/

#include "platform.h"

#include "../utils/utils.h"
#include "../utils/nm_types.h"

#include "../primitives/ari.h"



/*
 * +--------------------------------------------------------------------------+
 * |					   Private Functions  								  +
 * +--------------------------------------------------------------------------+
 */


static ari_t p_ari_deserialize_lit(CborValue *it, int *success)
{
	ari_t result;
	uint8_t byte;

	ari_init(&result);

	/* We got here through a peek, so we know this next byte is good. */
	cut_get_cbor_numeric(it, AMP_TYPE_BYTE, &byte);

	result.type = ARI_GET_FLAG_TYPE(byte);
	result.as_lit.type = result.type;

	if(tnv_deserialize_val_by_type(it, &(result.as_lit)) != AMP_OK)
	{
		AMP_DEBUG_ERR("p_ari_deserialize_lit","Can't get ARI literal value.", NULL);
		return ari_null();
	}

	return result;
}



static ari_t p_ari_deserialize_reg(CborValue *it, int *success)
{
	ari_t result;
	uint8_t flags;
	uvast temp;

	ari_init(&result);

	/* We got here through a peek, so we know this next byte is good. */
	*success = cut_get_cbor_numeric(it, AMP_TYPE_BYTE, &flags);

	result.type = ARI_GET_FLAG_TYPE(flags);
	result.as_reg.flags = flags;


	/* Get the nickname, if one exists. */
	if((*success == AMP_OK) && ARI_GET_NN(flags))
	{
		/* Get the UVAST nickname. */
		success = cut_get_cbor_numeric(it, AMP_TYPE_UVAST, &temp);
		vec_uvast_add(g_nn_db, temp, &(result.as_reg.nn_idx));
	}

	/* Get the name. */
	if(*success == AMP_OK)
	{
		result.as_reg.name = blob_deserialize(it, success);
	}

	if((*success == AMP_OK) && ARI_GET_FLAG_PARM(flags))
	{
		result.as_reg.parms = ttnvc_deserialize(it, success);
		if(*success != AMP_OK)
		{
			ari_release(&result, 0);
			return result;
		}
	}

	if((*success == AMP_OK) && ARI_GET_FLAG_ISS(flags))
	{
		/* Get the UVAST nickname. */
		cut_get_cbor_numeric(it, AMP_TYPE_UVAST, &temp);
		vec_uvast_add(g_iss_db, temp, &(result.as_reg.iss_idx));
	}

	if((*success == AMP_OK) && ARI_GET_FLAG_TAG(flags))
	{
		blob_t tag = blob_deserialize(it, success);

		if(*success == AMP_OK)
		{
			*success = vec_blob_add(g_tag_db, tag, &(result.as_reg.tag_idx));
			blob_release(&tag, 0); // TODO avoid this needeless re-alloc.
		}
	}

	if(*success != AMP_OK)
	{
		ari_release(&result, 0);
		return result;
	}

	return result;
}



static CborError p_ari_serialize_lit(CborEncoder *encoder, ari_t *ari)
{
	CborError err;
	uint8_t byte;
	blob_t *result;

	CHKUSR(encoder, CborErrorIO);
	CHKUSR(ari, CborErrorIO);


	byte = (ari->as_lit.type << 4) | (AMP_TYPE_LIT % 0xF);

	err = cut_enc_byte(encoder, byte);
	if((err != CborErrorOutOfMemory) && (err != CborNoError))
	{
		return err;
	}

	if((result = tnv_serialize_value_wrapper(&(ari->as_lit))) == NULL)
	{
		return CborErrorIO;
	}

	err = blob_serialize(encoder, result);

	blob_release(&result, 1);

	return err;
}


static CborError p_ari_serialize_reg(CborEncoder *encoder, ari_t *ari)
{
	CborError err;
	blob_t *result;
	int success;

	CHKUSR(encoder, CborErrorIO);
	CHKUSR(ari, CborErrorIO);

	err = cut_enc_byte(encoder, ari->as_reg.flags);


	CHKUSR(((err != CborNoError) && (err != CborErrorOutOfMemory)), err);

	if(ARI_GET_FLAG_NN(ari->as_reg.flags))
	{
		uvast *nn = (uvast *)vec_at(g_nn_db, ari->as_reg.nn_idx, &success);
		err = (success == AMP_OK) ? cbor_encode_uint(encoder, *nn) : CborErrorIO;
	}

	CHKUSR(((err != CborNoError) && (err != CborErrorOutOfMemory)), err);

	err = blob_serialize(encoder, &(ari->as_reg.name));

	CHKUSR(((err != CborNoError) && (err != CborErrorOutOfMemory)), err);

	if(ARI_GET_FLAG_PARM(ari->as_reg.flags))
	{
		blob_t *result = tnvc_serialize_wrapper(&(ari->as_reg.parms));
		err = blob_serialize(encoder, result);
		blob_release(result, 1);
	}
	CHKUSR(((err != CborNoError) && (err != CborErrorOutOfMemory)), err);

	if(ARI_GET_FLAG_ISS(ari->as_reg.flags))
	{
		uvast *iss = (uvast *)vec_at(g_iss_db, ari->as_reg.iss_idx, &success);
		err = (success == AMP_OK) ? cbor_encode_uint(encoder, *iss) : CborErrorIO;
	}
	CHKUSR(((err != CborNoError) && (err != CborErrorOutOfMemory)), err);

	if(ARI_GET_FLAG_TAG(ari->as_reg.flags))
	{
		result = (blob_t *)vec_at(g_tag_db, ari->as_reg.tag_idx, &success);
		err = blob_serialize(encoder, result);
		blob_release(result, 1);
	}

	return err;
}









/*
 * +--------------------------------------------------------------------------+
 * |					   Public Functions  								  +
 * +--------------------------------------------------------------------------+
 */


/******************************************************************************
 *
 * \par Function Name: ari_add_param
 *
 * \par Adds a parameter to an ARI.
 *
 * \retval Success Value
 *
 * \param[in, out] ari   The ARI receiving the new parameter.
 * \param[in]      parm  The new parameter.
 *
 * \par Notes:
 *		1. The new parameter is deep copied and the passed-in value may be
 *		   released if necessary.
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  11/25/12  E. Birrane     Initial implementation,
 *  04/15/16  E. Birrane     Updated to use blob_t
 *  06/11/16  E. Birrane     Cleanup parameters, use TDC.
 *  09/18/18  E. Birrane     Update to ARI. (JHU/APL)
 *****************************************************************************/
int ari_add_param(ari_t *ari, tnv_t parm)
{
	CHKUSR(ari, AMP_FAIL);
	CHKUSR(ari->type != AMP_TYPE_LIT, AMP_FAIL);
	return tnvc_insert(&(ari->as_reg.parms), &parm);
}


int ari_add_parms(ari_t *ari, tnvc_t *parms)
{
	vec_idx_t idx;
	CHKUSR(ari, AMP_FAIL);
	CHKUSR(parms, AMP_FAIL);

	return tnvc_append(&(ari->as_reg.parms), parms);
}


int ari_cb_comp_fn(void *i1, void *i2)
{
	CHKUSR(i1, -2);
	CHKUSR(i2, -2);

	return ari_compare((ari_t*)i1, (ari_t*)i2);
}

void* ari_cb_copy_fn(void *item)
{
	CHKNULL(item);
	return ari_copy_ptr((ari_t*)item);
}

void ari_cb_del_fn(void *item)
{
	CHKVOID(item);
	ari_release((ari_t*)item, 1);
}

/*
 * Based on sample BKDR hash function provided by
 * http://www.partow.net/programming/hashfunctions/
 */
rh_idx_t  ari_cb_hash(rhht_t ht, void *key)
{
	unsigned int seed = 131; /* 31 131 1313 13131 131313 etc.. */
    unsigned int hash = 0;
	unsigned int i    = 0;

	ari_t *ari = (ari_t*) key;

	CHKUSR(ari, ht.num_bkts);

	for (i = 0; i < sizeof(ari_t); ++ari, ++i)
	{
		hash = (hash * seed) + (*ari);
	}

   return hash % ht.num_bkts;
}



/******************************************************************************
 *
 * \par Function Name: ari_compare
 *
 * \par Determines equivalence of two ARIs.
 *
 * \retval -1   : Error or ari1 < ari2
 * 			0   : ari1 == ari2
 * 			>0  : ari1 > ari2
 *
 * \param[in] ari1      First ari being compared.
 * \param[in] ari2      Second ari being compared.
 * \param[in] use_parms Whether to compare paramaters as well.
 *
 * \par Notes:
 *		1. This function should only check for equivalence (== 0), not order
 *         since we do not differentiate between ari1 < ari2 and error.
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  10/22/12  E. Birrane     Initial implementation,
 *  06/25/13  E. Birrane     Removed references to priority field.
 *  09/18/18  E. Birrane     Update to ARI.
 *****************************************************************************/

int ari_compare(ari_t *ari1, ari_t *ari2, uint8_t use_parms)
{
    AMP_DEBUG_ENTRY("ari_compare","("ADDR_FIELDSPEC","ADDR_FIELDSPEC")",
    		         (uaddr) ari1, (uaddr) ari2);

    CHKUSR(ari1, -1);
    CHKUSR(ari2, -1);

    if(ari1->type != ari2->type)
    {
    	return 1;
    }
    else if(ari1->type == AMP_TYPE_LIT)
    {
    	return tnv_compare(&(ari1->as_lit), &(ari2->as_lit));
    }
    else
    {
    	if( (ari1->as_reg.flags    != ari2->as_reg.flags) ||
    		(ari1->as_reg.iss_idx  != ari2->as_reg.iss_idx) ||
			(ari1->as_reg.nn_idx   != ari2->as_reg.nn_idx) ||
			(ari1->as_reg.tag_idx  != ari2->as_reg.tag_idx))
    	{
    		return 1;
    	}
    	else if(blob_compare(&(ari1->as_reg.name), &(ari2->as_reg.name)))
    	{
    		return 1;
    	}
    	else if(use_parms)
    	{
    		return tnvc_compare(&(ari1->as_reg.parms), &(ari2->as_reg.parms));
    	}
    }

    return 0;
}



/******************************************************************************
 *
 * \par Function Name: ari_copy
 *
 * \par Duplicates an ARI object.
 *
 * \retval The copied ARI.
 *
 * \param[in]  src     The ARI being copied.
 * \param[out] success Whether the copy succeeded.
 *
 * \par Notes:
 *     1. ARI parameters are deep copied.
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  10/22/12  E. Birrane     Initial implementation (JHU/APL)
 *  09/29/18  E. Birrane     Updated to match copy pattern. (JHU/APL)
 *****************************************************************************/

ari_t ari_copy(ari_t val, int *success)
{
    ari_t result;

    /* Shallow copy bulk items. */
    result = val;

    /* Deep copy as needed. */
    if(result.type == AMP_TYPE_LIT)
    {
    	result.as_lit = tnv_copy(val.as_lit, success);
    	if(*success != AMP_OK)
    	{
    		tnv_release(&(result.as_lit), 0);
    	}
    }
    else
    {
    	*success = blob_copy(val.as_reg.name, &(result.as_reg.name));
    	CHKUSR(*success == AMP_OK, result);

    	*success = tnvc_init(&(result.as_reg.parms), tnvc_get_count(val.as_reg.parms));
    	if(*success != AMP_OK)
    	{
    		blob_release(&(val.as_reg.name), 0);
    		return result;
    	}

        *success = tnvc_append(&(result.as_reg.parms), &(val.as_reg.parms));
        if(*success != AMP_OK)
        {
        	blob_release(&(val.as_reg.name), 0);
        	tnvc_release(&(result.as_reg.parms), 0);
        	return result;
        }
    }

    return result;
}


ari_t *ari_copy_ptr(ari_t val)
{
	ari_t *result = ari_create();
	int success;

	CHKNULL(result);

	*result = ari_copy(val, &success);
	if(success != AMP_OK)
	{
		SRELEASE(result); // don't call ari_release here since ari_copy cleans up anyway.
		result = NULL;
	}

	return result;
}



ari_t* ari_create()
{
	return STAKE(sizeof(ari_t));
}


/******************************************************************************
 *
 * \par Function Name: ari_deserialize
 *
 * \par Builds an ARI from a CBOR stream.
 *
 * \retval The deserialized structure.
 *
 * \param[in|out]  it       The CBOR value iterator being read/advanced
 * \param[out]     success  Whether the deserialization succeeded.
 *
 * \par Notes:
 *   - A deserialization error will return  an ARI with unknown type.
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  10/22/12  E. Birrane     Initial implementation,
 *  06/25/13  E. Birrane     Removed references to priority field.
 *  09/18/18  E. Birrane     Move to ARI from MID
 *****************************************************************************/
ari_t ari_deserialize(CborValue *it, int *success)
{
	uint8_t *flag;

    AMP_DEBUG_ENTRY("ari_deserialize","("ADDR_FIELDSPEC","ADDR_FIELDSPEC")", (uaddr)it, (uaddr)success);

    CHKUSR(it, ari_null());
    CHKUSR(success, ari_nulL());

    /* Grab the first byte to see what we've got. */

    if((flag = cbor_value_get_next_byte(it)) == NULL)
    {
    	AMP_DEBUG_ERR("ari_deserialize", "Can't peek at first byte.", NULL);
    	return ari_null();
    }

    if(ARI_GET_FLAG_TYPE(*flag) == AMP_TYPE_LIT)
    {
    	return p_ari_deserialize_lit(it, success);
    }

    return p_ari_deserialize_reg(it, success);
}


ari_t *ari_deserialize_ptr(CborValue *it, int *success)
{
	ari_t *result = ari_create();

	*success = AMP_FAIL;
	CHKNULL(result);

	*result = ari_deserialize(it, success);
	if(success != AMP_OK)
	{
		ari_release(result, 1);
		result = NULL;
	}

	return result;
}



/*
 * Retrieve mid from unsigned long value representing mid in hex
 * 0x31801...
 *
 * 1/5/18
 *
 *to ARI 9/19/18
 */

ari_t*   ari_from_uvast(uvast val)
{
	CborParser parser;
	CborValue it;
	CborError err;
	int success = AMP_FAIL;
	ari_t *result = NULL;

	err = cbor_parser_init((uint8_t *)&val, sizeof(uvast), 0, &parser, &it);
	CHKNULL(err == CborNoError);

	result = ari_deserialize_ptr(it, &success);

	if(*success != AMP_OK)
	{
		ari_release(result, 1);
		result = NULL;
	}

	return result;
}


// Must not fre. Shallow pointer
tnv_t* ari_get_param(ari_t *ari, int i)
{
	CHKNULL(ari);

	if((ari->type == AMP_TYPE_LIT) ||
	   (ARI_GET_FLAG_PARM(ari->as_reg.flags) == 0))
	{
		return NULL;
	}

	return tnvc_get(&(ari->as_reg.parms), i);
}



uint8_t  ari_get_num_parms(ari_t *ari)
{

	CHKZERO(ari);

	if((ari->type == AMP_TYPE_LIT) ||
	   (ARI_GET_FLAG_PARM(ari->as_reg.flags) == 0))
	{
		return NULL;
	}

	return tnvc_get_count(&(ari->as_reg.parms));
}


void ari_init(ari_t *ari)
{
	CHKVOID(ari);
	memset(ari, 0, sizeof(ari_t));
	ari->type = AMP_TYPE_UNK;
}




ari_t ari_null()
{
	static int i = 0;
	static ari_t result;

	if(i == 0)
	{
		ari_init(&result);
		i = 1;
	}
	return result;
}



/******************************************************************************
 *
 * \par Function Name: mid_release
 *
 * \par Purpose: Frees resources associated with a MID
 *
 * \param[in,out] mid  The MID being released.
 *
 * \par Notes:
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  11/14/12  E. Birrane     Initial implementation,
 *  09/18/18  E. Birrane     Move to ARI from MID
 *****************************************************************************/

void ari_release(ari_t *ari, int destroy)
{
	CHKVOID(ari);

	if(ari->type == AMP_TYPE_LIT)
	{
		tnv_release(&(ari->as_lit), 0);
	}
	else
	{
		blob_release(&(ari->as_reg.name), 0);
		tnvc_release(&(ari->as_reg.parms), 0);
	}

	if(destroy)
	{
		SRELEASE(ari);
	}
}


CborError ari_serialize(CborEncoder *encoder, ari_t *ari)
{
	CHKUSR(ari, CborErrorIO);

	if(ari->type == AMP_TYPE_LIT)
	{
		return p_ari_serialize_lit(&encoder, ari);
	}

	return p_ari_serialize_reg(&encoder, ari);
}

blob_t* ari_serialize_wrapper(ari_t *ari)
{
	return cut_serialize_wrapper(ARI_DEFAULT_ENC_SIZE, ari, ari_serialize);
}




/******************************************************************************
 *
 * \par Function Name: ari_to_string
 *
 * \par Purpose: Create a string representation of the ARI.
 *
 * \retval  NULL - Failure
 *         !NULL - The string representation of the raw ARI.
 *
 * \param[in] mid The MID whose string representation is being calculated.
 *
 * \par Notes:
 *		1. The string is dynamically allocated from the memory pool and must
 *		   be deallocated when no longer needed.
 *
 * Modification History:
 *  MM/DD/YY  AUTHOR         DESCRIPTION
 *  --------  ------------   ---------------------------------------------
 *  11/14/12  E. Birrane     Initial implementation,
 *****************************************************************************/

char *ari_to_string(ari_t *ari)
{
    char *result = NULL;

   // TODO

	return result;
}


void ac_clear(ac_t *ac)
{
	CHKVOID(ac);

	vec_clear(ac->values);
}



ac_t *ac_create()
{
	ac_t *result;
	int success;

	if((result = STAKE(sizeof(ac_t))) == NULL)
	{
		AMP_DEBUG_ERR("ac_create","Can't allocate ac", NULL);
		return NULL;
	}

	result->values = vec_create(0, ari_cb_del_fn, ari_cb_comp_fn, ari_cb_copy_fn, VEC_FLAG_AS_STACK, &success);

	if(success != AMP_OK)
	{
		vec_release(&(result->values), 0);
		SRELEASE(result);
		result = NULL;
	}

	return result;
}

ac_t ac_copy(ac_t *src)
{
	vec_idx_t i;
	ari_t *cur_ari = NULL;
	ari_t *new_ari = NULL;
	int success = AMP_FAIL;
	ac_t result;

	memset(&result, 0, sizeof(ac_t));

	CHKUSR(src, result);

	for(i = 0; i < vec_size(src->values); i++)
	{
		cur_ari = vec_at(src->values, i, &success);
		new_ari = ari_copy_ptr(cur_ari);
		if((success = vec_insert(&(result.values), new_ari, NULL)) != AMP_OK)
		{
			AMP_DEBUG_ERR("ac_copy","Error copying AC.", NULL);
			ac_release(result, 0);
			memset(&result, 0, sizeof(ac_t));
			break;
		}
	}

	return result;
}

ac_t*     ac_copy_ptr(ac_t *src)
{
	ac_t *result = NULL;

	CHKNULL(src);

	if((result = ac_create()) == NULL)
	{
		return NULL;
	}

	*result = ac_copy(src);

	return result;
}
/*
 * If bad success, result is undefined.
 */

ac_t ac_deserialize(CborValue *it, int *success)
{
	CborError err = CborNoError;
	CborValue array_it;
	uint8_t *flag;
	ac_t result;
	size_t length;
	size_t i;

	AMP_DEBUG_ENTRY("ac_deserialize","("ADDR_FIELDSPEC","ADDR_FIELDSPEC")", (uaddr)it, (uaddr)success);

	CHKUSR(it, result);
	CHKUSR(success, result);

	*success = AMP_FAIL;

	if((!cbor_value_is_container(it)) ||
	   ((err = cbor_value_enter_container(it, &array_it)) != CborNoError))
	{
		AMP_DEBUG_ERR("ac_deserialize","AC not a container. Error is %d", err);
		return result;
	}

	if((err = cbor_value_get_array_length(it, &length)) != CborNoError)
	{
		AMP_DEBUG_ERR("ac_deserialize","Can't get array length. Err is %d", err);
		return result;
	}

	result.values = vec_create(length, ari_cb_del_fn, ari_cb_comp_fn, ari_cb_copy_fn, VEC_FLAG_AS_STACK, &success);

	for(i = 0; i < length; i++)
	{
		ari_t *cur_ari = ari_deserialize_ptr(&array_it, success);
		if((*success = ac_insert(&result, cur_ari)) != AMP_OK)
		{
			AMP_DEBUG_ERR("ac_deserialize","Can't grab ARI #%d.", i);
			ac_release(&result, 0);
			return result;
		}
	}

	if((err = cbor_value_leave_container(it, &array_it)) != CborNoError)
	{
		AMP_DEBUG_ERR("ac_deserialize","Can't leave container. Err is %d.", err);
		ac_release(&result, 0);
		return result;
	}

	*success = AMP_OK;
	return result;
}



ac_t* ac_deserialize_ptr(CborValue *it, int *success)
{
	ac_t *result = ac_create();

	CHKNULL(success);
	*success = AMP_FAIL;
	CHKNULL(result);

	*result = ac_deserialize(it, success);
	if(success != AMP_OK)
	{
		ac_release(result, 1);
		result = NULL;
	}

	return result;
}

/*
 * Shallow get.
 */
ari_t* ac_get(ac_t* ac, uint8_t index)
{
	ari_t *result;
	int success;

	CHKNULL(ac);

	result = (ari_t *) vec_at(ac->values, index, &success);
	if(success != AMP_OK)
	{
		result = NULL;
	}

	return result;
}


uint8_t   ac_get_count(ac_t* ac)
{
	CHKZERO(ac);
	return vec_size(ac->values);
}

int ac_insert(ac_t* ac, ari_t *ari)
{
	CHKUSR(ac, AMP_FAIL);
	CHKUSR(ari, AMP_FAIL);

	return vec_push(ac, ari, NULL);
}

void ac_release(ac_t *ac, int destroy)
{
	CHKVOID(ac);

	vec_release(&(ac->values), 0);
	SRELEASE(ac);
}


CborError ac_serialize(CborEncoder *encoder, ac_t *ac)
{
	CborError err;
	CborEncoder *array_enc;
	vec_idx_t i;
	vec_idx_t max;
	int success;

	CHKUSR(encoder, CborErrorIO);
	CHKUSR(ac, CborErrorIO);

	max = vec_size(ac->values);
	err = cbor_encoder_create_array(encoder, &array_enc, max);

	for(i = 0; i < max; i++)
	{
		blob_t *result = ari_serialize_wrapper((ari_t*) vec_at(ac->values, i, success));

		err = CborErrorIO;
		if(result != NULL)
		{
			err = cbor_encode_byte_string(encoder, result->value, result->length);
			blob_release(result, 1);
		}

		if((err != CborNoError) && (err != CborErrorOutOfMemory))
		{
			AMP_DEBUG_ERR("ac_serialize","Can't serialize ari #%d. Err is %d.",i, err);
			cbor_encoder_close_container(encoder, &array_enc);
			return err;
		}
	}

	return cbor_encoder_close_container(encoder, &array_enc);
}


blob_t*  ac_serialize_wrapper(ac_t *ac)
{
	CHKNULL(ac);

	return cut_serialize_wrapper(vec_size(ac->values) * ARI_DEFAULT_ENC_SIZE, ac, ac_serialize);
}




