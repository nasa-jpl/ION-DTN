# JHU/APL
# Description: This is a library file for any settings that need to be
# set up globally for CAmpPython
# Modification History:
#   YYYY-MM-DD     AUTHOR            DESCRIPTION
#   ----------     ---------------   -------------------------------
#   2017-12-01     Sarah             File creation
#
#############################################################################

from collections import OrderedDict

#
# The placement of each in this list should match the integer associated in init()
# function
# sname should be what's used by MIDs, lname what's used by JSON
#
collections = [{"sname":"meta",   "lname":"Mdat"},       # META  = 0 below
	       {"sname":"cnst",   "lname":"Const"},      # CONST = 1
	       {"sname":"ctrl",   "lname":"Ctrl"},       # CTRL  = 2
	       {"sname":"edd",    "lname":"Edd"},        # EDD   = 3
	       {"sname":"mac",  "lname":"Mac"},          # MACRO = 4
	       {"sname":"op",     "lname":"Oper"},     # OP    = 5
	       {"sname":"rpttpl",   "lname":"Rptt"},	 # RPT   = 6 
	       {"sname":"tblt",   "lname":"Tblt"},  	 # TBL   = 7
	       {"sname":"var",    "lname":"Var"}         # VAR   = 8
]

# the area of the data type and its enumeration
#enumerations from sec 8 in ama 
ari_type_enum = {"CONST":"0", "CTRL":"1","EDD":"2", "LIT":"3", "MAC":"4", "OPER":"5", "RPT":"6", "RPTT":"7", "SBR":"8", "TBL":"9", "TBLT":"a",  
	 "TBR":"b",  "VAR":"c", "MDAT":"0" }

#Area enumetraions for nn as outlined in the new AMP
nn_type_enum = OrderedDict([("CONST",0), ("CTRL",1), ("EDD",2), 
							("MAC",3), ("OPER",4), ("RPTT",5), 
							("TBLT",7), ("VAR",9), ("MDAT",10)])

#
# Initializes global variables for CAmpPython
#
#
def init():

	# TODO: not good that these are mutable. enum may be preferred but not available until
	# Python 3	
	global META, CONST, TBL, EDD, CTRL, OP, VAR, MACRO, RPT

	META   = 0
	CONST  = 1
	CTRL   = 2
	EDD    = 3
	MACRO  = 4
	OP     = 5
	RPT    = 6
	TBL    = 7
	VAR    = 8
	


#
# Returns the short name for the passed collection type
# TODO: handle out of range
#
def get_sname(coll):
	return collections[coll]["sname"]

#
# Returns the long name for the passed collection type
# TODO: handle out of range
#
def get_lname(coll):
	return collections[coll]["lname"]

#
# Returns the collection type with the passed long or short name.
# Returns None if the name is not present 
#
def name_get_coll(name):
	for idx, i in enumerate(collections):
		if(i["lname"].upper() == name.upper() or i["sname"].upper() == name.upper()):
			return idx
	return None

		

