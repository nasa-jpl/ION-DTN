# JHU/APL
# Description: creates the c file for the public version of the adm
# Modification History:
#   YYYY-MM-DD     AUTHOR            DESCRIPTION
#   ----------     ---------------   -------------------------------
#   2017-08-11		Evana
#	2017-12-28     David 			Metadata is in constants now
#
###############################################

from lib import campch
from lib.common import camputil as cu
from lib.common import campsettings as cs

#
# Writes all of the #includes for this c file
#
# c_file is an open file descriptor to be written to
# name is the name provided by get_adm_names()
# retriever is the Retriever class instance for this data
#
def write_includes(c_file, name, retriever):
	files = ["ion.h", "platform.h",
		 "{}.h".format(name), "shared/utils/utils.h",
		 "shared/primitives/report.h",   "shared/primitives/blob.h",
		 "{}_impl.h".format(name),          "agent/rda.h"]

	c_file.write(campch.make_includes(files))

	# Adds #includes calls for all of the adms in the "uses"
	# construct of the ADM
	files = campch.get_uses_h_files(retriever)
	c_file.write(campch.make_includes(files))
	
#
# Constructs and writes the main init function for the agent file
#
# c_file is an open file descriptor to write to
# name is the name returned by the call to get_adm_names()
# retriever is the Retriever class instance for this ADM
#
def write_init_function(c_file, name, g_var_idx, retriever):
	campch.write_init_function(c_file, name, g_var_idx, retriever, False)

#
# Builds a template for the
# ```
# adm_add_...(adm_build_ari(...), ...)
# ```
# calls with passed collection type and adm name. Should be formatted in the calling
# function with:
# return_str.format([0|1](for whether params are present or not), ari_name, ari_amp_type, item[name], item[description])
#
# The intention behind this function is to only have to construct these parts once for each
# collection. Subset of formatted values that need to be substituted for_each_ item in the
# collection is much smaller.
#
# Only trivially different than the function of the same name in create_mgr_c.py
#
def make_std_meta_adm_build_template(coll, g_var_idx):
	build_ari_template = campch.make_adm_build_ari_template(coll, g_var_idx, False)
	return "\n\tadm_add_" + cs.get_raw_amp_type(coll).lower() + "(" + build_ari_template + ", {2});"
		
#
# Constructs and writes the init metadata function
#
# c_file is an open file descriptor to write to
# name is the name returned by a call to get_adm_names()
# retriever is the Retriever class instance for this ADM
#
def write_init_metadata_function(c_file, name, g_var_idx, retriever):
	body = ""
	add_str_template = make_std_meta_adm_build_template(cs.META, g_var_idx)

	for i in retriever.get_metadata():
		try:
			_,fname,_ = campch.make_meta_function(name, i)
			ari       = cu.make_ari_name(name, cs.META, i)
			
			body = body + add_str_template.format("0", ari, fname)
		except KeyError, e:
			print "[ Error ] Badly formatted metadata. Key not found:"
			print e
			raise

	campch.write_formatted_init_function(c_file, name, cs.META, body)

#
# Constructs and writes the init_constants function
#
# c_file is an open file descriptor to write to,
# name is the value returned from get_adm_names()
#
def write_init_constant_function(c_file, name, g_var_idx, retriever):
	body = ""
	add_str = make_std_meta_adm_build_template(cs.CONST, g_var_idx)

	for i in retriever.get_constants():
		parms_tf = "0"
		try:
			_,fname,_ = campch.make_constant_function(name, i)
			ari       = cu.make_ari_name(name, cs.CONST, i)
			
			if retriever.item_get_parms(i) : parms_tf = "1"

			body = body + add_str.format(parms_tf, ari, fname)
		except KeyError, e:
			print "[ Error ] Badly formatted constant. Key not found:"
			print e
			raise
			
	campch.write_formatted_init_function(c_file, name, cs.CONST, body)
	
#
# Constructs and writes the init_edd function
#
# c_file is an open file descriptor to write to
# name is the value returned from get_adm_names()
#
def write_init_edd_function(c_file, name, g_var_idx, retriever):
	body = ""
	add_str = make_std_meta_adm_build_template(cs.EDD, g_var_idx)

	for i in retriever.get_edds():
		parms_tf = "0"
		try:
			_,fname,_ = campch.make_collect_function(name, i)
			ari       = cu.make_ari_name(name, cs.EDD, i)
			
			if retriever.item_get_parms(i) : parms_tf = "1"

			body = body + add_str.format(parms_tf, ari, fname)
		except KeyError, e:
			print "[ Error ] Badly formatted EDD. Key not found:"
			print e
			raise
		
	campch.write_formatted_init_function(c_file, name, cs.EDD, body)
			

#
# Constructs and writes the init_operators function
#
# c_file is an open file descriptor to write to,
# name is the value returned from get_adm_names()
# operators is a list of operators to add
#
def write_init_op_function(c_file, name, g_var_idx, retriever):
	body = ""
	adm_add_op_template = "\n\tadm_add_"+cs.get_sname(cs.OP)+"(" + g_var_idx + "["+cs.get_adm_idx(cs.OP)+"], {0}, {1}, {2});"

	operators = retriever.get_operators()
	for i in operators:
		try:
			ari      = cu.make_ari_name(name, cs.OP, i)
			in_types = retriever.item_get_in_types(i)
			
			body = body + adm_add_op_template.format(ari, len(in_types), ari.lower())
		except KeyError, e:
			print "[ Error ] Badly formatted operator. Key not found:"
			print e
			raise

	campch.write_formatted_init_function(c_file, name, cs.OP, body)

#
# Writes the init_variables body 
# for each variable creates a lyst for its postfix-expr and writes 
# its appropriate adm_add_var function
#
def write_init_var_function(c_file, name, g_var_idx, retriever):
	campch.write_init_var_function(c_file, name, g_var_idx, retriever, False)
	
#
# Constructs and writes the init_controls function
#
# c_file is an open file descriptor to write to,
# name is the value returned from get_adm_names()
# controls is a list of controls to add
#
def write_init_control_function(c_file, name, g_var_idx, retriever):
	body = ""
	adm_add_template = "\n\tadm_add_ctrldef(" + g_var_idx + "["+cs.get_adm_idx(cs.CTRL)+"], {0}, {1}, {2});"

	controls = retriever.get_controls()
	for i in controls:
		try:
			ari = cu.make_ari_name(name, cs.CTRL, i)
			parm = retriever.item_get_parms(i)
			body = body + adm_add_template.format(ari, len(parm), ari.lower())
		except KeyError, e:
			print "[ Error ] Badly formatted control. Key not found:"
			print e
			raise

	campch.write_formatted_init_function(c_file, name, cs.CTRL, body)

#
# Constructs and writes the init_macros function
#
# c_file is an open file descriptor to write to,
# name is the value returned from get_adm_names()
# macros is a list of macros to add
#
def write_init_macro_function(c_file, name, g_var_idx, retriever):
	campch.write_init_macro_function(c_file, name, g_var_idx, retriever, False)

#
# Constructs and writes the init reports function
#
# c_file is an open file descriptor to write to
# name is the name returned by the call to get_adm_names()
# retriever is the Retriever class instance for this ADM
#
def write_init_reports_function(c_file, name, g_var_idx, retriever):
	campch.write_parameterized_init_reports_function(c_file, name, g_var_idx, retriever, False)

#
# Constructs and writes the init tables function
# 
# c_file is an open file descriptor to write to
# name is the name returned by the call to get_adm_names()
# retriever is the Retriever class instance for this ADM
#
def write_init_tables_function(c_file, name, g_var_idx, retriever):
	campch.write_init_tables_function(c_file, name, g_var_idx, retriever, False)
	
#
# Main function of this file, which calls helper functions
# to orchestrate creation of the generated file
#
# retriever: the Retriever class instance for this ADM
# outpath: the output directory
#
def create(retriever, outpath):
	try:
		name, ns = retriever.get_adm_names()
		ns_upper = ns.upper()
	except KeyError, e:
		print "[ Error ] JSON does not include valid metadata"
		print e
		return

	filename, c_file = cu.initialize_file(outpath, "agent", name, "_agent.c")
	if not c_file:
		return

	print "Working on ", filename, 

	campch.write_c_file_header(c_file, filename)
	write_includes(c_file, name, retriever)

	c_file.write("#define _HAVE_"+ns_upper+"_ADM_\n")
	c_file.write("#ifdef _HAVE_"+ns_upper+"_ADM_\n\n")

	g_var_idx = retriever.get_g_var_idx()
	c_file.write("static vec_idx_t {}[11];\n\n".format(g_var_idx))
	
	write_init_function(c_file, ns, g_var_idx, retriever)

	write_init_metadata_function(c_file, ns, g_var_idx, retriever)
	write_init_constant_function(c_file, ns, g_var_idx, retriever)

	write_init_edd_function(c_file, ns, g_var_idx, retriever)
	write_init_op_function( c_file, ns, g_var_idx, retriever)
	
	write_init_var_function(    c_file, ns, g_var_idx, retriever)
	write_init_control_function(c_file, ns, g_var_idx, retriever)
	write_init_macro_function(  c_file, ns, g_var_idx, retriever)
	
	write_init_reports_function(c_file, ns, g_var_idx, retriever)
	write_init_tables_function( c_file, ns, g_var_idx, retriever)

	c_file.write("#endif // _HAVE_"+ns_upper+"_ADM_\n")
	c_file.close()
	
	print "\t[ DONE ]"
