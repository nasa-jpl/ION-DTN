use amp_core;


-- view for type name value collections 

CREATE OR REPLACE VIEW `vw_tnvc` AS
    SELECT 
        `type_name_value_entry`.tnvc_id,
        tnv_id,
        order_num,
        data_type_id,
        data_name,
        use_desc
    FROM
        `type_name_value_entry`,
        `type_name_value_collection`
    WHERE
        `type_name_value_collection`.`tnvc_id` = `type_name_value_entry`.`tnvc_id`