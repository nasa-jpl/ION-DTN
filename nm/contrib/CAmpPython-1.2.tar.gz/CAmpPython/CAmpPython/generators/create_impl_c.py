# JHUAPL
# Description: Creates the c file for the implementation version of the adm

# Modification History:
#   YYYY-MM-DD   AUTHOR         DESCRIPTION
#   ----------   ------------   ---------------------------------------------
#   2017-08-10   David          First implementation
#   2017-11-15   Sarah          Made long strings more readable, added error checks
#   2017-12-28   David 			Metadata is in constants now
#   2017-12-19   Evana			Insert table functionality	
#   2018-06-27   David 			Changed mids to aris	
##################################################################### 

from lib import campch
from lib.campch_roundtrip import C_Scraper
from lib.common import camputil as cu
 
#
# Writes the metadata functions to the file passed
# new_c is an open file descriptor to write to
# name is the value returned from get_adm_names()
# metadata is a list of metadata to include
#
def write_metadata_functions(new_c, name, metadata):
	new_c.write("\n/* Metadata Functions */\n\n")
			   
	metadata_funct_str = (
		"\n{0}"
		"\n{{"
		"\n\treturn tnv_from_str(\"{1}\");"
		"\n}}"
		"\n\n")

	for i in metadata:
		try:
			_,_,signature = campch.make_meta_function(name, i)
			new_c.write(metadata_funct_str.format(signature, i["value"]))
		except KeyError, e:
			print "[ Error ] Badly formatted metadata. Key not found:"
			print e
			raise

#
# Writes the constant functions to the file passed
# new_c is an open file descriptor to write to
# name is the value returned from get_adm_names()
# constants is a list of constants to include
#
def write_constant_functions(new_c, name, constants):
	new_c.write("\n/* Constant Functions */")

	const_function_str = (
		"\n{0}"
		"\n{{"
		"\n\treturn tnv_from_uvast({1});"
		"\n}}"
		"\n")

	for i in constants:
		try:
			_,_,signature = campch.make_constant_function(name, i)
			new_c.write(const_function_str.format(signature, i["value"]))
		except KeyError, e:
			print "[ Error ] Badly formatted constant. Key not found:"
			print e
			raise		

#
# Helper function to correctly format and return a string for the column
# conditional in the table functions
#
# XXX: this is currently unused (commented out). Remove?
#
def make_column_conditional(columns):
	if(columns == []):
		return "" 

	cout = "\tif("
	
	table_function_ari_str = "\n\t\t(tblt_add_col(table, {0}, \"{1}\") == ERROR){2}"
	
	items_left = len(columns) - 1

	for pair in columns:
		type_name = cu.make_amp_type_name(pair)
		if items_left == 0:
			cout = cout + table_function_ari_str.format(type_name, pair["name"], ")")
		else:
			cout = cout + table_function_ari_str.format(type_name, pair["name"], " ||")
		items_left -= 1
			
	return cout
			
#
# writes the table functions to the file passed
# new_c is an open file descriptor to write to
# name is the value returned from get_adm_names()
# table is a list of tables to include
# scraper is the Scraper object associated with this ADM
#
def write_table_functions(new_c, name, table, scraper):
 	new_c.write("\n/* Table Functions */\n\n")	
	
	table_function_begin_str = (
		"\n{0}"
		"\n{1}"
		"\n{{"
		"\n\ttbl_t *table = NULL;"
		"\n\tif((table = tbl_create(id)) == NULL)"
		"\n\t{{"
		"\n\t\treturn NULL;"
		"\n\t}}"
		"\n\n")

	conditional_body_str = (
		"\n\t{"
		"\n\t\treturn NULL;"
		"\n\t}"
		"\n\n")
	
	table_function_end_str = "\treturn table;\n}\n\n"
	
	for i in table:
		try:
			basename,_,signature = campch.make_table_function(name,  i)
			description          = campch.multiline_comment_format(i["description"])

			new_c.write(table_function_begin_str.format(description, signature))
#			new_c.write(make_column_conditional(i["columns"]))
#			new_c.write(conditional_body_str)
		except KeyError, e:
			print "[ Error ] Badly formatted table. Key not found:"
			print e
			raise
		
		# Add custom body tags and any scrapped lines found
		scraper.write_custom_body(new_c, basename)

		# Close out the function
		new_c.write(table_function_end_str)

#
# Writes the edd functions to the file passed
# new_c is an open file descriptor to write to
# name is the value returned from get_adm_names()
# edds is a list of edds to include
# custom is a dictionary of custom function bodies to include, in the
# form {"function_name":["line1", "line2",...], ...}
# scraper is the Scraper object for the current ADM
#
def write_edd_functions(new_c, name, edds, scraper):
	new_c.write("\n/* Collect Functions */")

	edd_function_begin_str = (
		"\n{0}"
		"\n{1}"
		"\n{{"
		"\n\ttnv_t *result = NULL;"
		"\n")
	edd_function_end_str = "\treturn result;\n}\n\n"

	for i in edds:
		try:
			basename,_,signature = campch.make_collect_function(name, i)
			description          = campch.multiline_comment_format(i["description"])

			new_c.write(edd_function_begin_str.format(description, signature))
		except KeyError, e:
			print "[ Error ] Badly formatted edd. Key not found:"
			print e
			raise
		
		# Add custom body tags and any scrapped lines found
		scraper.write_custom_body(new_c, basename)

		# Close out the function
		new_c.write(edd_function_end_str)

#
# Writes the control functions to the file passed
# new_c is an open file descriptor to write to
# name is the value returned from get_adm_names
# controls is a list of controls to include
# custom is a dictionary of custom function bodies to include, in the
# form {"function_name":["line1", "line2",...], ...}
# scraper is the Scraper class object for this ADM
#
def write_control_functions(new_c, name, controls, scraper):
	new_c.write("\n\n/* Control Functions */\n")
	
	ctrl_function_begin_str = (
		"\n{0}"
		"\n{1}"
		"\n{{"
		"\n\ttnv_t *result = NULL;"
		"\n\t*status = CTRL_FAILURE;"
		"\n")
	ctrl_function_end_str = "\treturn result;\n}\n\n"
	
	for i in controls:
		try:
			basename,_,signature = campch.make_control_function(name, i)
			description          = campch.multiline_comment_format(i["description"])
			new_c.write(ctrl_function_begin_str.format(description, signature))
		except KeyError, e:
			print "[ Error ] Badly formatted control. Key not found:"
			print e
			raise

		scraper.write_custom_body(new_c, basename)

		new_c.write(ctrl_function_end_str)

#
# Writes the operator functions to the file passed
# new_c is an open file descriptor to write to
# name is the value returned from get_adm_names
# operators is a list of operators to include
# custom is a dictionary of custom function bodies to include, in the
# form {"function_name":["line1", "line2",...], ...}
# scraper is the Scraper class object for this ADM
#
def write_operator_functions(new_c, name, operators, scraper):
	new_c.write("\n\n/* OP Functions */\n")

	op_function_begin_str = (
		"\n{0}"
		"\n{1}"
		"\n{{"
		"\n\ttnv_t *result = NULL;"
		"\n")
	op_function_end_str = "\treturn result;\n}\n\n"
	
	for i in operators:
		try: 
			basename,_,signature = campch.make_operator_function(name, i)
			description          = campch.multiline_comment_format(i["description"])
			new_c.write(op_function_begin_str.format(description, signature))
		except KeyError, e:
			print "[ Error ] Badly formatted operator. Key not found:"
			print e
			raise
		
		scraper.write_custom_body(new_c, basename)

		new_c.write(op_function_end_str)

#
# function for writing the setup function and 
# custom body if present 
#
# scraper is the Scraper class object for this ADM
#
def write_setup(new_c, name, scraper):
	new_c.write("void {}_setup()\n{{\n\n".format(name))

	scraper.write_custom_body(new_c, "setup")

	new_c.write("}\n\n")

#
# function for writing the cleanup function and 
# custom body if present 
#
# scraper is the Scraper class object for this ADM
#
def write_cleanup(new_c, name, scraper):
	new_c.write("void {}_cleanup()\n{{\n\n".format(name))
	
	scraper.write_custom_body(new_c, "cleanup")

	new_c.write("}\n\n")

#
# Main function of this file, which calls helper functions to
# orchestrate the creation of the generated file
#
# retriever: the Retriever class object for this ADM
# outpath: the output directory
# scrape_file: file name of the file to be scraped for roundtripping
#
def create(retriever, out, scrape_file):
	scraper = C_Scraper(scrape_file)

	try:
		name, ns = retriever.get_adm_names()
	except KeyError, e:
		print "[ Error ] JSON does not include valid metadata"
		print e
		return
	
	filename, new_c = cu.initialize_file(out, "agent", name, "_impl.c")
	if not new_c:
		return
			
	# Create the new file
	print "Working on ", filename,
	campch.write_c_file_header(new_c, filename)

	# Custom includes tag
	scraper.write_custom_includes(new_c)
	new_c.write(campch.make_includes(["shared/adm/adm.h",
					  "{}_impl.h".format(name)]))
	
	# Add any custom functions scraped
	scraper.write_custom_functions(new_c)
	
	write_setup(new_c, ns, scraper)
	write_cleanup(new_c, ns, scraper)

	try:
		write_metadata_functions(new_c, ns, retriever.get_metadata())
		write_constant_functions(new_c, ns, retriever.get_constants())
		write_table_functions(   new_c, ns, retriever.get_tables(),    scraper)
		write_edd_functions(     new_c, ns, retriever.get_edds(),      scraper)
		write_control_functions( new_c, ns, retriever.get_controls(),  scraper)	
		write_operator_functions(new_c, ns, retriever.get_operators(), scraper)
	except KeyError, e:
		return
	finally:
		new_c.close()

	print "\t[ DONE ]"
