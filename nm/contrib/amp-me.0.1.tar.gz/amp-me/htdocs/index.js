
import { CBOR } from "./lib/shared/cbor.js";
import * as AMP from "./lib/shared/amp.js";

var cfg = {
    nmrest_base: "/nm/api",
    dbrest_base: "/api",
}

// TODO: Create helper functions for commonly-used types
    // TODO: Replace style="" with actual CSS definitions wherever practical.
var config = {
    agent1: {
        name: 'demo-agent',
        active: 'tab1',
        tabs: [
            /* Reserved
            { id: 'tab1', caption: 'Status' },
            { id: 'tab2', caption: 'Reports' },
            { id: 'tab3', caption: 'Tables' },
            { id: 'tab4', caption: 'Send Control' },
            */
        ],
        onClick: function (event) {
            $('#tab-example .tab').hide();
            $('#tab-example #' + event.target).show();
        }
        // onClose
    },
    toolbar: {
        name: 'toolbar',
        items: [
            // TODO: Option to disable Mgr entirely in config, or to fix path
            // TODO: Disable editing of mgr URI when connected
            { type: 'button', id: 'mgr_connect', text: 'Mgr', icon: 'w2ui-icon-cross' },
            { type: 'drop', id: 'mgr_settings', text: '', icon: 'w2ui-icon-pencil',
              html: '<div style="padding: 10px; line-height: 1.5">Future: Dialog to edit NM REST Connection Settings, if enabled</div>' },
            { type: 'button', id: 'mgr_refresh', text: '', icon: 'w2ui-icon-reload' }, // If we use WebSockets this can be disabled
            { type: 'break' },

            // TODO: Option to disable SQL entirely in config, or to fix path
            // TODO: Disable editing of mgr URI when connected
            { type: 'button', id: 'sql_connect', text: 'DB', icon: 'w2ui-icon-check' },
            { type: 'drop', id: 'sql_settings', text: '', icon: 'w2ui-icon-pencil',
              html: '<div style="padding: 10px; line-height: 1.5">Future: Dialog to edit SQL Connection Settings, if enabled</div>' },
            { type: 'button', id: 'db_refresh', text: '', icon: 'w2ui-icon-reload' }, // If we use WebSockets this can be disabled
            { type: 'break' },
            { type: 'menu-radio', id: 'app-mode', icon: 'fa-star', // FIXME: This icon isn't showing up
                text: function (item) {
                    var text = item.selected;
                    var el   = this.get('item2:' + item.selected); // ?
                    return 'Mode: ' + el.text;
                },
                selected: 'dbg',
              items: [
                  // TOOD: Default view should be configurable, option to hide this button. Currently using debug-mode only -- in the future non-debug modes will hide duplicate information, and records only useful for developers/debuggers.
                    { id: 'dbg', text: 'Debug', icon: 'fa-camera' },
                    { id: 'db', text: 'AMP DB', icon: 'fa-picture' },
                    { id: 'nm', text: 'NM Mgr', icon: 'fa-glass' },
                    { id: 'static', text: 'Offline', icon: 'fa-glass' }
                ]
            },
        ],
        onClick: function(event) {
            switch(event.target) {
            case 'mgr_refresh': // Test: This may change later
                load_agents_nm();
            }
        }
    },
sidebar: {
    name: 'sidebar',
    
    flatButton: true, // Not working...
    onFlat: function (event) {
            $('#sidebar').css('width', (event.goFlat ? '35px' : '200px'));
    },
    
    nodes: [ 
        { id: 'agents', text: 'Agents', group: true, expanded: true, nodes: [
            { id: 'sidebar-all-agents', text: 'All', img: 'icon-page' }, // Interface for viewing reports/info for all agents
        ]},        
        { id: 'db', text: 'AMP DB', group: true, expanded: true, nodes: [
            { id: 'msgs-out', text: 'Outgoing Sets', img: 'icon-page' },
            { id: 'msgs-in', text: 'Received Sets', img: 'icon-page' },
            { id: 'msgs-all', text: 'All Message Sets', img: 'icon-page' },
            { id: 'view-logs', text: 'Mgr Logs', img: 'icon-page' },
            { id: 'item10', text: 'Controls', img: 'icon-page' },
            { id: 'item11', text: '...sample...', img: 'icon-page' }
        ]},
        { id: 'mgr', text: 'NM Manager', group: true, expanded: true, nodes: [
            { id: 'item4', text: 'Status', img: 'icon-page' },
            { id: 'item5', text: 'Send Command', img: 'icon-page' },
        ]},
        { id: 'util', text: 'Utilities', group: true, expanded: true, nodes: [
            { id: 'amp.me', text: 'Amp.me', img: 'icon-page' },
            { id: 'adms', text: 'ADM Listing', img: 'icon-page' },
            { id: 'item6', text: 'Documentation', img: 'icon-page' },
            { id: 'item7', text: 'Support', img: 'icon-page' }
        ]}
    ],
    onClick: function (event) {
        /*
          Demo; Serves as a tab selector
          Desired; selects a set of tabs
        */        
        var tabs = w2ui.layout_main_tabs;

        // Clear any existing tabs
        var tabids = tabs.tabs.map(obj => obj.id);
        tabids.forEach(tab => tabs.remove(tab) );

        if (event.node.parent.id == "agents") { // TODO: parent

            if (event.target == "sidebar-all-agents") {
                w2ui.layout.html('main', 'All Agents display TODO');
            } else {
                // Create Agent Tags
                tabs.add([
                    { id: 'tab-status', caption: 'Status' },
                    { id: 'tab-reports', caption: 'Reports' },
                    { id: 'tab-tables', caption: 'Tables' },
                    { id: 'tab-send', caption: 'Send Control' },
                ]);

                // Select status as default
                tabs.select('tab-status');

                // And show it (TODO: Can this be automatic from .select event?)
                //w2ui.layout.html('main', event.node.agent.showStatus() );
                w2ui.layout.content('main', event.node.agent.showStatus() );
            }
        } else {
            switch(event.target) {
            case "amp.me":
                window.location.hash = "#amp.me";
                w2ui.layout.content('main', w2ui.ampMe_layout );
                break;
            case "adms":
                window.location.hash = "#adms";
                if (!config.adms_list_grid) {
                    config.adms_list_grid = ui_adms_idx_grid();
                    $().w2grid(config.adms_list_grid);
                }
                w2ui.layout.content('main', w2ui.adms_idx_grid );
                break;
            case "msgs-in":
                w2ui.layout.content('main', msgs_grid('incoming'));
                break;
            case "msgs-out":
                w2ui.layout.content('main', msgs_grid('outgoing'));
                break;
            case "msgs-all":
                w2ui.layout.content('main', msgs_grid('all'));
                break;
            case "view-logs":
                w2ui.layout.content('main', ui_nm_mgr_log());
                break;
            default:
                // Actual page/output display TODO.  For now, hide tab bar entirely
                w2ui.layout.html('main', event.target+ " is a placeholder.");
            }


        }
    }
},
    statusGrid: { // DEBUG
        name: 'statusGrid',
        columns: [
            { field: 'key', caption: 'Key', size: '80px' },
            { field: 'title', caption: 'Title', size: '100%' },
            { field: 'priority', caption: 'Priority', size: '80px', attr: 'align="center"' }
        ],
        records: [
            /* Sample
            { recid: 1, key: 'Open', title: 'Short title for the record', priority: 2 },
            { recid: 2, key: 'Open', title: 'Short title for the record', priority: 3 },
            { recid: 3, key: 'Closed', title: 'Short title for the record', priority: 1 }
            */
        ]
    },
    ampMe_form: {
        name: 'ampMe_form',
        url: 'undefined', // VERIFY we can deleete this line
        header: 'Currently accepts CBOR Hex (0x...) AMP-CBOR (ie: ari:0x...), or AMP URIs (ie: ari:/IANA:...). This tool is experimental and some data types may not be fully implemented at this time.',
        fields: [
            { field: 'input', type: 'text', required: true,
              html: { caption: 'Input (CBOR or URI)', attr: 'style="width: 100%"'} },
        ],
        actions: {
            'Parse': function(evt) {
                // Get Input Text
                var input = this.get('input').el.value;

                // Parse & Validate
                //ui_parsed_cbor_grid_popup( input );
                ui_show_parsed_cbor(input);
                
            },
            'Clear' : function(evt) {
                this.clear();
                //this.destroy();
            }
        }

    }
};
config.layout = {
        name: 'layout',
        padding: 0,
        panels: [
            { type: 'top', size: 40, resizable: false, style: 'border: 1px solid #dfdfdf; padding: 5px;', toolbar: config.toolbar },
            {type: 'left', size: 200, resizable: true, minSize: 120 },
            { type: 'main', overflow: 'hidden', tabs: config.agent1 }
        ]
};
config.ampMe_layout = {
        name: 'ampMe_layout',
        padding: 4,
        panels: [
            { type: 'top', size: 150 },
            { type: 'main',
              tabs: [
                  { id: 'null', caption: 'Not Parsed' },
//                  { id: 'trace', caption: 'Trace' },
//                  { id: 'info', caption: 'Overview' },
        ],
            }
        ]
};


$(function () {
    var reg = AMP.Registry.getInstance("lib/shared/adms");
    
    $('#main').w2layout(config.layout);
    w2ui.layout.content('left', $().w2sidebar(config.sidebar));
    load_agents_nm();
    load_agents_db();
    $().w2grid(config.statusGrid); // DEBUG
    $().w2form(config.ampMe_form);


    $().w2layout(config.ampMe_layout);
    w2ui.ampMe_layout.content('top', w2ui.ampMe_form);
    w2ui.ampMe_layout.content('main', w2ui.statusGrid);


    if (window.location.hash) {
        console.log(window.location.hash);
        if (window.location.hash == "#amp.me") {
            w2ui.layout.content('main', w2ui.ampMe_layout );
        } else if (window.location.hash == "#adms") {
            reg.then((resolve,reject) => w2ui.layout.content('main', $().w2grid(ui_adms_idx_grid() )));
        }
    } else {
        // Default View: amp.me
        w2ui.layout.content('main', w2ui.ampMe_layout );
    }
});

// TODO: This should evolve into a class
var agents = {};

// Load or refresh agent listing from AMP SQL Database
function load_agents_db() {
    fetch(cfg.dbrest_base + '/agents').then(response => response.json()).then(data => {
        console.log('Agents from DB: ', data);
        data.forEach(agent => {
            var obj;
            var eid = agent.agent_id_string;
            if (agents[eid]) {
                obj = agents[eid];
                // TODO: Update icon for agent
            } else {
                obj = new Agent(eid);
                agents[eid] = obj;
                ui_add_agent(obj, 'w2ui-icon-cross');
            }
            obj.db = agent; // TODO: This may be cleaned up later
        });
    })
        .catch((error) => {
            console.error('Error retrieving agents listing from DB:', error);
        });
    
}
// Load/refresh agent listing from NM Manager REST API
function load_agents_nm() {
    fetch(cfg.nmrest_base + '/agents').then(response => response.json()).then(data => {
        // TODO: Check for errors
        console.log('Agents from NM: ', data);
        data.agents.forEach(agent => {
            var obj;
            if (agents[agent.name]) {
                obj = agents[agent.name];
                ui_agent_set_icon(agent.name, 'w2ui-icon-check'); // Ensure icon reflects that agent is active
            } else {
                obj = new Agent(agent.name);
                agents[agent.name] = obj;
                ui_add_agent(obj);
            }
            obj.nm = agent; // TODO: This may be cleaned up later
        });
        // TODO: Consider downgrading icon to disconnected if entry is not in this listing.
    })
        .catch((error) => {
            console.error('Error retrieving agents listing from NM:', error);
        });
    
    
}
// TODO: Should ui_*agent* functions be a part of Agent class?
function ui_add_agent(obj, icon='w2ui-icon-check') {
    w2ui.sidebar.add('agents',
                     {
                         id: 'sidebar-agent-'+obj.eid, // TODO: Is prefix necessary?
                         text: obj.eid,
                         icon: icon, // TODO: Icon for 'connected NM Agent' vs disconnected or DB-entry
                         agent: obj
                     }
                    );
}
function ui_agent_set_icon(eid, icon) {
    w2ui.sidebar.get("agents", "sidebar-agent-"+eid).icon=icon;
    w2ui.sidebar.refresh();
}

function build_control(default_agent=null) {
    // Note: Should this become an object for clarity?

    // Part 1: Base Form
    /* Select Destination Node(s).
       - This is a multi-select type field, with '+' and '-' buttons, where add gives menu to select known agents or enter custom
         - Entering custom will register a new agent (unless that option is bypassed in a debug-case)
       - If default_agent is an object, use this Agent as default
       - If default_agent is a string, use this as string name for default (lookup Agent object for future convenience)
       - If default_agent is array, then each eleement is an object/string containing an agent
    */
    /* Select Timestamp
       - Date field entry, with option for NULL time
       - Allow entry in timestamp format, or as a raw integer time
    */
    /* Single Message or Set
       - If connected via DB, Create a Set (with requisite Set fields)
       - If connected via Mgr, Create a single message only
       - If both are available, provide a radio button to choose desired mode
    */

    // Part 2: DB-Only: Define Set Attributes
    /* Add Control - Each 'add' will insert a Part3 section, but with the DB-only definition options */

    // Part 3: Define Control
    // Select Entry Mode: Raw CBOR (NM-only, at least initially), Manual, Select From ADM

    // Part 3a: Raw
    // Enter CBOR Hex String of an ARI
    // Option to validate (amp.me function will be invoked in a popup)
    // Buttn to Send

    // Part 3b: RAW Cbor - equivalent to manual entry in Mgr CLI

    // Part 3c: Select from ADM - equivalent to from template in Mgr CLI, but based off of JSON ADMs with a cleaner interface
}

class Agent {

    constructor(eid) {
        this.eid = eid;
    }

    showStatus() {

        var rtv = ui_status_section();
        rtv.append(ui_status_item("Endpoint Name", this.eid));
        if (this.db) {
            rtv.append(ui_status_item("AMP DB ID", this.db.registered_agents_id));
        }
        if (this.nm) {
            rtv.append(ui_status_item("Manager Reports Count", this.nm.rpts_count));
            rtv.append(ui_status_item("Manager Tables Count", this.nm.tbls_count));
        }

        return rtv.html(); // TODO: Is there a better way of doing this?

        // return w2ui.statusGrid; // Alternate idea of returning a table or form (must be pre-created?)
        /* Or....
           var gridConfig = { ... };
           if (w2ui[gridConfig.name]) {
              w2ui.tmpStatusGrid.destroy();
           }
           $().w2grid(gridConfig);
           return w2ui[gridConfig.name];
         */

    }
    

}

function ui_show_parsed_cbor( input ) {
    var obj, title;
    try {
        obj = AMP.parseUri(input, true);
        title = obj.constructor.name;
    } catch(e) {
        AMP.trace.tracing.push({type: "EXCEPTION", value: e});
    }

    var trace = AMP.trace.get();
    
    // Get Existing tabs
    var tabs = w2ui.ampMe_layout_main_tabs;

    // Clear any existing tabs
    var tabids = tabs.tabs.map(obj => obj.id);
    tabids.forEach(tab => tabs.remove(tab) );

    tabs.add([ {id: 'tab-trace', caption: 'Trace'},
               {id: 'tab-info', caption: 'Summary'},
               {id: 'tab-cbor', caption: 'CBOR Encoding'},
             ]);
    tabs.select('tab-trace'); // TODO: change default to info ... and update below to display accordingly
    if (obj) {
        if (obj.toSql) { // TODO: If SQL enabled
            tabs.add( {id: 'tab-sql', caption: 'SQL'} );
        }
        if (obj.toUml) {
            tabs.add( {id: 'tab-uml', caption: 'UML'} );
        }
    }

    tabs.onClick = function(event) {
        switch(event.target) {
        case "tab-trace":
            w2ui.ampMe_layout.content('main', $().w2grid(ui_parsed_cbor_grid(trace)));
            break;
        case "tab-info":
            var page = new ui_status();
            page.add('Input', input);
            page.add('Parsed As', title);
            if (title == 'CBOR') {
                page.add('Length (bytes)', obj.buf.byteLength);
                page.add('Bytes Remaining', obj.bytesRemaining);
            } else {
                if (obj.toCbor) {
                    page.add('CBOR', obj.toCbor() );
                }
                if (obj.toUri) {
                    page.addQuote('URI', obj.toUri());
                }
                if (obj.toJSON) {
                    // TODO: Consider replacing with a library like renderjson to make it collapsible
                    page.addQuote('JSON', JSON.stringify(obj.toJSON(1),null,2) );
                }
            }
            w2ui.ampMe_layout.content('main', page.content.html());
            break;
        case "tab-cbor":
            AMP.trace.start();
            var cbor = obj.toCbor();
            var cborTrace = AMP.trace.get();
            w2ui.ampMe_layout.content('main', $().w2grid(ui_parsed_cbor_grid(cborTrace)));
            break;
        case "tab-uml":
            // TODO: TextArea with 'click to copy' button, and ability to switch to svg view once loaded
            var uml = obj.toUml().toUml();
            //w2ui.ampMe_layout.content('main', $('<p>').append($('<pre>').text(uml)).html());

            // TODO: Make UML Server configurable
            var src = "http://www.plantuml.com/plantuml/svg/"+encode64(
                zip_deflate(unescape(encodeURIComponent(uml), 9)
                           ));
            w2ui.ampMe_layout.content('main', `<img src="${src}">`);
            
            break;
        case "tab-sql":
            // Show an Insert-into-DB button
            // onClick, attempt to insert, then display tracing log in grid
            /* insert process
               - obj.toSql()
               - Returns results of a REST query to server-side component which will call obj.fromJson() and then return 
                    { results: obj.toSql(), trace: get_trace() }
             */
            break;
        }
    };
    
    return w2ui.ampMe_layout.content('main', $().w2grid(ui_parsed_cbor_grid(trace)));
}

// TODO: Rename; This can be any parsed type with tracing logs.  For AMP Types, we will extend with additional tabs/displays later
// TODO: Is this function deprecated in favor of ui_show_parsed_cbor?
function ui_parsed_cbor_grid_popup( input ) {
    var cbor, obj, title, trace;
    try {
        obj = AMP.parseUri(input, true);
        title = obj.constructor.name;
        trace = AMP.trace.get();
    } catch(e) {
        AMP.trace.tracing.push({type: "EXCEPTION", value: e});
    }

    w2popup.open({
        title: title,
        showMax : true,
        body    : '<div id="mainPopup" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px;"></div>',
        onOpen  : function (event) {
            event.onComplete = function () {
                $('#w2ui-popup #mainPopup').w2grid(ui_parsed_cbor_grid(trace));
            }
        },
        onToggle: function (event) { 
            event.onComplete = function () {
                w2ui.cbor_grid.resize();
            }
        },
        onMax: function(event) {
            w2ui.cbor_grid.resize();
        },
        onMin: function(event) {
            w2ui.cbor_grid.resize();
        },
    });
}
function ui_parsed_cbor_grid( input ) {
    // Add recid field for w2ui grid
    for (var i in input) {
        input[i]['recid'] = i;
        if (typeof input[i].input == "object" && input[i].input.constructor.name == "DataView") {
            input[i].input_view = input[i].input;
            input[i].input = bufferViewToHex(input[i].input);
        }
    }
    if (w2ui['cbor_grid']) {
        w2ui['cbor_grid'].destroy(); // TODO: Can we reuse instead?
    }
    return {
        name: 'cbor_grid',
        columns: [
            { field: 'input', caption: 'Input', size: '30%' },
            { field: 'type', caption: 'Type', size: '20%' },
            { field: 'value', caption: 'Value', size: '50%',
              editable: { type: 'text' } // TODO: This is solely to allow for easier copy+paste. Ideally we should make it read-only, or add a context-menu for direct copy in the future (neither are built-in option for w2ui)
            }
        ],
        records: input
    };
}

/** Show a table of messages. Mode can be all, incoming, or outgoing */
function msgs_grid(mode="all") {
    if (mode != 'all' && mode != 'incoming' && mode != 'outgoing') {
        console.error('Invalid mode ', mode);
        return;
    }
    var gridname = 'msgs_grid_'+mode;
    // If this view already exists, return it.
    if (w2ui[gridname]) {
        return w2ui[gridname];
    }

    var grid = {
        show: {
            toolbar: true
        },
        name: gridname,
        columns: [
            { field: 'group_id', caption: 'ID', size: '5%' },
            { field: 'agent', caption: 'Agent', size: '10%' }, // Can be multiple agents for outgoing
            { field: 'created_ts', caption: 'Created', size: '10%'},
            { field: 'modified_ts', caption: 'Modified', size: '10%'},
            { field: 'ts', caption: 'Sent', size: '10%'}, // incoming only
            { field: 'is_outgoing', caption: 'Type', size: '10%', hidden: (mode!='all'),
              render: function(record, index) {
                  return (record['is_outgoing']) ? 'Outgoing' : 'Incoming';
              }
            },
            { field: 'state_id', caption: 'State (ID)', size: '10%', hidden: true},
            { field: 'name', caption: 'State', size: '10%'},
            { field: 'description', caption: 'State (Description)', size: '10%', hidden: true},
        ],
        url: cfg.dbrest_base + '/msgs?type='+mode,
    };

    $().w2grid(grid);
    return w2ui[gridname];
}
function ui_nm_mgr_log() {
    if (w2ui.nm_mgr_log) {
        return w2ui.nm_mgr_log;
    }

    var grid = {
        show: {
            toolbar: true
        },
        name: 'nm_mgr_log',
        columns: [
            { field: 'id', caption: 'ID', size: '5%' },
            { field: 'time', caption: 'Time', size: '10%' },
            { field: 'msg', caption: 'Message', size: '20%'},
            { field: 'details', caption: 'Detailed', size: '20%'},
            { field: 'level', caption: 'Severity', size: '5%'},
            { field: 'source', caption: 'Source', size: '10%'},
            { field: 'file', caption: 'File', size: '10%'},
            { field: 'line', caption: 'Line/Id', size: '5%'},
        ],
        url: cfg.dbrest_base + '/logs',
    };

    $().w2grid(grid);
    return w2ui.nm_mgr_log;
}

function ui_adms_idx_grid() {
    var db = AMP.Registry.instanceSync().db.namespaces;
    var data = [];
    var sums = { w2ui: {summary: true},
                 recid: '*', name: 'Summary',ctrls:0,edds:0,mdats:0,rptts:0,tblts:0,vars:0,consts:0,opers:0};
    for(let i = 0; i < db.length; i++) {
        var ns = db[i];
        
        if (!ns.reserved) {
            var def = {
                recid: i,
                name: ns.name,
                url: ns.url,
                issuer: ns.issuer,
            };

            if (ns.definition) {
                var indef = ns.definition;
                if (indef.Ctrl) {  def.ctrls = indef.Ctrl.length; sums.ctrls+=def.ctrls; } else { def.ctrls = 0; }
                if (indef.Edd) {  def.edds = indef.Edd.length; sums.edds+=def.edds; } else { def.edds = 0; }
                if (indef.Mdat) {  def.mdats = indef.Mdat.length; sums.mdats+=def.mdats; } else { def.mdats = 0; }
                if (indef.Rptt) {  def.rptts = indef.Rptt.length; sums.rptts+=def.rptts; } else { def.rptts = 0; }
                if (indef.Tblt) {  def.tblts = indef.Tblt.length; sums.tblts+=def.tblts; } else { def.tblts = 0; }
                if (indef.Var) {  def.vars = indef.Var.length; sums.vars+=def.vars; } else { def.vars = 0; }
                if (indef.Const) {  def.consts = indef.Const.length; sums.consts+=def.consts; } else { def.consts = 0; }
                if (indef.Oper) {  def.opers = indef.Oper.length; sums.opers+=def.opers; } else { def.opers = 0; }
            }
            data.push(def);
        }
    }
    data.push(sums);
    return {
        name: 'adms_idx_grid',
        columns: [
            { field: 'name', caption: "Name", size: '10%' },
            { field: 'recid', caption: "Index", size: '5%' },
            { field: 'url', caption: "IETF Source", size: '20%'},
            { field: 'issuer', caption: "Issuer", size: '10%'},
            { field: 'ctrls', caption: "Controls", size: '5%'},
            { field: 'edds', caption: "Edds", size: '5%'},
            { field: 'mdats', caption: "Mdats", size: '5%'},
            { field: 'rptts', caption: "Rptts", size: '5%'},
            { field: 'tblts', caption: "Tblts", size: '5%'},
            { field: 'vars', caption: "Vars", size: '5%'},
            { field: 'consts', caption: "Consts", size: '5%'},
            { field: 'opers', caption: "Operators", size: '5%'},  
        ],
        records: data,
        onDblClick: function(event) {
            if (event.column == 2) {
                window.open( 
                    data[event.recid].url,
                    "_blank"
                );
            } else if (db[event.recid]) {
                window.open( AMP.Registry.instanceSync().path + "/" + db[event.recid].file, "_blank" );
            }
        }  
    };
}
        
// Custom UI Helpers (should these be a new class? Call this our template wrapper)

class ui_status { // There are likely better ways to achieve this, but this API at least should be modular
    content;

    constructor(title) {
        this.content = $("<div>").addClass("ui-status-section");
        if (title) {
            this.content.append($("<h1>").text(title));
        }
    }
    add(key, val) {
        this.content.append($('<p>').html('<strong>' + key + ":</strong> " + val));
    }

    // TODO: Option to make section collapsible
    addQuote(key, val, collapsible=false) {
        this.content.append($('<p>')
                            .append($('<strong>').text(key))
                            .append($('<pre>').text(val))
                           );
    }
}
        
// Jquery-based helpers
function ui_status_section() {
    var rtv = $("<div>").addClass("ui-status-section");
    // TODO: Optional id
    // TODO: Optional Heading
    return rtv;
}
function ui_status_item(title, val) {
    // TODO: CSS styles.  This is just a quick placeholder
    return $('<p>').html('<strong>' + title + ":</strong> " + val);
    /* Alt: Error: label only works for form fields
    return $('<div>').addClass('w2ui-field')
        .add( $('<label>').text(title)  )
        .add( $('<div>').text(val) )
    ;
    */
}
