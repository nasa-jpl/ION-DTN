SET GLOBAL sql_mode='NO_AUTO_VALUE_ON_ZERO';
SET SESSION sql_mode='NO_AUTO_VALUE_ON_ZERO';
SELECT @@GLOBAL.sql_mode;
SELECT @@SESSION.sql_mode;

drop database amp_core;