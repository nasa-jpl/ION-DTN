# JHU/APL
#
# Description: library file for utility functions related to verifying JSON
#
# Modification History:
#   YYYY-MM-DD     AUTHOR            DESCRIPTION
#   ----------     ---------------   -------------------------------
#   2017-11-30     Sarah             File creation
#   2018-01-02	   Evana	     Added functionality for tables
#   2018-01-05	   David	     Added new method for creating parameterized mids 
#
#############################################################################

import json

#
# Validates if the file with the passed filename
# is a validJSON file
# Returns True if so, False if not
#
def is_jsonFile(filename):
	try:
		myjson = open(filename,'r')
		json_object=json.load(myjson)
	except IOError, e:
		return False
	except ValueError, e:
		return False
	finally:
		myjson.close()

	return True

#
# Returns True if the passed string, myjson, is valid
# JSON, False if not
#
def is_jsonString(myjson):
	try:
		json_object=json.loads(myjson)
	except ValueError, e:
		print "JSON string is invalid. See error(s) below:"
		print e
		return False
	return True

