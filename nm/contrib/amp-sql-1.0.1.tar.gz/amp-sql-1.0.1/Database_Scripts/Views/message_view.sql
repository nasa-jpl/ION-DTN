-- NOTE: These Views assumes that lookup table for state_id is static.  state_id can be alternately represented as an enum in compatible databases

CREATE OR REPLACE VIEW vw_ready_outgoing_message_groups AS SELECT * FROM message_group WHERE is_outgoing = TRUE AND state_id=1;
CREATE OR REPLACE VIEW vw_ready_incoming_message_groups AS SELECT * FROM message_group WHERE is_outgoing = FALSE AND state_id=1;
CREATE OR REPLACE VIEW vw_message_agents AS SELECT ma.message_id, ra.* FROM message_agents ma LEFT JOIN registered_agents ra ON ma.agent_id=ra.registered_agents_id;
CREATE OR REPLACE VIEW vw_message_group_agents AS SELECT ma.group_id, ra.* FROM message_group_agents ma LEFT JOIN registered_agents ra ON ma.agent_id=ra.registered_agents_id;
