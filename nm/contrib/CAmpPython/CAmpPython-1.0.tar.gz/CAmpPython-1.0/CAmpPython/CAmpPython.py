#!/usr/bin/env python

# JHU/APL
# Description: Entrypoint into the CAmpPython program. Creates c and h files
# from JSON of different ADMs for use by protocols in DTN
#
# Modification History:
#   YYYY/MM/DD	    AUTHOR	   DESCRIPTION
#   ----------	  ------------	 ---------------------------------------------
#   2017-08-10	  David		 First implementation
#   2017-08-15	  Evana		 Clean up
#   2017-08-17	  David		 fixed mid converter
#   2017-08-23	  David		 Started convertion to command line tool
#   2017-11-01	  Sarah		 Documentation and minor fixups
##################################################################### 


import os
import argparse
import json
import re

from generators import create_gen_h
from generators import create_agent_c
from generators import create_mgr_c
from generators import create_impl_h
from generators import create_impl_c
from generators import create_mysql
from generators.lib.common import campsettings
from generators.lib.common import camputil 

from util import jsonutil
from util import name_registry as NR

#
# Sets up the format of command line arguments for CAmpPython,
# validates and returns arguments input on the command line
#
# Return value is a tuple (args, jsonfilename)
#
def handle_command_line_arguments():
	p = argparse.ArgumentParser(description = 'C code generator for Asychronous management protocols')

	# camp [-o PATH] [-s FILE] [-b B] [-n N] [-u] json
	
	p.add_argument('-o', '--out',         help="The ouput directory",                          default="./")
	p.add_argument('-c', '--scrapeC',     help="Previously generated c file to be scraped",    default=None)
	p.add_argument('-s', '--scrapeH',     help="Previously generated h file to be scraped",    default=None)
	
	p.add_argument('-n', '--nickname',    help="The integer nickname to use for this file",    default=-1, type=int)
	p.add_argument('-u', '--update-nn',   help="If this flag is set, nickname will be updated in name registry. Requires Root", action='store_true')
	
	p.add_argument('json',                help="JSON file to use for file generation")

	args = p.parse_args()	
	filename = args.json

	# Make sure the passed file is valid JSON
	if (not jsonutil.is_jsonFile(filename)):
		print "[ ERROR ] ", filename, " is not a valid JSON file\n"
		raise Exception

	return args, filename

#
# Makes the output directory if it doesn't already exist
# d_name is the path to the output directory
#
def set_up_outputdir(d_name):
	if(not os.path.isdir(d_name)):
		try:
			os.makedirs(d_name)
		except OSError, e:
			print "[ Error ] Failed to make output directory\n",
			print e
			raise

	
#
# Main function of CAmpPython
#
# Calls helper functions to initialize settings, read command line arguments,
# parse the input JSON file, and generate c and h files
#
def main():
	try:
		options, json_filename = handle_command_line_arguments()

		# Initialize settings and output dir with the options returned 
		campsettings.init()
		
		set_up_outputdir(options.out)

		passed_nn = options.nickname
	except Exception, e:
		return -1

	# Parse the JSON file
	print "Parsing " + json_filename + " ...",
	
	jfile = open(json_filename, 'r')
	myjson = json.load(jfile)
	jfile.close()
	
	print "\t[ DONE ]"

	try:
		nn = NR.handle_nickname(myjson, passed_nn, options.update_nn)
	except Exception, e:
		print e
		return -1

	# Pull in any "uses" files
	# XXX for now, assuming all JSON live in the same place
	path_to_uses,_ = os.path.split(json_filename)
	print "Loading all ADMs needed ...",
	uses_dict = camputil.build_uses_dict(myjson, path_to_uses)
	print "\t[ DONE ]"
	
	# Generate files for the JSON
	print "Generating files ..."
	create_impl_h.create(myjson, options.out, options.scrapeH)
	create_impl_c.create(myjson, options.out, options.scrapeC)
	create_mysql.create(myjson,options.out, uses_dict)
	create_gen_h.create(myjson, options.out, nn)
	create_mgr_c.create(myjson, options.out, uses_dict)
	create_agent_c.create(myjson, options.out, uses_dict)

	print "[ End of CAmpPython Execution ]\n"

	


if __name__ == '__main__':
	main()	
