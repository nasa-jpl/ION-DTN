USE amp_core;

-- STORED PROCEDURE(S)

-- DROP PROCEDURE IF EXISTS SP__insert_data_value; 
-- DELIMITER //
-- CREATE PROCEDURE SP__insert_data_value(IN p_value_converted varchar(255), p_value_string varchar(255), OUT r_value_id int(10) unsigned)
-- BEGIN
-- 	INSERT INTO amp_core.data_value(value_converted, value_string) VALUES(p_value_converted, p_value_string); 
--     SET r_value_id =  LAST_INSERT_ID();
-- END //
-- DELIMITER ;

