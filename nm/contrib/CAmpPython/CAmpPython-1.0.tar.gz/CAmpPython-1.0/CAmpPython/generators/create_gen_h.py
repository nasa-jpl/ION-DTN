# JHU/APL
# Description: This creates the h file for the public portions of an adm
# Modification History:
# YYYY-MM-DD  AUTHOR     DESCRIPTION
# ----------  ---------- -----------------------------
# 2017-08-10  Evana       
#	      David      cleaning up
#	      Evana      fix formatting
# 2017-08-14  Evana      cleaning up
# 2017-08-15  Evana	 fix formatting
# 2017-08-15  David	 Added AMP aris
# 2017-08-17  David      fixed ariconverter
# 2017-08-22  Evana      cleaning up
# 2017-11-15  Sarah      error handling and cleaning up
# 2017-12-27  David  change constants to require types 
# 2017-12-28     David 			Metadata is in constants now
#   2018-06-27   David 			Changed mids to aris	
########################################################

import re
import os 
import errno

from lib import campch
from lib.common import camputil as cu
from lib.common import campsettings as cs

nickname = -1

#
# Constructs and returns the filename for this generated file.
#
# Also creates the shared directory in the out directory
# if it doesn't exist.
#
# name is the name returned from a call to camputil.get_adm_names()
# outpath is the path to the output directory
#
def initialize_file(name, outpath):
	# Make the shared dir, only want to allow the 'directory exists' error
	try:
		os.mkdir(outpath + "/shared/")
	except OSError as ose:
		if(not ose.errno == errno.EEXIST):
			print "[ Error ] Failed to create subdirectory in ", outpath
			print ose
			exit(-1)

	filename = outpath + "/shared/" + name + ".h"
	return filename

#
# Writes the #defines for the generated file
# h_file is an open file descriptor to write to
# name and ns are the values returned from get_adm_names
#
def write_defines(h_file, name, ns):
	name_upper = name.upper();
	ns_upper = ns.upper();
	defines_str = (
		"\n#ifndef {0}_H_"
		"\n#define {0}_H_"
		"\n#define _HAVE_{1}_ADM_"
		"\n#ifdef _HAVE_{1}_ADM_"
		"\n")
	h_file.write(defines_str.format(name_upper, ns_upper))

#
# Writes the includes statements for this generated file
# h_file is an open file descriptor to write to
# ns is the ns returned from get_adm_names()
#
def write_includes(h_file, ns):
	files = ["../utils/nm_types.h", "adm.h" ]

	h_file.write(campch.make_includes(files))
	
#
# Writes the ADM template documentation for this generated file
# h_file is an open file descriptor to write to
# name is the colon-deliminated name returned from get_adm_names()
#
def write_adm_template_documentation(h_file, name):
	header_str = campch.make_formatted_comment_header("ADM TEMPLATE DOCUMENTATION", True, False)
	documentation_str = (
		"{} *"
		"\n * ADM ROOT STRING:{}"
		"\n */"
		"\n")
	h_file.write(documentation_str.format(header_str, name))

#
# Writes the agent nickname #defines enum to the file
#
def write_agent_nickname_definitions(h_file, ns, nn):
	h_file.write("#define ADM_ENUM_{0} {1}".format(ns.upper(), nn))
	header_str = campch.make_formatted_comment_header("AGENT NICKNAME DEFINITIONS", True, True)
	h_file.write(header_str)

	

#
# Function for formatting the description field in the tables.
# Wraps the description nicely and fills other cells in the
# row with empty spaces. Returns the string result
#
# descr is the string to format as a description.
# name_col_fmt is the format of the name column
# ari_col_fmt is the format of the ari column
# type_col_fmt is the format of the type column
# desc_col_sz is the size of the description column to fit to
# 
def format_table_description(descr, name_col_fmt, ari_col_fmt, type_col_fmt, value_col_fmt, desc_col_sz):
	result = []
	descr = descr.strip()

	# fill the rest of this row and the next one
	if value_col_fmt:
		fill_this_row = ("|" + type_col_fmt + "|" + value_col_fmt +"|\n") % ("", "")  # the rest of this row
	else:
		fill_this_row = ("|" + type_col_fmt + "|\n") % ("")  # the rest of this row

	start_next_row = (" * |" + name_col_fmt + "|" + ari_col_fmt + "|") % ("", "") # next row up until description column

	desc_fmt = '%-' + str(desc_col_sz) + '.' + str(desc_col_sz) + 's'
	
	# split because descriptions may contain new lines
	lines = descr.splitlines()
	num_lines = len(lines)
	for line_idx in range(0, num_lines):
		
		# This to wrap nicely inside the column
		line = lines[line_idx].strip()
		
		while len(line) > desc_col_sz:
			left, right = line[:desc_col_sz], line[desc_col_sz:]
			
			result.append(desc_fmt % (left))
			result.append(fill_this_row)
			result.append(start_next_row)
			line = right

		result.append(desc_fmt % (line))
		
		# If there are still lines to write, fill the row and start a new one
		if(line_idx < num_lines-1):
			result.append(fill_this_row)
			result.append(start_next_row)
			
	return "".join(result)

#
# Formats and returns a table entry to the passed file descriptor, fd, with
# the passed name, ari, description, and type (ttype)
#
# Centered is True if the entries should be centered in their columns, False
# if not. For now, centered only takes effect if all column entries are smaller
# than the column width.
#
def format_table_entry(centered, name, ari, desc, ttype, value):
	name_col_sz = 21
	ari_col_sz  = 14
	desc_col_sz = 38
	type_col_sz = 7
	value_col_sz   = 24


	
	# Set up each individual column's formatting
	if(centered and
	   # Centered only goes into effect if all are smaller than allocated column size
	   (len(name) <= name_col_sz) and (len(ari) <= ari_col_sz) and
	   (len(desc) <= desc_col_sz) and (len(ttype) <= type_col_sz) and
	   (len(value) <= value_col_sz)):
			
		name_ws = (" " * int(( name_col_sz - len(name) ) / 2))
		ari_ws  = (" " * int(( ari_col_sz  - len(ari)  ) / 2))
		desc_ws = (" " * int(( desc_col_sz - len(desc) ) / 2))
		type_ws = (" " * int(( type_col_sz - len(ttype)) / 2))
		value_ws = (" " * int(( value_col_sz - len(value) ) / 2))

		

		name_format = name_ws + "%s " + name_ws
		ari_format  = ari_ws  + "%s " + ari_ws
		type_format = type_ws + "%s " + type_ws
		value_format = value_ws + "%s " + value_ws
		
		desc_format = "%s"

		formatted_desc = desc_ws + desc + " " + desc_ws
	else:
		name_format = "%-" + str(name_col_sz) + "." + str(name_col_sz) + "s"
		ari_format  = "%-" + str(ari_col_sz)  + "." + str(ari_col_sz)  + "s"
		type_format = "%-" + str(type_col_sz) + "." + str(type_col_sz) + "s"
		value_format = "%-" + str(value_col_sz) + "." + str(value_col_sz) + "s"
		
		if value == "":
			value_format = ""

		desc_format = "%s"
		formatted_desc = format_table_description(desc, name_format, ari_format, type_format, value_format, desc_col_sz)


	# Put everything together, write and return
	if(value):
		entry_format   = " * |" + name_format + "|" + ari_format + "|" + desc_format + "|" + type_format + "|" + value_format + "|\n"
		# This formats the `+------+------+----+-----+` for the correct size of each column
		divider_format =(" * +" + ('-' * name_col_sz) + "+" + ('-' * ari_col_sz) +
	                    "+" + ('-' * desc_col_sz) + "+" + ('-' * type_col_sz) + "+" + ('-' * value_col_sz) + "+\n")
		
		return (entry_format % (name, ari, formatted_desc, ttype, value) + divider_format)


	else:
		entry_format   = " * |" + name_format + "|" + ari_format + "|" + desc_format + "|" + type_format + "|\n"
		
		# This formats the `+------+------+----+` for the correct size of each column
		divider_format =(" * +" + ('-' * name_col_sz) + "+" + ('-' * ari_col_sz) +
	                    "+" + ('-' * desc_col_sz) + "+" + ('-' * type_col_sz) + "+\n")
	
		return (entry_format % (name, ari, formatted_desc, ttype) + divider_format)

#
# Calls helper functions to write the header for a definition table to the
# passed fd with the passed definitions string in the center area
# results in:
# ```
#  * +-------------------------+
#  * |      definitions_str    +
#  * +-------------------------+
#  * +----+---+-----------+----+
#  * |NAME|ARI|DESCRIPTION|TYPE|
#  * +----+---+-----------+----+
# ```
# but spaced to standard width for this file (defined in campch.py)
#
def write_definition_table_header(fd, definitions_str):
	fd.write(campch.make_formatted_comment_header(definitions_str, True, False))
	
	fd.write(format_table_entry(True, "NAME", "ARI", "DESCRIPTION", "TYPE", ""))

#
# Writes the metadata definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names
# metadata is a list of the metadata to include
#
def write_metadata_definitions(h_file, ns, metadata):
	# The table comment section
	h_file.write(campch.make_formatted_comment_header(ns.upper() + " META-DATA DEFINITIONS", True, False))
	
	h_file.write(format_table_entry(True, "NAME", "ARI", "DESCRIPTION", "TYPE", "VALUE"))

	table   = ""
	defines = ""	
	count = 0
	for i in metadata:
		try:
			hex_str = format(count, '#04x')
			ari     = cu.convert_ari((nickname, cs.META, count, i))
			ari_str = cu.make_ari_name(ns, cs.META, i)

			table   = table   + format_table_entry(False, i["name"], ari, i["description"], i["type"], i["value"])

			defines = defines + "// \"{}\"\n".format(i["name"])			
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
			
		except KeyError, e:
			print "[ Error ] Badly formatted metadata. Key not found: "
			print e
			raise
		count += 1 

	h_file.write(table   + " */\n")
	h_file.write(defines + "\n")

#
# Writes the edd definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names
# edds is a list of edds to include
#
def write_edd_definitions(h_file, ns, edds):
	ns_upper = ns.upper()

	# the table comment section
	write_definition_table_header(h_file, ns_upper+" EXTERNALLY DEFINED DATA DEFINITIONS")

	table   = ""
	defines = ""
	count = 0
	for i in edds:
		try:
			hex_str = format(count, '#04x')
			ari     = cu.convert_ari((nickname, cs.EDD, count, i))
			ari_str = cu.make_ari_name(ns, cs.EDD, i)
			
			table   = table   + format_table_entry(False, i["name"], ari, i["description"], i["type"], "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted EDD. Key not found: "
			print e
			raise
		count += 1

	h_file.write(table   + " */\n")
	h_file.write(defines + "\n")

def create_ac(definition_list, name):
	ac = []
	
	for d in definition_list:
		d_adm, d_coll, d_name, parms = cu.parse_definition(d, name)


#
# Writes the variable definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names
# variables is a list of variables to include
#
def write_variable_definitions(h_file, ns, variables):
	ns_upper = ns.upper()

	# the table comment section
	write_definition_table_header(h_file, ns_upper+" VARIABLE DEFINITIONS")

	table   = ""
	defines = ""
	count = 0 
	# For each variable, write the commented table entry to file, and save to a string for the #define
	for i in variables:
		try:
			hex_str = format(count, '#04x')
			ari     = cu.convert_ari((nickname, cs.VAR, count, i))
			ari_str = cu.make_ari_name(ns, cs.VAR, i)
			
			table   = table   + format_table_entry(False, i["name"], ari, i["description"], i["type"], "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted variable. Key not found: "
			print e
			raise
		count += 1
		
	h_file.write(table + " */\n")
	h_file.write(defines + "\n")

#
# Writes the report template definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names()
# templates is a list of report templates to include
#
def write_rpt_definitions(h_file, ns, templates):
	ns_upper = ns.upper()

	# the table comment section
	write_definition_table_header(h_file, ns_upper+" REPORT DEFINITIONS")

	table   = ""
	defines = ""
	count = 0
	for i in templates:
		try:
			hex_str = format(count, '#04x')
			ari     = cu.convert_ari((nickname, cs.RPT, count, i))
			ari_str = cu.make_ari_name(ns, cs.RPT, i)
			
			table   = table   + format_table_entry(False, i["name"], ari, i["description"], "TNVC", "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted report-template. Key not found: "
			print e
			raise
		count += 1
		
	h_file.write(table   + " */\n")
	h_file.write(defines + "\n")

#
# Writes the table definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names()
# tbls is a list of tabels to include
#
def write_tbl_definitions(h_file, ns, tbls):
	ns_upper = ns.upper()

	# the table comment section
	write_definition_table_header(h_file, ns_upper+" TABLE DEFINITIONS")

	table   = ""
	defines = ""
	count = 0
	for i in tbls:
		try:
			hex_str = format(count, '#04x')
			ari     = cu.convert_ari((nickname, cs.TBL, count, i))
			ari_str = cu.make_ari_name(ns, cs.TBL, i)
	

			table   = table   + format_table_entry(False, i["name"], ari, i["description"], "", "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted table. Key not found: "
			print e
			raise
		count += 1

	h_file.write(table + " */\n")
	h_file.write(defines + "\n")
	
#
# Writes the control definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names()
# controls is a list of controls to include
#
def write_ctrl_definitions(h_file, ns, controls):
	ns_upper = ns.upper()

	# the table comment section
	write_definition_table_header(h_file, ns_upper+" CONTROL DEFINITIONS")

	table   = ""
	defines = ""
	count = 0
	for i in controls:
		try:
			hex_str = format(count, '#04x')
			ari     = cu.convert_ari((nickname, cs.CTRL, count, i))
			ari_str = cu.make_ari_name(ns, cs.CTRL, i)
	

			table   = table   + format_table_entry(False, i["name"], ari, i["description"], "", "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted control. Key not found: "
			print e
			raise
		count += 1

	h_file.write(table + " */\n")
	h_file.write(defines + "\n")

#
# Writes the constants definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names()
# constants is a list of constants to include
#
def write_const_definitions(h_file, ns, constants):
	ns_upper = ns.upper()

	# the table comment section
	h_file.write(campch.make_formatted_comment_header(ns.upper() + " CONSTANT DEFINITIONS", True, False))
	h_file.write(format_table_entry(True, "NAME", "ARI", "DESCRIPTION", "TYPE", "VALUE"))

	table   = ""
	defines = ""

	count = 0

	for i in constants:
		try:
			hex_str = format(count, '#04x')
			ari     = cu.convert_ari((nickname, cs.CONST, count, i))
			ari_str = cu.make_ari_name(ns, cs.CONST, i)
			
			table   = table   + format_table_entry(False, i["name"], ari, i["description"], i["type"], i["value"])
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted constant. Key not found: "
			print e
			raise
		count += 1
			
	h_file.write(table   + " */\n")
	h_file.write(defines + "\n")

#
# Writes the operator definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names()
# operators is a list of operators to include
#
def write_op_definitions(h_file, ns, operators):
	ns_upper = ns.upper()

	# the table comment section
	write_definition_table_header(h_file, ns_upper+" OPERATOR DEFINITIONS")

	table   = ""
	defines = ""
	count = 0
	for i in operators:
		try:
			hex_str = format(count, '#04x')
			ari     = cu.convert_ari((nickname, cs.OP, count, i))
			ari_str = cu.make_ari_name(ns,  cs.OP, i)
						      
			table   = table   + format_table_entry(False, i["name"], ari, i["description"], i["result-type"], "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted operator. Key not found: "
			print e
			raise
		count += 1
		
	h_file.write(table   + " */\n")
	h_file.write(defines + "\n")
	
#
# Writes the macro definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names()
# macros is a list of macros to include
#
def write_macro_definitions(h_file, ns, macros):
	ns_upper = ns.upper()

	# the table comment section
	write_definition_table_header(h_file, ns_upper+" MACRO DEFINITIONS")

	table   = ""
	defines = ""
	count = 0
	for i in macros:
		try:
			hex_str = format(count, '#04x')
			ari     = cu.convert_ari((nickname, cs.MACRO, count, i))
			ari_str = cu.make_ari_name(ns, cs.MACRO, i)
			
			table   = table   + format_table_entry(False, i["name"], ari, i["description"], "mc", "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted macro. Key not found: "
			print e
			raise
		count += 1

	h_file.write(table   + " */\n")
	h_file.write(defines + "\n")

#
# Writes the initialization functions' forward declars to the file
# h_file is an open file descriptor to write to
# name is the name returned by get_adm_names()
#
# TODO: should the names of the init functions not be hardcoded?
def write_initialization_functions(h_file, name, data):
	body = 	(
		"/* Initialization functions. */\n"
		"void {0}_init();\n"
		).format(name.lower())
	
	decl_fun_template = "void "+name.lower()+"_init_{0}();\n"

	# XXX: consider changing this to only colls in the data; but would have to change
	# EVERYWHERE to only be the colls in the data (_agent.c, _mgr.c also)
	for coll in [cs.META, cs.CONST, cs.EDD, cs.OP, cs.VAR, cs.CTRL, cs.MACRO, cs.RPT, cs.TBL]:
		body = body + decl_fun_template.format(cs.get_sname(coll).lower())

	h_file.write(body.format(name))

#
# Writes the end ifs for at the end of the file
# h_file is an open file desciptor to write to
# name and ns are the names returned by get_adm_names()
#
def write_endifs(h_file, name, ns):
	endifs_str = (
		"#endif /* _HAVE_{0}_ADM_ */\n"
		"#endif //{1}_H_")
	h_file.write(endifs_str.format(ns.upper(), name.upper()))
	
#
# Main function of this file, which calls helper funtions to
# orchestrate the creation of the generated file
#
# data: the dictionary from the parsed JSON file
# outpath: the output directory
#
def create(data, outpath, nn):
	global nickname
	nickname = nn

	if nn < 0:
		print "[ Error ] Cannot create ", filename, ": ADM not included in NAME REGISTRY"
		return 
	
	try:
		name, ns = cu.get_adm_names(data)
		namespace = cu.get_namespace(data)

		filename = initialize_file(name, outpath)
		h_file = open(filename,"w")
	except KeyError, e:
		print "[ Error ] JSON does not include valid metadata"
		print e
		return
	except IOError, e:
		print "[ Error ] Failed to open ", filename, " for writing."
		print e
		return

	print "Working on ", filename, 
	
	campch.write_h_file_header(h_file, filename)

	write_defines(h_file, name, ns)	
	write_includes(h_file, ns)

	g_var_idx = cu.make_g_var_idx(ns)
	h_file.write("extern vec_idx_t {}[11];\n\n".format(g_var_idx))
	
	write_adm_template_documentation(h_file, namespace)

	
	write_agent_nickname_definitions(h_file, ns, nn)

	try:
		write_metadata_definitions(h_file, ns, cu.get_metadata(data))

		write_edd_definitions(     h_file, ns, cu.get_edds(data))
		write_variable_definitions(h_file, ns, cu.get_variables(data))
		write_rpt_definitions(     h_file, ns, cu.get_reports(data))
		write_tbl_definitions(     h_file, ns, cu.get_tables(data))
		write_ctrl_definitions(    h_file, ns, cu.get_controls(data))

		write_const_definitions(h_file, ns, cu.get_constants(data))
		write_macro_definitions(h_file, ns, cu.get_macros(data))
		write_op_definitions(   h_file, ns, cu.get_operators(data))
	except KeyError, e:
		return
	finally:
		write_initialization_functions(h_file, ns, data)
		write_endifs(h_file, name, ns)
		h_file.close()

	print "\t\t[ DONE ]"	
	


