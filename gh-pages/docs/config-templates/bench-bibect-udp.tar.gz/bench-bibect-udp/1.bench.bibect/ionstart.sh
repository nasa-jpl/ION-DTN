#!/usr/bin/bash
rm -f core.*
rm -f bpacq.*
rm -f ion.log

ionadmin n1.ionrc
sleep 1
ionadmin contacts.ionrc
sleep 1
ionsecadmin n1.ionsecrc
sleep 1
bpadmin n1.bprc
sleep 1