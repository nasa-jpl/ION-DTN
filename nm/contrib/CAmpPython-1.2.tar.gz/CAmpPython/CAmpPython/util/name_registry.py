#
# JHU/APL
#
# Description: Helper functions for accessing and modifying entries in the name
#              registry
#
# Modification History:
#   YYYY-MM-DD     AUTHOR            DESCRIPTION
#   ----------     ---------------   -------------------------------
#   2018-03-28	   Sarah  	     File Creation 
#   2018-06-14	   David	     Update to a .cfg file and using ConfigParser
#
#############################################################################

import os
import re
import ConfigParser
from configobj import ConfigObj

#
# Finds the integer value for this type in the name_registry file if it exists
# hr_nickname is the human-readable nickname to look for
# returns the integer value if found, < 0 if not found.
#
def find_nickname(hr_nickname, config):
	hold = hr_nickname.split('/')
	namespace, adm = hold[:-1], str(hold[-1]).strip()

	try:
		hold = config
		for s in namespace:
			hold = hold.get(str(s))

		return int(hold.get(adm))
	except:
		return -1

#
# Adds the passed name and nickname to the name_registry.cfg file
#
def add_to_registry(name, passed_nn, config):
	hold = name.split('/')
	namespace, adm = hold[:-1], str(hold[-1]).strip()

	try:		
		print "\tAdding to name registry: ", name, "=", str(passed_nn)
		hold = config
		for n in namespace: 
			if(str(n) not in hold):
				hold[str(n)] = {}
	
			hold = hold[str(n)]
		
		hold[adm] = passed_nn
	except Exception, e:
		print "\t[ Warning ] Unable to Add adm to name_registry.cfg. Passed value will still be used for file generation."
		print "\t"+str(e)
		

#
# Updates the passed name in the name registry with the passed value
#
def update_registry(name, passed_nn, config):
	hold = name.split('/')
	namespace, adm = hold[:-1], str(hold[-1]).strip()	
		
	try:	
		hold = config
		for n in namespace: 
			hold = hold[str(n)]
		
		hold[adm] = passed_nn
	except Exception, e:
		print "\t[ Warning ] Unable to update name_registry.cfg. Passed value will still be used for file generation."
		print "\t"+str(e)


#
# Finds the existing nickname for the passed namespace:
#  - If a nickname was passed, returns that nickname (user's passed value takes
#    priority over stored value)
#  - If a nickname was passed and update_flag is set, adds the passed
#    nickname to the name registry, or updates the name registry with the
#    passed value.
# Returns integer nickname value
# Raises exception if no nickname is found (passed or in name_registry)
#
def handle_nickname(namespace, passed_nn, update_flag):
	path = os.path.join((os.path.abspath(os.path.dirname(__file__))), '../data', "name_registry.cfg")
	config = ConfigObj(path)

	current_nn = find_nickname(namespace, config)
	
	if(update_flag and passed_nn == -1):
		print"Warning: nickname update request but no new nickname supplied. Inlcude a new nickname with -n NICKNAME\nContinuing..."
	
	# integer value not present in name_registry and not passed via command line
	if(current_nn == -1 and passed_nn == -1):
		print "[Error] this ADM is not present in the name registry. Pass integer value via command line or set manually in name_registry.cfg"
		raise Exception

	# present in name registry, but not on command line
	elif (passed_nn == -1):
		return current_nn

	# value only on command line
	elif(current_nn == -1):
		if(update_flag):
			add_to_registry(namespace, passed_nn, config)
			
			# Writing our configuration file 
			config.write()

		return passed_nn

	# both are set, favor user's passed value, but print warning
	else:
		if(current_nn != passed_nn):
			print "Warning: this JSON already has value of "+str(current_nn)+" in name_registry. Using passed value of "+str(passed_nn)
			if(update_flag):
				update_registry(namespace, passed_nn, config)
			
				# Writing our configuration file
				config.write()
			    
		return passed_nn

	
	
