# JHU/APL
# Description: This creates ACE files
#
########################################################


from lib.common import camputil as cu
from lib.common.camputil import Retriever
from lib.common import campsettings as cs
import json


dictionary = {}
nickname = -1

#
# Format the ARI name for the ACE files
# TODO: this is very similar to a function in camputil.py. Just a slightly
# different format. If this is changed to match, switch to use the existing
# helper function instead
#
def make_ari_name(ns, coll, i):
	template = "{0}/{1}.{2}"
	return template.format(ns, cs.get_lname(coll), i["name"]).upper()

#
# Again, very similar to something in camputil.py, but we need a
# slightly different format here. Would be good to consolidate
#
def make_full_ns(ns):
	template = "{0}:{1}"
	ana = "IANA"   # TODO: fix hardcoding

	# replace the / between the DTN and the ADM with .
	ns = ns.replace("/", ".")

	return template.format(ana, ns).upper()

#
# Returns a string representation of the cbor-encoded representation of passed
# parameter type.
#
def get_type_encoding(ptype):
	#define dictionary that contains primitive data types
	# TODO: this should probably be moved to campsettings
	Type_Prim = {'BOOL': 10, 'BYTE': 11, 'STR': 12, 'INT': 13, 'UINT': 14,
		     'VAST': 15, 'UVAST': 16, 'REAL32': 17, 'REAL64': 18,
		     'TV':20, 'TS':21, 'TNV':22, 'TNVC':23, 'ARI':24, 'AC':25,
		     'EXPR':26, 'BYTESTR':27}
	
	try:
		return str(Type_Prim[ptype])
	except KeyError, e:
		print "[ Error ] Badly formatted collection. Key not found: " + str(e)
		raise

#
# populates the dictionary for the passed data
#
def gather_data(retriever, ns, data, coll):
	for idx, i in enumerate(data):
		ari_list = []
		try:
			ari_str = make_ari_name(ns, coll, i)
			ari     = cu.convert_ari_wo_flags(nickname, coll, idx)
			ari_list.append(ari)
			
			# Add the parameter types
			params = retriever.item_get_parms(i)
			for p in params:
				ptype = get_type_encoding(p["type"]) # TODO: fix hardcoding
				ari_list.append(ptype)

			dictionary[ari_str] = ari_list
			
		except KeyError, e:
			print "[ Error ] Badly formatted collection. Key not found: " + str(e)
			raise
	
#
# Main function of this file, which calls helper funtions to
# orchestrate the creation of the generated file
#
# data: the dictionary from the parsed JSON file
# outpath: the output directory
#
def create(retriever, outpath, nn):
	global nickname
	nickname = nn

	if nn < 0:
		print "[ Error ] Cannot create ", filename, ": ADM not included in NAME REGISTRY"
		return 
	
	try:
		name, _ = retriever.get_adm_names()
		ns = retriever.get_ns()
		ns = make_full_ns(ns)
	except KeyError, e:
		print "[ Error ] JSON does not include valid metadata"
		print e
		return

	filename, h_file = cu.initialize_file(outpath, "ace", name, ".json")
	if not h_file:
		return

	print "Working on ", filename, 
	
	try:
		gather_data(retriever, ns, retriever.get_metadata(), cs.META)
		gather_data(retriever, ns, retriever.get_edds(),     cs.EDD)
		gather_data(retriever, ns, retriever.get_variables(),cs.VAR)
		gather_data(retriever, ns, retriever.get_reports(),  cs.RPTT)
		gather_data(retriever, ns, retriever.get_tables(),   cs.TBLT)
		gather_data(retriever, ns, retriever.get_controls(), cs.CTRL)
		gather_data(retriever, ns, retriever.get_constants(),cs.CONST)
		gather_data(retriever, ns, retriever.get_macros(),   cs.MACRO)
		gather_data(retriever, ns, retriever.get_operators(),cs.OP)

	except KeyError, e:
		return
	finally:
		h_file.write(json.dumps(dictionary,indent=1, sort_keys=True))
		h_file.close()

	print "\t\t[ DONE ]"
	


