/*****************************************************************************
 **
 ** File Name: table.h
 **
 ** Description: This implements a typed table template and instances of that
 **              template.
 **
 ** Notes:
 **   - Tables are ephemeral and exist only when they are created to be
 **     returned in reports.
 **   - Table templates are AMM objects that are stored and updated.
 **
 ** Assumptions:
 **
 ** Modification History:
 **  MM/DD/YY  AUTHOR         DESCRIPTION
 **  --------  ------------   ---------------------------------------------
 **  05/15/16  E. Birrane    Initial Implementation. (Secure DTN - NASA: NNX14CS58P)
 **  09/30/18  E. Birrane    Updated to AMP v0.5. (JHU/APL)
 *****************************************************************************/
#ifndef TABLE_H_
#define TABLE_H_

#include "stdint.h"

#include "../utils/nm_types.h"

/*
 * +--------------------------------------------------------------------------+
 * |							  CONSTANTS  								  +
 * +--------------------------------------------------------------------------+
 */

#define TBL_DEFAULT_ENC_SIZE  1024
#define TBLT_DEFAULT_ENC_SIZE 1024

/*
 * +--------------------------------------------------------------------------+
 * |							  	MACROS  								  +
 * +--------------------------------------------------------------------------+
 */


/*
 * +--------------------------------------------------------------------------+
 * |							  DATA TYPES  								  +
 * +--------------------------------------------------------------------------+
 */


typedef struct
{
	amp_type_e type;
	char *name;
} tblt_col_t;


typedef struct
{
	ari_t id;      /* The ID of the template. */
	vector_t cols; /* Column information for each col. (table_col_t*). */

	db_desc_t desc;
} tblt_t;


typedef struct
{
	ari_t    id;   /**> The ID of the table template that this populates. */
	vector_t rows; /**> Vector of rows in the table. (tnvc_t*) */
} tbl_t;


/*
 * +--------------------------------------------------------------------------+
 * |						  FUNCTION PROTOTYPES  							  +
 * +--------------------------------------------------------------------------+
 */

int      tbl_add_row(tbl_t *tbl, tnvc_t *row);

void     tbl_clear(tbl_t *tbl);

tbl_t*   tbl_create(ari_t *id);

tbl_t*   tbl_deserialize_ptr(CborValue *it, int *success);

tbl_t*   tbl_deserialize_raw(blob_t *data, int *success);

tnvc_t*  tbl_get_row(tbl_t *tbl, int row_idx);

void     tbl_release(tbl_t *tbl, int destroy);

int      tbl_num_rows(tbl_t *tbl);

CborError tbl_serialize(CborEncoder *encoder, tbl_t *tbl);

blob_t*   tbl_serialize_wrapper(tbl_t *tbl);





/* tbl Template Functions */

int       tblt_add_col(tblt_t *tblt, amp_type_e type, char *name);


void      tblt_cb_del_fn(void *item);
void*     tblt_cb_copy_fn(void *item);


int       tblt_check_row(tblt_t *tblt, tnvc_t *row);

tblt_t*   tblt_copy_ptr(tblt_t *tblt);

tblt_t*   tblt_create(ari_t *id);

amp_type_e tblt_get_type(tblt_t *tblt, int idx);

vector_t  tblt_deserialize_names(CborValue *it, size_t num, int *success);
tblt_t*   tblt_deserialize_ptr(CborValue *it, int *success);

tblt_t*   tblt_deserialize_raw(blob_t *data, int *success);

int       tblt_num_cols(tblt_t *tblt);

void      tblt_release(tblt_t *tblt, int destroy);

CborError tblt_serialize(CborEncoder *encoder, tblt_t *tblt);

blob_t*   tblt_serialize_types(tblt_t* tblt);


blob_t*   tblt_serialize_wrapper(tblt_t *tblt);



void      tblt_col_cb_del_fn(void *item);
void*     tblt_col_cb_copy_fn(void *item);


#endif // TABLE_H_
