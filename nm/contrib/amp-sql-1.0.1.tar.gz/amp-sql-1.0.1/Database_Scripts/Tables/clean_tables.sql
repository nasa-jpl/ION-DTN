-- cleaning out the tables 

use amp_core;

DELETE FROM adm;
DELETE FROM amp_core.namespace;

DELETE FROM amp_core.edd_formal_definition 
WHERE
    TRUE;

DELETE FROM amp_core.adm 
WHERE
    TRUE;

DELETE FROM amp_core.ari_collection 
WHERE
    TRUE;

DELETE FROM amp_core.ari_collection_entry 
WHERE
    TRUE;

DELETE FROM amp_core.expression 
WHERE
    TRUE;

DELETE FROM amp_core.obj_formal_definition 
WHERE
    TRUE;

DELETE FROM amp_core.obj_metadata
WHERE
    TRUE;

DELETE FROM amp_core.obj_actual_definition 
WHERE
    TRUE;

DELETE FROM amp_core.operator_actual_definition 
WHERE
    TRUE;

DELETE FROM amp_core.variable_actual_definition 
WHERE
    TRUE;

DELETE FROM amp_core.control_formal_definition;

DELETE FROM amp_core.control_actual_definition;

DELETE FROM `amp_core`.`outgoing_message_set`
WHERE TRUE;

DELETE FROM `amp_core`.`incoming_message_set`
WHERE TRUE;

DELETE FROM `amp_core`.`formal_parmspec`
WHERE TRUE;

DELETE FROM amp_core.registered_agents
Where TRUE;







