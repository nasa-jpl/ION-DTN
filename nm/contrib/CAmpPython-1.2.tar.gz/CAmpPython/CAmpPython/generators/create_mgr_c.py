# JHU/APL
# Description: creates the c file for the public version of the adm
# Modification History:
#   YYYY-MM-DD     AUTHOR            DESCRIPTION
#   ----------     ---------------   -------------------------------
#   2017-08-11		Evana
#	2017-12-28      David 			Metadata is in constants now
#   2018-06-27      David 			Changed mids to aris	

###############################################

from lib import campch
from lib.common import camputil as cu
from lib.common import campsettings as cs

# meta_add_parm() function commonly used by many of the functions in this file
add_parm_template = "\n\tmeta_add_parm(meta, \"{0}\", {1});"

#
# Writes all of the #includes for this file
#
# c_file is an open file descriptor to be written to
# name is the name provided by get_adm_names()
# retriever is the Retriever class instance for this data
#
def write_includes(c_file, name, retriever):
	files = ["ion.h", "platform.h",
		 "{}.h".format(name),
		 "shared/utils/utils.h", "shared/primitives/report.h",
		 "shared/primitives/blob.h",
		 "metadata.h", "nm_mgr_ui.h"]

	c_file.write(campch.make_includes(files))

	# Adds #includes calls for all of the adms in the "uses"
	# construct of the ADM
	files = campch.get_uses_h_files(retriever)
	c_file.write(campch.make_includes(files))

#
# Write the #defines to the open file descriptor passed, c_file
# short name is the short name value returned by get_adm_names()
#
def write_defines(c_file, ns):
	ns_upper = ns.upper()
	define_str = (
		"\n#define _HAVE_{0}_ADM_"
		"\n#ifdef _HAVE_{0}_ADM_"
		"\n")
	c_file.write(define_str.format(ns_upper))

#
# Writes the top-level init function that calls all of the other ones
# c_file is an open file descriptor to write to
# name is the name returned from get_adm_names()
#
def write_init_function(c_file, name, g_var_idx, retriever):
	campch.write_init_function(c_file, name, g_var_idx, retriever, True)

#
# Iterates through all of the parameters passed and returns
# a string with the meta_add_parm(...) calls for all parameters.
# Caller needs to generate `metadata_t *meta` string.
#
def make_add_parms_str(parms):
	add_parms_str = ""	
	for p in parms:
		try:
			p_type = cu.make_amp_type_name(p)
			add_parms_str = add_parms_str + add_parm_template.format(p["name"], p_type)
		except KeyError, e:
			print "[ Error ] Badly formatted parameter. Key not found:"
			print e
			raise

	return add_parms_str


# Builds a template for the
# ```
# id = adm_build_ari(...)
# adm_add_...
# ```
# calls with passed collection type and adm name. Should be formatted in the calling
# function with:
# return_str.format([0|1](for whether params are present or not), ari_name, ari_amp_type, item[name], item[description])
#
# The intention behind this function is to only have to construct these parts once for each
# collection. Subset of formatted values that need to be substituted for_each_ item in the
# collection is much smaller.
#
def make_std_adm_build_add_template(coll, g_var_idx):
	add_str = campch.make_adm_build_ari_template(coll, g_var_idx, True)
	add_str = add_str + "\n\tadm_add_"  + cs.get_sname(coll).lower() + "(id, NULL);" 

	return add_str

#
# A lot of the collections in the mgr file follow the same pattern for their init
# function. This method encapsulates that.
#
# c_file is the file to write to, name is the name of the adm,
# g_var_idx is the g_*_idx variable created in the main function
# coll_type is the type of collection we're working with (cs.META, etc)
# retriever is the Retriever class instance for this ADM
#
# XXX: this is only used by two collections, reconsider breaking this out as a
# 'standard' (std) method.
#
def write_mgr_std_init_funct(c_file, name, g_var_idx, coll_type, retriever):
	body = ""
	coll_decl_str = "\n\tari_t *id = NULL;\n"
	parm_decl_str = "\n\tmetadata_t *meta = NULL;\n"
	add_str_template  = make_std_adm_build_add_template(coll_type, g_var_idx)
	meta_add_template = campch.make_std_meta_add_coll_template(coll_type, name)

	added_coll = False
	added_parm = False

	coll = retriever.get_collection(coll_type)
	for i in coll:
		try:
			# Gather all of the pieces of data we need
			ari      = cu.make_ari_name(name, coll_type, i)
			amp_type = cu.make_amp_type_name(i)
			parms    = retriever.item_get_parms(i)

			# format the meta_add_.* template for this item
			meta_add_str = meta_add_template.format(amp_type, i["name"], i["description"])

			# Make the string to add the parms in the function
			add_parms_str = make_add_parms_str(parms)

			# A couple of variables depend on the presence or absence of parms
			parms_tf     = "0"
			if(add_parms_str != ""):
				parms_tf     = "1"
				meta_add_str = "meta = " + meta_add_str
				added_parm   = True
			
			# Add everything to the body of the function
			body = body + add_str_template.format(parms_tf, ari)
			body = body + "\n\t" + meta_add_str
			body = body + add_parms_str
			
			added_coll = True		
				
		except KeyError, e:
			print "[ Error ] Badly formatted " + cs.get_lname(coll_type) + ". Key not found:"
			print e
			raise
		
	# This ensures that the ari_t *id variable is only declared if it is going to be used.
        # Avoids compiler warnings for unused variables
	if (added_parm):
		body = parm_decl_str + body
	if (added_coll) :
		body = coll_decl_str + body
		
	campch.write_formatted_init_function(c_file, name, coll_type, body)

#
# Writes the init_metadata() function to the open file descriptor passed as c_file
# name and ns are the values returned from get_adm_names()
# metadata is a list of the metadata to include
#
def write_init_metadata(c_file, name, g_var_idx, retriever):
	body = ""
	coll_decl_str = "\n\tari_t *id = NULL;\n"
	parm_decl_str = "\n\tmetadata_t *meta = NULL;\n"

	meta_add_template = campch.make_std_meta_add_coll_template(cs.CONST, name)
	
	# NOTE: this function uses the CONST modifiers for most things, but needs the META IDX here:
	const_idx = cs.get_adm_idx(cs.CONST)
	meta_idx  = cs.get_adm_idx(cs.META)
	add_str_template = make_std_adm_build_add_template(cs.CONST, g_var_idx).replace(const_idx, meta_idx)

	added_coll = False
	added_parm = False

	metadata = retriever.get_metadata()
	for i in metadata:
		try:
			# Preliminary; gather all of the pieces of data we need
			ari      = cu.make_ari_name(name, cs.META, i)
			amp_type = cu.make_amp_type_name(i)
			parms = retriever.item_get_parms(i)

			# format the meta_add_.* template for this item
			meta_add_str = meta_add_template.format(amp_type, i["name"], i["description"])

			# Make the string to add the parms in the function
			add_parms_str = make_add_parms_str(parms)

			# A couple of variables depend on the presence or absence of parms
			parms_tf = "0"
			if(add_parms_str != ""):
				parms_tf = "1"
				meta_add_str = "meta = " + meta_add_str
				added_parm = True

			# Add everything to the body of the function
			body = body + add_str_template.format(parms_tf, ari)
			body = body + "\n\t" + meta_add_str
			body = body + add_parms_str
			
			added_coll = True		
				
		except KeyError, e:
			print "[ Error ] Badly formatted " + cs.get_lname(cs.META) + ". Key not found:"
			print e
			raise
		
	# This ensures that the ari_t *id variable is only declared if it is going to be used.
        # Avoids compiler warnings for unused variables
	if (added_parm):
		body = parm_decl_str + body
	if (added_coll) :
		body = coll_decl_str + body
		
	campch.write_formatted_init_function(c_file, name, cs.META, body)

#
# Writes the init_constants() function to the open file descriptor passed as c_file
# name is the value returned from get_adm_names()
# constants is a list of constants to include
#
def write_init_constants(c_file, name, g_var_idx, retriever):
	write_mgr_std_init_funct(c_file, name, g_var_idx, cs.CONST, retriever)

#
# Writes the init_edds function to the passed open file c_file
# name and ns are the values returned by get_adm_names()
# edds is a list of edds to include
#
def write_init_edd_function(c_file, name, g_var_idx, retriever):
	write_mgr_std_init_funct(c_file, name, g_var_idx, cs.EDD, retriever)

	
#
# Writes the init_operators() function to the open file descriptor passed as c_file
# name is the value returned from get_adm_names()
# operators is a list of the operators to include
#
def write_init_ops(c_file, name, g_var_idx, retriever):
	body = ""
	coll_decl_str = "\n\tari_t *id = NULL;\n"
	parm_decl_str = "\n\tmetadata_t *meta = NULL;\n"
	
	add_op_ari_template = "\n\tadm_add_op_ari(id, {}, NULL);"
	build_str_template  = campch.make_adm_build_ari_template(cs.OP, g_var_idx, True)
	meta_add_template   = campch.make_std_meta_add_coll_template(cs.OP, name)

	added_coll = False
	added_parm = False

	operators = retriever.get_operators()
	for i in operators:
		try:
			# Preliminary; gather all of the pieces of data we need
			ari      = cu.make_ari_name(name, cs.OP, i)
			amp_type = cu.make_amp_type_name_from_str(i["result-type"])
			parms    = retriever.item_get_in_types(i)

			# Format the meta_add_.* template for this item
			meta_str = meta_add_template.format(amp_type, i["name"], i["description"])

			# A couple of variables depend on the presence or absence of parms
			parms_tf = "0"
			if parms :
				parms_tf = "1"
				added_parm = True
				meta_str = "meta = " + meta_str

			# Add formatted strings to the body of the function
			body = body + "\n" + build_str_template.format(parms_tf, ari)		
			body = body + add_op_ari_template.format(len(parms))
			body = body + "\n\t" + meta_str
			
			for idx,p in enumerate(parms):
				parm_type = cu.make_amp_type_name_from_str(p)
				body = body + add_parm_template.format("O{}".format(idx+1), parm_type)
			
			added_coll = True			
				
		except KeyError, e:
			print "[ Error ] Badly formatted " + cs.get_lname(cs.OP) + ". Key not found:"
			print e
			raise
		
	# This ensures that the ari_t *id variable is only declared if it is going to be used.
        # Avoids compiler warnings for unused variables
	if (added_parm):
		body = parm_decl_str + body
	if (added_coll) :
		body = coll_decl_str + body
		
	campch.write_formatted_init_function(c_file, name, cs.OP, body)

#
# Writes the init_variables() function to the open file descriptor passed as c_file
# name is the value returned from get_adm_names()
# variables is a list of variables to include
#
def write_init_variables_function(c_file, name, g_var_idx, retriever):
	campch.write_init_var_function(c_file, name, g_var_idx, retriever, True)

#
# Writes the init_controls() function to the open file descriptor passed as c_file
# name is the value returned from get_adm_names()
# controls is a list of controls to include
#
def write_init_controls_function(c_file, name, g_var_idx, retriever):
	body = ""
	coll_decl_str = "\n\tari_t *id = NULL;\n"
	parm_decl_str = "\n\tmetadata_t *meta = NULL;\n"
	
	build_str_template   = campch.make_adm_build_ari_template(cs.CTRL, g_var_idx, True)
	add_ctrldef_template = "\n\tadm_add_ctrldef_ari(id, {}, NULL);"	
	enum_name            = cu.make_enum_name_from_str(name)
	meta_add_template    = "meta_add_" + cs.get_sname(cs.CTRL).lower() + "(id, " + enum_name + ", \"{0}\", \"{1}\");\n"

	added_coll = False
	added_parm = False

	controls = retriever.get_controls()
	for i in controls:
		try:
			# Gather the pieces of data that we need
			ari   = cu.make_ari_name(name, cs.CTRL, i)
			parms = retriever.item_get_parms(i)

			# Format the meta_add_.* template for this item
			meta_str = meta_add_template.format(i["name"], i["description"])

			# A couple of variables depend on the presence or absence of parms
			parms_tf = "0"
			if parms :
				parms_tf = "1"
				added_parm = True
				meta_str = "meta = " + meta_str

			# Add formatted strings to the body of the function
			body = body + "\n\n\t/* {} */".format(i["name"].upper())
			body = body + "\n" + build_str_template.format(parms_tf, ari)		
			body = body + add_ctrldef_template.format(len(parms))
			body = body + "\n\t" + meta_str
			
			for p in parms:
				parm_type = cu.make_amp_type_name(p)
				body = body + add_parm_template.format(p["name"], parm_type)
			
			added_coll = True			
				
		except KeyError, e:
			print "[ Error ] Badly formatted " + cs.get_lname(cs.CTRL) + ". Key not found:"
			print e
			raise
		
	# This ensures that the ari_t *id variable is only declared if it is going to be used.
        # Avoids compiler warnings for unused variables
	if (added_parm):
		body = parm_decl_str + body
	if (added_coll) :
		body = coll_decl_str + body
		
	campch.write_formatted_init_function(c_file, name, cs.CTRL, body)


#
# Writes the init_macros() function to the open file descriptor passed as c_file
# name is the value returned from get_adm_names()
# macros is a list of macros to include
#
def write_init_macros(c_file, name, g_var_idx, retriever):
	campch.write_init_macro_function(c_file, name, g_var_idx, retriever, True)


#
# Writes the init_reports() function to the open file descriptor passed as c_file
# name is the value returned from get_adm_names()
#
def write_init_reports(c_file, name, g_var_idx, retriever):
	campch.write_parameterized_init_reports_function(c_file, name, g_var_idx, retriever, True)

#
# Writes the init_tables() function to the open file descriptor passed as c_file
# name is the value returns from get_adm_names()
#
def write_init_tables(c_file, name, g_var_idx, retriever):
	campch.write_init_tables_function(c_file, name, g_var_idx, retriever, True)
	
#
# Main function of this file, which calls helper functions to
# orchestrate the creation of the generated file
#
# data: the dictionary made from a parsed JSON file
# outpath: the output directory
# uses: the dictionary of the imported JSON files
#
def create(retriever, outpath):
	try:
		name, ns = retriever.get_adm_names()
	except KeyError, e:
		print "[ Error ] JSON does not include valid metadata"
		print e
		return
		
	filename, c_file = cu.initialize_file(outpath, "mgr", name, "_mgr.c")
	if not c_file:
		return

	print "Working on ", filename,
	
	campch.write_c_file_header(c_file, filename)

	# calling each of the helper functions to handle the writing of
	# various functions in this file
	write_includes(c_file, name, retriever)
	
	write_defines(c_file, ns)

	g_var_idx = retriever.get_g_var_idx()
	c_file.write("static vec_idx_t {}[11];\n\n".format(g_var_idx))

	write_init_function(c_file, ns, g_var_idx, retriever);
	try:
		write_init_metadata(    c_file, ns, g_var_idx, retriever)

		write_init_constants(   c_file, ns, g_var_idx, retriever)

		write_init_edd_function(c_file, ns, g_var_idx, retriever)
		write_init_ops(         c_file, ns, g_var_idx, retriever)

		write_init_variables_function(c_file, ns, g_var_idx, retriever)
		write_init_controls_function( c_file, ns, g_var_idx, retriever)

		write_init_macros( c_file, ns, g_var_idx, retriever)
		write_init_reports(c_file, ns, g_var_idx, retriever)
		write_init_tables( c_file, ns, g_var_idx, retriever)
		
		c_file.write("#endif // _HAVE_"+ns.upper()+"_ADM_\n")

	except KeyError, e:
		print "[ Error ] Create_Mgr_C. Key not found:"
		print e
	except Exception, e:
		print "[ Error ] Create_Mgr_C"
		print e
	finally:
		c_file.close()
	
	print "\t[ DONE ]"
