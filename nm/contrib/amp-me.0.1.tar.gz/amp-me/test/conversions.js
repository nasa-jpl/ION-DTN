/*
- Load inputs.json, and parse all through verify_truths()
- Load sql_inputs.json, and pasre all, providing that we have a SQL connection
   - We will use a dedicated test set for sql as behavior may differ for some object types. Or a flag
   - We may need to split sql tests into a seperate test file entirely, TBD.
     - This will also help since SQL tests must be sequential, whereas all others can be async

SQL Testing Notes
- Always execute in a transaction which we will nominally cancel at the end of the test instead of committing
- Test Mode 1: fromSql specifies an ID to query
- Test Mode 1a: FromSql specifies an ID to query, but an alternate function name/mode to do it (ie: tnvc has two modes)
- Test Mode 2: toSql - boolean indicating we should try serializing into sql, and immediately deserialize back into a new obj
*/

// Testing tools
//const fs = require('fs');
//const chai = require('chai');
//chai.use(require('chai-as-promised'));
import * as fs from 'fs';
import chai from 'chai';
import * as colors from 'colors'; // For clearer debug output
const assert = chai.assert;
const expect = chai.expect;


// Project includes
import { CBOR } from "../lib/shared/cbor.js";
import * as AMP from "../lib/amp-sql.js";


// Test settings
var inputFile = "test/inputs.json"; // TODO: Make this configurable
var verbose = 1; // TODO: Command-line parsing
var inputs;
var db;

await main();

async function main() {
    // TODO: If providing SQL functionality in this test, initialize DB here, AND a transaction

    await AMP.Registry.getInstance("lib/shared/adms");
    try {
        db = await AMP.connectDb();
        console.log("Connection established.  Trying to begin transaction".green);
        //await db.beginTransaction(); // Run all tests in a transaction
        // TODO: Do this before each sql test step.
    } catch(e) {
        // TODO: chai-ify this
        console.log("WARNING: DB connection not available. Related tests will be SKIPPED.".yellow, e);
    }
    
    // Load Input Data
    inputs = JSON.parse(fs.readFileSync(inputFile));

    for(var i = 0; i < inputs.length; i++) {
        try {
            var input = inputs[i];
        
            var title;
            if (input.title) { title = input.title; }
            else if (input.uri) { title = input.uri; }
            else if (input.cbor) { title = input.cbor; }
            else { title = input.toString(); }
            console.log("Parsing".green, "[",i,"] ", title.cyan);
            await verify_truths( input );
        } catch (e) {
            // TODO: Make this more Mocha/Chai friendly
            console.log("Exception Thrown. Current AMP Trace is: ", AMP.trace.tracing);
            throw e;
        }
    }

    console.log("Test Completed Successfully".green);

    // Cleanup
    if (db) {
        await db.rollback(); // TOOD: May move this into individual sql tests
        await db.end();
    }
}

function find_amp_obj( name ) {
    if (name == "CBOR") {
        return CBOR;
    } else if (AMP[name]) {
        return AMP[name];
    }
}

async function verify_truths( truths ) {
    if (verbose) {
        console.log("verify_truths");
    }
    var objProto = find_amp_obj(truths.type);
    var actuals = { type: truths.type };

    if (truths.cbor) {
        if (verbose) { console.log("From CBOR Truth: ".cyan, truths.cbor); }
        actuals.cborObj = new objProto();
        actuals.cborObj.fromCbor(truths.cbor);
        
        actuals.cborOut = await verify_to( actuals.cborObj, truths );  
    }
    if (truths.uri) {
        if (verbose) { console.log("From URI Truth: ".cyan, truths.uri); }
        actuals.uriObj = new objProto();
        actuals.uriObj.fromUri(truths.uri);

        actuals.uriOut = await verify_to( actuals.uriObj, truths );
    }
    if (truths.fromSql && db) {
        if (verbose) { console.log("From SQL Truth ID: ".cyan, truths.fromSql); }
        // This is a boolean flag indicating that this entry should be encoded to/from SQL
        actuals.sqlObj = new objProto();
        AMP.trace.start();
        await actuals.sqlObj.fromSql(truths.fromSql);
        AMP.trace.save();
        
        actuals.sqlOut = await verify_to( actuals.sqlObj, truths );

    }
    if (verbose > 1) {
        console.log("TRUTHS", truths);
        console.log("ACTUALS", actuals);
    }
}

async function verify_to( obj, truths, recursive_call ) {
    if (verbose > 1) {
        console.log("verify_to(", obj, ", ", truths);
    }
    var rtv = { type: truths.type };

    assert(typeof obj == "object", "Input should be an object");
    assert(obj.constructor.name == truths.type, "Expected object type");

    if (verbose) {
        console.log("Convert to CBOR");
    }
    var cbor = obj.toCbor();
    var cbor_str = cbor.toString();
    rtv.cbor = cbor_str;
    if (truths.cbor) {
        assert.equal(cbor_str, truths.cbor, "CBOR output doesn't match expected truth");
    }

    if (obj.toUri) {
        if (verbose) { console.log("Convert to URI"); }
        var uri = obj.toUri();
        var uri_str = uri.toString();
        rtv.uri = uri_str;
        
        if (truths.uri) {
            assert.equal(uri_str, truths.uri, "URI output doesn't match expected truth");
        }
    } else if (truths.uri) {
        throw new Error("Configuration Error; Validation URI defined for an object that does not provide a toUri function");
    }

    if (db && truths.toSql && !recursive_call) {
        if (verbose) { console.log("Convert to SQL"); }
        assert.exists(obj.toSql, 'toSql function defined');
        AMP.trace.start();
        rtv.sqlId = await obj.toSql();

        AMP.trace.save();

        assert.exists(obj.fromSql, 'fromSql function defined');

        if (verbose) { console.log("Convert back from SQL"); }
        var sqlObj = new obj.constructor();
        AMP.trace.start();
        await sqlObj.fromSql(rtv.sqlId);
        await AMP.trace.save();
        if (verbose) { console.log("Verify from SQL"); }
        rtv.sqlOut = await verify_to( sqlObj, truths, 1);
    }

    // Repeat for truths.json, truths.sql
    return rtv;
}

