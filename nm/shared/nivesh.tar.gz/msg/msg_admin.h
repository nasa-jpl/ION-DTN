/******************************************************************************
 **                           COPYRIGHT NOTICE
 **      (c) 2012 The Johns Hopkins University Applied Physics Laboratory
 **                         All rights reserved.
 ******************************************************************************/

/*****************************************************************************
 **
 ** \file msg_admin.h
 **
 **
 ** Description: Defines the data types associated with administrative
 **              messages within the protocol. Also, identify the functions
 **              that pack and unpack these messages.
 **
 ** Notes:
 **
 ** Assumptions:
 **
 ** Modification History:
 **  MM/DD/YY  AUTHOR         DESCRIPTION
 **  --------  ------------   ---------------------------------------------
 **  09/24/12  E. Birrane     Initial Implementation (JHU/APL)
 **  11/01/12  E. Birrane     Redesign of messaging architecture. (JHU/APL)
 *****************************************************************************/

#ifndef MSG_ADMIN_H_
#define MSG_ADMIN_H_

#include "stdint.h"

#include "lyst.h"

#include "../utils/nm_types.h"

#include "../primitives/mid.h"

#include "../msg/pdu.h"


/*
 * +--------------------------------------------------------------------------+
 * |							  CONSTANTS  								  +
 * +--------------------------------------------------------------------------+
 */


/*
 * +--------------------------------------------------------------------------+
 * |							  	MACROS  								  +
 * +--------------------------------------------------------------------------+
 */


/*
 * +--------------------------------------------------------------------------+
 * |							  DATA TYPES  								  +
 * +--------------------------------------------------------------------------+
 */


/*
 * Associated Message Type: MSG_TYPE_ADMIN_REG_AGENT
 * Purpose: Notify manager of discovered agent.
 * +-----------+
 * |  Agent ID |
 * | [BYTESTR] |
 * +-----------+
 */

typedef struct {
	eid_t agent_id;       /**> ID of the agent being registered. */
} adm_reg_agent_t;



/*
 * +--------------------------------------------------------------------------+
 * |						  FUNCTION PROTOTYPES  							  +
 * +--------------------------------------------------------------------------+
 */


/* Administrative messages */
#define MSG_TYPE_ADMIN_REG_AGENT  (0x00)


/* Create functions. */
adm_reg_agent_t *msg_create_reg_agent(eid_t eid);


/* Release functions.*/
void msg_release_reg_agent(adm_reg_agent_t *msg);

/* Serialize functions. */
uint8_t *msg_serialize_reg_agent(adm_reg_agent_t *msg, uint32_t *len);


/* Deserialize functions. */
adm_reg_agent_t *msg_deserialize_reg_agent(uint8_t *cursor,
		                                   uint32_t size,
		                                   uint32_t *bytes_used);

#endif // MSG_ADMIN_H_
