# JHU/APL
#
# Description: library file for functions related to the roundtripping
# of .c and .h files
#
# Modification History:
#   YYYY-MM-DD     AUTHOR            DESCRIPTION
#   ----------     ---------------   -------------------------------
#   2017-11-21     Sarah             File creation
#
##############################################################################

import os
import re
import datetime

####################### FUNCTIONS TO WRITE \CUSTOM\ TAGS TO FILE ##################

#
# Returns a tuple of the custom includes start and end markers
#
def make_custom_includes_markers():
	return "/*   START CUSTOM INCLUDES HERE  */", "/*   STOP CUSTOM INCLUDES HERE  */"

#
# Returns a tuple of the custom functions start and end markers
#
def make_custom_functions_markers():
	return "/*   START CUSTOM FUNCTIONS HERE */", "/*   STOP CUSTOM FUNCTIONS HERE  */"

#
# Returns a tuple of the custom type_enum start and end markers
#
def make_custom_type_enum_markers():
	return "/*   START typeENUM */", "/*   STOP typeENUM  */"

#
# Helper function that returns the indicator and custom tag used by the custom bodies.
# TODO: This is split out differently than the others and is not ideal because of how the
# scraper deals with multi-line tags. Try to simplify.
#
def get_custom_body_pieces():
	indicator = "* +-------------------------------------------------------------------------+"
	marker  = '|{} CUSTOM FUNCTION {} BODY'
	return indicator, marker

#
# Returns a tuple of the (indicator, start marker, end marker) strings for use with a regex
# search for custom function bodies. 
#
def get_custom_body_re_markers():
	indicator, marker = get_custom_body_pieces()

	marker = '\* \\' + marker
	function_string_matcher = '(.+)'
	
	return indicator, marker.format('START', function_string_matcher), marker.format('STOP', function_string_matcher)

#
# Returns a tuple of the custom body's start and end markers
#
def make_custom_body_markers(function):
	indicator, marker = get_custom_body_pieces()

	template = ("\t/*\n"
		    "\t {0}\n"
		    "\t * {1}\n"
		    "\t {0}\n"
		    "\t */\n")

	start_marker = marker.format("START", function)
	end_marker = marker.format("STOP", function)
	
	return template.format(indicator, start_marker), template.format(indicator, end_marker)

#
# Write the standard 'CUSTOM' tag for the includes at the top of a file
# Adds any passed custom content between the start and stop tags
#
# file: open file descriptor to write to
# custom: array of lines to add as custom content (from scraping)
# if custom is empty, will just write the tags to the file
#
def write_custom_includes(file, custom):
	start, end = make_custom_includes_markers()
	
	file.write(start + "\n")
	for line in custom:
		file.write(line);
	file.write(end + "\n\n")
	
#
# Write the standard 'CUSTOM' tag for custom functions
# Adds any passed custom content between the start and stop tags
#
# file: open file descriptor to write to
# custom: array of lines to add as custom content (from scraping)
# if custom is empty, will just write the tags for custom content to the file
#
def write_custom_functions(file, custom):
	start, end = make_custom_functions_markers()
	
	file.write(start + "\n")
	for line in custom:
		file.write(line)
	file.write(end + "\n\n")

#
# Write the standard 'CUSTOM' tag for the body of a standard function
#
# file: open file descriptor to write to
# function: function name
# custom: array of lines to add as custom function body content (from scraping)
# if custom is empty, will just write the tags for custom content to the file
#
def write_custom_body(file, function, custom):
	start, end = make_custom_body_markers(function)
	
	file.write(start)
	for line in custom:
		file.write(line)
	file.write(end)

#
# writes the type enum tags and if scraping was required any 
# typeENUMS that were found
def write_custom_type_enums(file, custom):
	start, end = make_custom_type_enum_markers()
	
	file.write(start + "\n")
	for line in custom:
		file.write(line)
	file.write(end + "\n\n")

	
####################### FUNCTIONS TO SCRAPE CUSTOM CONTENTS ############################
	
#
# Scrapes the passed file for CUSTOM tags to be put into freshly-generated
# file. Returns a (list, list, dictionary) tuple of 1) custom includes,
# 2) custom functions, and 3) function custom bodies
#
# In the function custom bodies dictionary, the name of the function serves
# as the key, and the value is a list of strings that make up the custom body
# of that function.
#
# fd: c file to scrape
#
def scrape(fd):
	c = []
	includes = []
	custom_func = []
	func_bods = {}

	# Insert each line into a queue
	# NOTE: this results in the first line of the file being last in c
	# (find_* functions appropriately pop off the end of c).
	try:
		for line in open(fd).readlines(): 
			c.insert(0,line)
	except IOError, e:
		print "[ Error ] Failed to open ", fd, " for scraping."
		print e
		return includes, custom_func, func_bods

	includes,    c = find_custom_includes_in_queue(c)
	custom_func, c = find_custom_functions_in_queue(c)
	func_bods      = find_func_custom_body_in_queue(c)
	
	return includes, custom_func, func_bods

#
# Scrapes the passed file for CUSTOM tags to be put into freshly-generated
# file. Returns a (list, list) tuple of 1) custom includes, and
# 2) custom functions
#
# fd: h file to scrape
#
def scrapeH(fd):
	h = []
	includes = []
	custom_func = []
	type_enums = []	

	# Insert each line into a queue
	# NOTE: this results in the first line of the file being last in h
	# (find_* functions appropriately pop off the end of h).
	try:
		for line in open(fd).readlines(): 
			h.insert(0,line)
	except IOError, e:
		print "[ Error ] Failed to open ", fd, " for scraping."
		print e
		return includes, custom_func

	includes,    h = find_custom_includes_in_queue(h)
	type_enums,  h = find_type_enums_in_queue(h)
	custom_func, h = find_custom_functions_in_queue(h)
	
	return includes, custom_func, type_enums


##################### HELPER FUNCTIONS FOR THIS FILE  ###########################

#
# Pops items off of the passed queue (list) structure, searching
# for the custom includes tags. Returns all lines encompassed in these tags
#
# lines: lines to search
# Returns: (list, list) tuple that is 1) list of strings from between the custom
# includes tags and 2) updated 'lines' queue (evaluated lines are popped off)
#
# NOTICE: since this is treating lines as a queue, it will evaluate lines in
# reverse order (popping off the end of the list).
#
def find_custom_includes_in_queue(lines):
	includes = []
	line = ""
	
	start, end = make_custom_includes_markers()
	
	# find the start
	while (len(lines) != 0 and line.strip() != start):
		line = lines.pop()

	# Append until we find the end
	while(len(lines) != 0):
		line = lines.pop()
		if(line.strip() == end):
			break
		includes.append(line)
		
	return includes, lines

#
# Pops items off of the passed queue (list) structure, searching
# for the custom functions tags. Returns all lines encompassed in these tags
#
# lines: lines to search
# Returns: (list, list) tuple that is 1) list of strings from between the custom
# function tags and 2) updated 'lines' queue (evaluated lines are popped off)
#
# NOTICE: since this is treating lines as a queue, it will evaluate lines in
# reverse order (popping off the end of the list).
#
def find_custom_functions_in_queue(lines):
	custom_func = []
	line = ""

	start, end = make_custom_functions_markers()
	
	# find the start
	while (len(lines) != 0 and line.strip() != start):
		line = lines.pop()

	# Append until we find the end
	while(len(lines) != 0):
		line = lines.pop()
		if(line.strip() == end):
			break
		custom_func.append(line)
		
	return custom_func, lines

#
# Pops items off of the passed queue (list) structure, searching
# for the function custom body tags. Returns all dictonary of key:value pairs for
# lines encompassed in these tags, where the key is the function name, and value
# is the list of custom lines for that function
# This exhausts the entire passed queue, so unlike the other find*_custom_*() functions,
# it does not return a list of remaining lines in the queue
#
# lines: lines to search
#
# NOTICE: since this is treating lines as a queue, it will evaluate lines in
# reverse order (popping off the end of the list).
#
def find_func_custom_body_in_queue(lines):
	func_bods = {}
	func = None

	indicator, start_re, end_re = get_custom_body_re_markers()

	# While lines remain in the queue, pop one off and evaluate it
	while len(lines) != 0:
		line = lines.pop()
		clean_line = line.strip()

		# If we're inside one of the custom function bodies
		# keep appending until end
		if(func is not None):

			# Append to this function's dictionary entry until you reach
			# another indicator with an end tag
			if(clean_line == indicator):
				line = lines.pop()
				clean_line = line.strip()
				
				if(re.match(end_re, clean_line) != None):
					func_bods[func].pop()
					func = None
				else:		
					continue			
			else:
				if(not func in func_bods):
					func_bods[func] = []
				func_bods[func].append(line)
				
		# Check if this line is the start of a new custom function body
		else:
			s = re.search(start_re, clean_line)
			if s != None:
				func = s.group(1)

	return func_bods

#
# Pops items off of the passed queue (list) structure, searching
# for the type_enum tag. Returns all lines encompassed in these tags
#
# lines: lines to search
# Returns: (list, list) tuple that is 1) list of strings from between the custom
# function tags and 2) updated 'lines' queue (evaluated lines are popped off)
#
# NOTICE: since this is treating lines as a queue, it will evaluate lines in
# reverse order (popping off the end of the list).
#
def find_type_enums_in_queue(lines):
	enums = []
	line = ""

	start, end = make_custom_type_enum_markers()
	
	# find the start
	while (len(lines) != 0 and line.strip() != start):
		line = lines.pop()

	# Append until we find the end
	while(len(lines) != 0):
		line = lines.pop()

		if(line.strip() == end):
			break
		enums.append(line)

	return enums, lines
