# JHU/APL
# Description: creates mysql scripts to populate the manager database 
# as descriped in AMP Manager SQL Interface draft-birrane-dtn-ampmgr-sql-01  
#
##################################################################### 


import re
import datetime
import os
import errno 

from lib import campch
from lib import campsql
from lib.common import camputil as cu
from lib.common import campsettings as cs


def initialize_file(name,outpath):
	filename=outpath +"/"+name+".sql"
	return filename


def get_namespace(mdat):
	for i in mdat:
		if i["name"]=="namespace":
			return i["value"]

#write the procedure call to insert an item into the amp.adm table
#takes in the sql file, the name of the adm, and the metadata information
def write_insert_adm(sql_file,name,mdat):
	adm_name = name

	for i in mdat:
		if i["name"]=="name":
			adm_name=i["value"]

		elif i["name"]=="version":
			version=i["value"]

		elif i["name"]=="organization":
			organization=i["value"]
	description=adm_name
	insert_adm_str=(
			"\nCALL create_adm('"+adm_name+"', '"+version+"', '"+description+"', '"+organization+"',@adm_id);"
		)
	sql_file.write(insert_adm_str)



#write the procedure calls to insert an item into the amp.adm_nicknames table
#takes in the sql file, namespace of the adm, and the metadata
#calculates the value of the nickname id
def write_insert_adm_nicknames(sql_file,namespace,mdat):

	nickname="hello"
	nickname_enum=0
	nickname_enum_str=""

	for x in range(11):
		try:
			if x==0:
				nickname="CONST"
			elif x==1:
				nickname="CTRL"
			elif x==2:
				nickname="EDD"
			elif x==3:
				nickname="MAC"
			elif x==4:
				nickname="OPER"
			elif x==5:
				nickname="RPTT"
			elif x==6:
				nickname="SBR"
			elif x==7:
				nickname="TBLT"
			elif x==8:
				nickname="TBR"
			elif x==9:
				nickname="VAR"
			elif x==10:
				nickname="MDAT"

			nickname_enum_str=str(nickname_enum)
			insert_pre_nn_calc_str=(
				"\nSET @nn_id=(@adm_id*20)+"+str(x)+";"
				)
			insert_adm_nickname_str=(
				"\nCALL create_adm_nickname(@adm_id,@nn_id, '"+namespace+" "+nickname+"');"
			)
			sql_file.write(insert_pre_nn_calc_str)
			sql_file.write(insert_adm_nickname_str)
			nickname_enum+=1
		except Exception, e:
			print e
			raise

#writes the procedure call to insert an item into the ac_set table
#ac is an ari collection
#takes in the sql file and the name of the ari that the ac_set belongs to
def write_insert_ac_set(sql_file,label):
	insert_ac_set_str=(
			"\nCALL create_ac_set('"+label+"', @ac_id);"
		)
	sql_file.write(insert_ac_set_str)


#writes the procedure call to insert an item into the ac_entry table
#takes in the sql file, name of the ari that the ac_set belongs to,
#the order number of the ac_entry in the ac_set, the nickname of the
#ac (EDD, VAR, etc.), and the namespace of the adm
def write_insert_ac_entry(sql_file,label,order,nn,namespace, new):
	if(new):
		insert_ac_entry_str=(
			"\nCALL create_ac_entry(@ac_id, @ari_id, "+order+");"
		)
	else: 
		insert_ac_entry_str=(
			"\nCALL create_ac_entry(@ac_id, (SELECT (ari_id) FROM amp.ari WHERE ari_definition_id=(SELECT (ari_definition_id) FROM amp.ari_definition WHERE ari_obj_name='"+label+"' AND nn_id=(SELECT (nickname_enum) FROM amp.adm_nickname WHERE label='"+namespace+" "+nn+"' ))), "+order+");"
		)

	sql_file.write(insert_ac_entry_str)




#writes the procedure call to insert an item into the parmspec_set table
#takes in the sql file and name of the ari that the parameter set belongs to
def write_insert_parmspec_set(sql_file,label):
	insert_parmspec_set_str=(
			"\nCALL create_parmspec_set('"+label+"',@parm_id);"
		)
	sql_file.write(insert_parmspec_set_str)


#writes the procedure call to insert a parameter into the parmspec_entry table
#takes in the sql file, the name of the parameter, the order of the parameter 
#in the parmspec set that it belongs to, and the type of the parameter
def write_insert_parmspec_entry(sql_file,label,order,type_str):
	insert_parmspec_entry_str=(
			"\nCALL create_parmspec_entry(@parm_id, '"+label+"', "+order+", (SELECT (enumeration) FROM amp.data_types WHERE type_name='"+type_str+"'),@parmspec_entry_id);"
		)
	sql_file.write(insert_parmspec_entry_str)


#writes the procedure call to create a tnvc set in the tnvc_set table
#takes in the sql file and the name of the ari to which the tnvc set belongs
def write_insert_tnvc_set(sql_file,label):
	insert_tnvc_set_str=(
			"\nCALL create_tnvc_set('"+label+"', @tnvc_id);"
		)
	sql_file.write(insert_tnvc_set_str)	


#writes the procedure call to add a tnvc entry into the tnvc table for 
#a particular set. 
#takes in the sql file, the order of the tnvc in the set to which it belongs
#the name of the tnvc, the type of the tnvc, and the value of the tnvc
def write_insert_tnvc_entry(sql_file,order,label,type_str,value):
	insert_tnvc_entry_str=(
			"\nCALL create_tnvc_entry(@tnvc_id, "+order+", '"+label+"', (SELECT (enumeration) from amp.data_types WHERE type_name='"+type_str+"'), "+value+");"
		)
	sql_file.write(insert_tnvc_entry_str)



#writes the procedure call to create a new expression set
#takes in the sql file, the name of the ari to which the expression set belongs
#and the type of the expression
def write_insert_expression_set(sql_file,label,type_str):
	insert_expression_set_str=(
			"\nCALL create_expression_set('"+label+"', (SELECT (enumeration) from amp.data_types WHERE type_name='"+type_str+"'), @expr_id);"
		)
	sql_file.write(insert_expression_set_str)


#writes the procedure call to create a new entry for a particular expression set
#in the expression_entry table.
#takes in the sql file, the name of the ari that is being used in the expression,
#the order of the entry in the expression set, the namespace of the entry that is 
#being added to the set (ex. Amp/Agent), and the nickname of the item that is being
#added (ex. EDD, VAR)
def write_insert_expression_entry(sql_file,label,order,namespace,nn,new):
	if(new):
		insert_expression_entry_str=("\nCALL create_expression_entry(@expr_id, "+order+", @curr_id);")
	else:
		insert_expression_entry_str=(
			"\nCALL create_expression_entry(@expr_id, "+order+", (SELECT (ari_id) FROM amp.ari WHERE ari_id=(SELECT (ari_definition_id) FROM amp.ari_definition WHERE ari_obj_name='"+label+"' AND nn_id=(SELECT (nickname_enum) FROM amp.adm_nickname WHERE label='"+namespace+" "+nn.upper()+"'))));"
		)
	sql_file.write(insert_expression_entry_str)


#writes the procedure call to create a new data set (that contains the values of parameters)
#takes in the sql file and the name of the ari to which the data set belongs
def write_insert_data_set(sql_file,label):
	insert_data_set_str=(
			"\nCALL create_data_set('"+label+"', @data_id);"
		)
	sql_file.write(insert_data_set_str)


#writes the procedure call to create a new data entry that corresponds to a certain data set
#takes in the sql file, the order of the data entry in the set, the type of the data entry,
#and the actual value of the data entry
#based on the type of the data entry, it will output a different ending
#because the value of the data will only exist in the column that corresponds to the type 
#that the data entry is and the other columns for the other types will be null
def write_insert_data_entry(sql_file,order,type_str,value):
	insert_data_entry_str=(
			"\nCALL create_data_entry(@data_id, "+order+", (SELECT (enumeration) from amp.data_types WHERE type_name='"+type_str+"'), "  
		)
	
	sql_file.write(insert_data_entry_str)
	if(type_str=='ARI'):
		sql_file.write("@ari_id, NULL, NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL, @data_entry_id);") # have to look at what ari values look like 
	elif(type_str=='BYTE'):
		sql_file.write("NULL,"+str(value)+"NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL, @data_entry_id);")
	
	elif(type_str=='TNVC'):
		sql_file.write("NULL,NULL,@tnvc_id,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL, @data_entry_id);")
	
	elif(type_str=='EXPR'):
		sql_file.write("NULL,NULL,NULL,@expr_id,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL, @data_entry_id);")
	
	elif(type_str=='AC'):
		sql_file.write("NULL,NULL,NULL,NULL,@ac_id,NULL,NULL,NULL,NULL,NULL,NULL,NULL, @data_entry_id);")
	
	elif((type_str=='VAST') or (type_str=='INT')):
		sql_file.write("NULL,NULL,NULL,NULL,NULL,"+str(value)+",NULL,NULL,NULL,NULL,NULL,NULL, @data_entry_id);")
	
	elif((type_str=='UVAST') or (type_str=='UINT')):
		sql_file.write("NULL,NULL,NULL,NULL,NULL,NULL,"+str(value)+",NULL,NULL,NULL,NULL,NULL, @data_entry_id);")
	
	elif((type_str=='REAL64') or (type_str=='REAL32')):
		sql_file.write("NULL,NULL,NULL,NULL,NULL,NULL,NULL,"+str(value)+",NULL,NULL,NULL,NULL, @data_entry_id);")
	
	elif(type_str=='STR'):
		sql_file.write("NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'"+str(value)+"',NULL,NULL,NULL, @data_entry_id);")
	
	elif(type_str=='BOOL'):
		sql_file.write("NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,"+str(value)+",NULL,NULL, @data_entry_id);")

	elif(type_str=='TS') or (type_str=='TV'):
		sql_file.write("NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,"+str(value)+",NULL, @data_entry_id);")

	elif (type_str.upper()=='PARMNAME'):
		sql_file.write("NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'"+str(value)+"', @data_entry_id);")



#writes the procedure call to create a new ari
#takes in the sql file, the name of the ari, the description of the ari, and a tag
#that shows whether or not the ari has a data set attached to it
#if there is a data set present for this ari, the procedure will call the id for that
#data set and if not then the data_id column will be null
def write_insert_ari(sql_file,label,description,data_tag,just_created,namespace,struc_name):
	description=description.replace("'","\\\'")
	#need to add a part of the method to include whether or not a new ari definition was just called before that and the namespace
	#if the ari definition was called then it should be what it says below
	#otherwise, instead of @ari_id, it should be doing a select statement
	if data_tag:
		if just_created:
			insert_ari_str=(
				"\nCALL create_ari('"+label+"', @ari_definition_id, @data_id, '"+description+"',@ari_id);"
			)
		else:
			insert_ari_str=(
					"\nCALL create_ari('"+label+"',(SELECT (ari_definition_id) FROM amp.ari_definition WHERE ari_obj_name='"+label+"' and nn_id=(SELECT (nickname_enum) FROM amp.adm_nickname WHERE label='"+namespace+" "+struc_name+"')), @data_id, '"+description+"',@ari_id); "
			)


	else:
		if just_created:
			insert_ari_str=(
				"\nCALL create_ari('"+label+"', @ari_definition_id, NULL, '"+description+"',@ari_id);"
			)
		else:
			insert_ari_str=(
				"\nCALL create_ari('"+label+"',(SELECT (ari_definition_id) FROM amp.ari_definition WHERE ari_obj_name='"+label+"' and nn_id=(SELECT (nickname_enum) FROM amp.adm_nickname WHERE label='"+namespace+" "+struc_name+"')), NULL, '"+description+"',@ari_id); "
			)

		
		

	sql_file.write(insert_ari_str)



#writes the procedure call to create a new ari definition
#takes in the sql file, the name of the ari that is being defined, the description of the ari,
#the type of the ari, the structure type of the ari (ex. EDD, VAR), the parameter flag where
#1 means that there is a parameter set for that ari and 0 if there is no parameter set for that
#ari, the namespace of the ari item, and the encoding of the adm object's name (in this case, we
#are saying that the order of the ari in the set of the object list (ex. EDD) is the encoding of the name)
#because there is a column that only deals with the definition of an ari that has operators, there is a 
#specific column that has information in it that any other ari being defined wouldnt have, which is why
#there is a specific elif statement only for operators. operators dont have parameters and instead they
#have in types
def write_insert_ari_definition(sql_file,label,description,type_str,struc_name,parm,namespace,order_str):
	description=description.replace("'","\\\'")
	if parm==1:

		insert_ari_definition_str=(
				"\nCALL create_ari_definition('"+label+"', (SELECT (enumeration) FROM amp.data_types WHERE type_name='"+type_str+"'), (SELECT (nickname_enum) FROM amp.adm_nickname WHERE label='"+namespace+" "+struc_name.upper()+"'),'"+order_str+"', @parm_id, 0,0,(SELECT (enumeration) FROM amp.data_types WHERE type_name='"+struc_name+"'), NULL,@ari_definition_id);"
			)
	elif struc_name=='OPER':
		insert_ari_definition_str=(
				"\nCALL create_ari_definition('"+label+"', (SELECT (enumeration) FROM amp.data_types WHERE type_name='"+type_str+"'), (SELECT (nickname_enum) FROM amp.adm_nickname WHERE label='"+namespace+" "+struc_name.upper()+"'),'"+order_str+"', NULL, 0,0,(SELECT (enumeration) FROM amp.data_types WHERE type_name='"+struc_name+"'), @in_type_id,@ari_definition_id);"
			)
	else:
		insert_ari_definition_str=(
				"\nCALL create_ari_definition('"+label+"', (SELECT (enumeration) FROM amp.data_types WHERE type_name='"+type_str+"'), (SELECT (nickname_enum) FROM amp.adm_nickname WHERE label='"+namespace+" "+struc_name.upper()+"'),'"+order_str+"', NULL, 0,0,(SELECT (enumeration) FROM amp.data_types WHERE type_name='"+struc_name+"'), NULL,@ari_definition_id);"
			)


	sql_file.write(insert_ari_definition_str)


#this writes the procedure call for creating an in type set
#this takes in the sql file and the name of the ari to which the in type set belongs
#this is only for operators
def write_insert_in_type_set(sql_file,label):
	insert_in_type_set_str=(
			"\nCALL create_in_type_set('"+label+"', @in_type_id);"
		)
	sql_file.write(insert_in_type_set_str)



#this writes the procedure call for creating an entry of an in type set
#this takes in the sql file, the name of the in type, the order of the in type
#in the in type set, and the type of the in type (ex. Int, Uint)
#this is for operators only
def write_insert_in_type_entry(sql_file,label,order,type_str):
	insert_in_type_entry_str=(
			"\nCALL create_in_type_entry('"+label+"', @in_type_id, "+str(order)+", (SELECT (enumeration) FROM amp.data_types WHERE type_name='"+type_str+"'));"
		)
	sql_file.write(insert_in_type_entry_str)


#this tries to parse the report definition for parameter values
#ex. DTN/bp_agent/Edd.src_bundles_by_priority(2)
def write_try_rpt_parm(sql_file,label):
	counter=0
	label=str(label)
	label=label.split("(")
	sql_file.write(str(label[0]))
	for i in label:
		
		counter+=1
		
	return counter

#this writes the procedure call to define a new macro
#this only takes in the sql file
def write_insert_macro_definition(sql_file):
	insert_macro_definition=(
			"\nCALL create_macro_definition(@ari_definition_id,@ac_id);"
		)
	sql_file.write(insert_macro_definition)

#this writes the procedure call to create a new variable definition
#this takes in the sql file and the type of the variable
def write_insert_var_definition(sql_file,type_str):
	insert_var_definition_str=(
			"\nCALL create_var_definition(@ari_definition_id, (SELECT (enumeration) from amp.data_types WHERE type_name='"+type_str+"'),@expr_id);"
		)
	sql_file.write(insert_var_definition_str)

#this writes the procedure call to create a new report template definition
#this only takes in the sql file
def write_insert_rptt_definition(sql_file):
	insert_rptt_definition=(
			"\nCALL create_rptt_definition(@ari_definition_id,@ac_id);"
		)
	sql_file.write(insert_rptt_definition)

#this writes the procedure call to create a new table template definition
#this only takes in the sql file
def write_insert_tblt_definition(sql_file):
	insert_tblt_definition=(
			"\nCALL create_tblt_definition(@ari_definition_id,@tnvc_id);"
		)
	sql_file.write(insert_tblt_definition)


# used by reports, macros, and varibles to process their definitions
# writes a ac entry for each definition entry and process 
# each entries parameter
def process_definitions(entry, order_value, default_adm, data, uses, namespace, paramspec, sql_file,struc_name):
	d_adm, d_coll, d_name, parms = cu.parse_definition(entry,default_adm)
	i = 0


	# finds the default values and types for this entries parms 
	default_vals = cu.get_default_values(d_adm, d_coll, d_name, data, uses)
	default_types = cu.get_parm_types(d_adm, d_coll, d_name, data, uses)
	if((default_types is not None) and (len(parms) > len(default_types))):
		print "Error: Too many parameter supplied for object  " +  str(entry)
		raise Exception

	if len(parms):
		write_insert_data_set(sql_file,d_name)
	
	# proccess each parameter
	for p in parms:
		type_enum = None
		valued_param = None
		if(isinstance(p, unicode) or isinstance(p, str)): # string encoding 
			# captures the parm info 
			match = re.match("^(.+=)?(.+)?$",p)
			if match != None:
				type_enum = match.group(1)
				valued_param = match.group(2)  
			if type_enum != None:

				if " " in type_enum:
					type_enum=type_enum.split(" ")
					type_enum=type_enum[0]

				type_enum = (type_enum.replace("=","")).strip()
			
			if valued_param != None:
				match = re.match("<(.+)>", valued_param)
				if (match):
					valued_param = match.group(1) or None
					type_enum = "ParmName"

			
		else: # if it is using JSON encoding 
			type_enum = p.get("type",None)
			valued_param = p.get("value",None)


		# If the parameter is mapped, checks to make sure 
		# what it is mapping to exists  
		if type_enum !=None and type_enum.upper() == "PARMNAME":
			src = None 
			i2 = 0 
			for p in paramspec:
				if p['name'] == valued_param:
					src = i2 
					break  
				i2 = i2 + 1

			if src == None:
				print "Error: could not find source for ", str(i), " parameter for " +  str(struc_name)
				raise Exception

		# if no type or value was given, uses the default one from this object  
		if(type_enum == None):
			if(default_types != None):
				type_enum = default_types[i]
			else:
				print "Error: extra parameter given for the " + str(i) + " parameter of "+ str(entry)
				raise Exception


		if(valued_param == None):
			if(default_vals != None):
				valued_param = default_vals[i]
			else:
				print "Error: No value supplied and no default value found for object  " +  str(entry)
				raise Exception



		value = str(valued_param)
		type_str=str(type_enum)
		order=str(i)
		#if type_enum.upper()!='PARMNAME':
		write_insert_data_entry(sql_file,order,type_str,value)
		#else:


		i  = i + 1
									
	nn = cs.get_lname(d_coll).upper()

	order=str(order_value)
	namespace=d_adm

	if(len(parms)):
		write_insert_ari(sql_file,str(d_name), "", len(parms),0,namespace,nn)
		

	if struc_name=='VAR':
		write_insert_expression_entry(sql_file,str(d_name),order,namespace,nn,len(parms))
	else:
		#underneath this is additions (need to be tested)
		#if(len(parms)):
			#if type_enum.upper()!='PARMNAME':
				#write_insert_ac_entry(sql_file,str(d_name),order, nn, d_adm, len(parms))
			#else:
			#	new=0
				#write_insert_ac_entry(sql_file,str(d_name),order, nn, d_adm, new)

		
		#else:
			#above this is additions (need to be tested)
			write_insert_ac_entry(sql_file,str(d_name),order, nn, d_adm, len(parms))
	


# this contains everything that needs to be done to add metadata into the database
# metadata needs an ari definition and an ari
def write_insert_meta(sql_file,name,mdat,namespace):
	body = ""
	ttype = "mdat"
	label="test"
	description="test"
	type_str="test"
	order_value=0
	struc_name='mdat'
	counter=0
	for i in mdat:

		#this means no parameters
		parm=0
		try:
			label= i["name"]
			description= i["description"]
			#this adds the name of the metadata and the description as a comment into the sql script
			sql_file.write("\n#Generate Metadata: "+label)
			sql_file.write("\n#Description:"+description)
			type_str=i["type"]
			value=i["value"]
			#this makes the order of the piece of metadata in the adm a string so that it can be printed out
			#in the procedure call for the ari_definition
			order_str=str(counter)

			#write the correct procedure calls
			write_insert_ari_definition(sql_file,label,description,type_str,struc_name,parm,namespace,order_str)
			write_insert_ari(sql_file,label,description, 0,1,namespace,struc_name)

			counter+=1
			sql_file.write("\n\n")
		except Exception, e:
			print e
			raise
		except KeyError,e:
			print"[Error] Badly formatted mdat. Key not found:"
			print e
			raise



#this contains everything that is needed to add an edd into the database
#this takes in the sql file, the edds from the JSON file, and the namespace
#an edd without a parameter will need only an ari definition and ari
#an edd with a parameter will need a parmspec set, parmspec entries, ari
#definition and ari
def write_insert_edd(sql_file,name,edds,namespace):
	body = ""
	ttype = "edd"
	label="test"
	description="test"
	type_str="test"
	order_value=0
	struc_name='edd'
	
	counter=0
	for i in edds:
		
		parm=0
		try:
			label= i["name"]
			description= i["description"]
			type_str=i["type"]
			sql_file.write("\n#Generate Externally Defined Data: "+label)
			sql_file.write("\n#Description:"+description)
			
			#look for parameters in the json file
			params = cu.item_get_params(i)
			#if parameters exist for this specific edd then create a parmspec_set for the edd
			#the label for the parmspec set should be the name of the edd
			if params != []:
				write_insert_parmspec_set(sql_file,label)
				for j in params:
					#make a parmspec entry for every parameter that is part of params
					#order_value is keeping track of the order in the parmspec set while counter 
					#is keeping track of the order in the set of edds
					order=str(order_value)
					label=j["name"]
					type_str=j["type"]
					write_insert_parmspec_entry(sql_file,label,order,type_str)
					order_value+=1
				#this means that the edd has a parmspec set attached to it
				parm=1
			label=i["name"]
			type_str=i["type"]
			order_str=str(counter)
			#write the correct procedures
			write_insert_ari_definition(sql_file,label,description,type_str,struc_name,parm,namespace,order_str)
			if(not len(params)):
				write_insert_ari(sql_file,label,description, len(params),1,namespace,struc_name)
				
			sql_file.write("\n\n")
			#reset the counter for the parameters and increase the order of the edd in the set by 1
			order_value=0
			counter+=1

		except Exception, e:
			print e
			raise
		except KeyError,e:
			print"[Error] Badly formatted edd. Key not found:"
			print e
			raise


#this contains everything that is needed to add a new variable in the database
def write_insert_var(sql_file,name,variables,data,namespace, uses):
	counter=0
	default_adm = data[cs.get_lname(cs.META)][1]["value"]

	for i in variables:
		#the default is that there are no parameters for variables
		parm=0
		try:

			label= i["name"]
			description=i["description"]
			sql_file.write("\n#Generate Variable: "+label)
			sql_file.write("\n#Description:"+description)
			type_str='EXPR'
			struc_name='VAR'
			expr_type=i["type"]
			value='NULL'
			order_val=0
			order=""
			order_holder=0
			order_str=str(counter)
			
			#see if there are parameters for the variable
			parms_spec = cu.item_get_params(i)
			order_value=0
			if parms_spec != []:
				write_insert_parmspec_set(sql_file,label)
				for j in parms_spec:
					order=str(order_value)
					label=j["name"]
					type_str=j["type"]
					write_insert_parmspec_entry(sql_file,label,order,type_str)
					order_value+=1
				parm=1

			write_insert_ari_definition(sql_file,label,description,type_str,struc_name,parm,namespace,order_str)
			if(not len(parms_spec)):
				write_insert_ari(sql_file,label,description, len(parms_spec),1,namespace,struc_name)
			#grab the information from the json about the initializing expression
			initializer=cu.item_get_initializer(i)
			#the initial type of the expression
			type_str=initializer["type"]
			write_insert_expression_set(sql_file,label,type_str)
			#grab the actual expression part of the variable
			postfix_expr=cu.item_get_postfix(initializer)

			order_value = 0
			
			for entry in postfix_expr:

				process_definitions(entry, order_value, default_adm, data, uses, namespace, cu.item_get_params(i), sql_file,struc_name)
				order_value = order_value + 1
				 
			
			label=i["name"]

			order='1'
			type_str=i["type"]
			data_tag=0
			
			write_insert_var_definition(sql_file,type_str)

		except Exception, e:
			print e
			raise
		except KeyError,e:
			print"[Error] Badly formatted edd. Key not found:"
			print e
			raise



#this contains everything that is needed to add a new report template into the database
def write_insert_reports(sql_file, name, reports, data, namespace, uses):
	order_value=0
	counter=0
	parm_count=0
	struc_name='RPTT'
	default_adm = data[cs.get_lname(cs.META)][1]["value"]

	for i in reports:
		#parm flag default to 0, meaning that there are no parameter sets for the report
		parm=0
		label=i["name"]
		description=i["description"]
		#generate the general commented information about the report into the sql file
		sql_file.write("\n#Generate Report: "+label)
		sql_file.write("\n#Description:"+description)
		try:
			#see if there are parameters for the report
			parms_spec = cu.item_get_params(i)
			order_value=0
			if parms_spec != []:
				write_insert_parmspec_set(sql_file,label)
				for j in parms_spec:
					order=str(order_value)
					label=j["name"]
					type_str=j["type"]
					write_insert_parmspec_entry(sql_file,label,order,type_str)
					order_value+=1
				parm=1
			
			label=i["name"]
			description=i["description"]
			type_str='NULL'
			
			defn=cu.item_get_def(i)
			order_str=str(counter)
			
			write_insert_ari_definition(sql_file,label,description,type_str,struc_name,parm,namespace,order_str)
			if(not len(parms_spec)):
				write_insert_ari(sql_file,label,description, len(parms_spec),1,namespace,struc_name)

			write_insert_ac_set(sql_file,label)
			
			counter+=1
			
			order_value=0
			for entry in defn:
				process_definitions(entry, order_value, default_adm, data, uses, namespace, parms_spec, sql_file,struc_name)
				order_value = order_value + 1
			
			order="0"
			type_str="AC"
			value="NULL"
			data_tag=0

			write_insert_rptt_definition(sql_file)
		except Exception,e:
			print e
			raise
		except KeyError,e:
			print"[Error] Badly formatted report. Key not found:"
			print e
			raise


#this contains all of the information that is needed to add a table template into the database
def write_insert_tables(sql_file,name,tables,namespace):
	counter=0
	for i in tables:
 		try:
			order_val=0
			label=i["name"]
			description=i["description"]
			#generate the overall information about each table template that is being added
			sql_file.write("\n#Generate Table: "+label)
			sql_file.write("\n#Description:"+description)
			#the information about the columns for tables will be in a tnvc set
			#the information in the tnvc set will be type and name only
			write_insert_tnvc_set(sql_file,label)
			#grab the columns that should be in the table template
			columns=cu.item_get_columns(i)
			for j in columns:
				label=j["name"]
				type_str=j["type"]
				order=str(order_val)
				value='NULL'
				#for every column, input the name and type, while leaving the value null
				write_insert_tnvc_entry(sql_file,order,label,type_str,value)
				order_val+=1
			#because there are no parameters for table templates, this should default to 0
			parm=0
			label=i["name"]
			description=i["description"]
			type_str='NULL'
			struc_name='TBLT'
			order_str=str(counter)
			write_insert_ari_definition(sql_file,label,description,type_str,struc_name,parm,namespace,order_str)
			#create a table template for the given ari that was defined
			write_insert_tblt_definition(sql_file)
			write_insert_ari(sql_file,label,description, 0,1,namespace,struc_name)

			counter+=1
		except Exception,e:
			print e
			raise
		except KeyError,e:
			print"[Error] Badly formatted report. Key not found:"
			print e
			raise

#this contains all of the information that is needed to add a control into the database
def write_insert_control(sql_file,name,controls,namespace):
	body = ""
	ttype = "control"
	label="test"
	description="test"
	type_str="test"

	order_value=0
	counter=0

	for i in controls:
		#the default should be that there are no parameters or parameter values
		parm=0
		try:
			
			label= i["name"]
			description= i["description"]
			sql_file.write("\n#Generate Control: "+label)
			sql_file.write("\n#Description:"+description)
			

			#grab any parameters for the control
			params = cu.item_get_params(i)
			if params != []:
				#if there are parameters, create a parmspec set and create parmspec entries
				write_insert_parmspec_set(sql_file,label)
				for j in params:
					#order value is for the order of the parameter in the set
					#counter is the order of the control in the list of controls
					order=str(order_value)
					label=j["name"]
					type_str=j["type"]
					write_insert_parmspec_entry(sql_file,label,order,type_str)
					order_value+=1
				#because there were parameters, set the flag to 1
				parm=1
			label=i["name"]
			type_str='NULL'
			struc_name="CTRL"
			order_str=str(counter)
			#generate the calls for the ari definition and ari for each control
			write_insert_ari_definition(sql_file,label,description,type_str,struc_name,parm,namespace,order_str)
			if(not len(params)):
				write_insert_ari(sql_file,label,description, len(params),1,namespace,struc_name)
			counter+=1
			sql_file.write("\n\n")
			#reset the number of parameters to 0
			order_value=0

		except Exception, e:
			print e
			raise
		except KeyError,e:
			print"[Error] Badly formatted control. Key not found:"
			print e
			raise


#this contains everything that is needed to add a constant into the database
def write_insert_constant(sql_file,name,constants,namespace):
	counter=0
	for i in constants:
		#constants shouldnt have any parameters or parameter values, so this is defaulted to 0
		parm=0
		try:
			label= i["name"]
			description=i["description"]
			sql_file.write("\n#Generate Constant: "+label)
			sql_file.write("\n#Description:"+description)
			type_str=i["type"]
			struc_name='CONST'
			order=str(1)
			order_str=str(counter)
			#generate the proper procedure calls
			write_insert_ari_definition(sql_file,label,description,type_str,struc_name,parm,namespace,order_str)
			write_insert_ari(sql_file,label,description, 0,1,namespace,struc_name)
			counter+=1
		except Exception, e:
			print e
			raise
		except KeyError,e:
			print"[Error] Badly formatted constant. Key not found:"
			print e
			raise

#this contains everything that is needed to add a macro into the database
#macros are a collection of controls
def write_insert_macro(sql_file, name, macros, data, namespace, uses):
	counter=0
	default_adm = data[cs.get_lname(cs.META)][1]["value"]

	for i in macros:
		parm = 0
		data_tag = 1
		try:
			
			description=i["description"]
			type_str="AC"
			label=i["name"]
			sql_file.write("\n#Generate Macro: "+label)
			sql_file.write("\n#Description:"+description)
			order_val=0
			order="test"
			struc_name='MAC'
			order_str=str(counter)

			#see if there are parameters for the macro
			parms_spec = cu.item_get_params(i)
			order_value=0
			if parms_spec != []:
				write_insert_parmspec_set(sql_file,label)
				for j in parms_spec:
					order=str(order_value)
					label=j["name"]
					type_str=j["type"]
					write_insert_parmspec_entry(sql_file,label,order,type_str)
					order_value+=1
				parm=1

			write_insert_ari_definition(sql_file,label,description,type_str,struc_name,parm,namespace,order_str)
			write_insert_ac_set(sql_file,label)
			counter+=1
			defn = cu.item_get_def(i)
			
			order_value = 0
			for entry in defn:
				process_definitions(entry, order_value, default_adm, data, uses, namespace, cu.item_get_params(i), sql_file,struc_name)
				order_value = order_value + 1


			label= i["name"]
			type_str="AC"
			value="NULL"
			order="0"
			data_tag=0


			if(not len(parms_spec)):
				write_insert_ari(sql_file,label,description, len(parms_spec),0,namespace,struc_name)
			
			write_insert_macro_definition(sql_file)
		except Exception, e:
			print e
			raise
		except KeyError,e:
			print"[Error] Badly formatted macro. Key not found:"
			print e
			raise

#contains all of the information that is needed to add an operator into the database
def write_insert_op(sql_file,name,operators,namespace):
	counter=0
	for i in operators:
		#operators do not have parameters or parameter values
		#default for no parameters/parameter values is 0
		parm=0
		data_tag=0
		try:
			#grab the in types from the json file
			in_types=cu.item_get_in_types(i)
			type_str=i["result-type"]
			label=i["name"]
			description=i["description"]
			#generate the general information about the operator for the sql file
			sql_file.write("\n#Generate Operator: "+label)
			sql_file.write("\n#Description:"+description)
			struc_name='OPER'
			order=0
			
			write_insert_in_type_set(sql_file,label)
			for j in in_types:
				in_type_str=j
				label=j
				write_insert_in_type_entry(sql_file,label,order,type_str)
				order+=1
			label=i["name"]
			order_str=str(counter)
			write_insert_ari_definition(sql_file,label,description,type_str,struc_name,parm,namespace,order_str)
			write_insert_ari(sql_file,label,description,data_tag,1,namespace,struc_name)
			order=0
			counter+=1
		except Exception,e:
			print e
			raise
		except KeyError,e:
			print"[Error] Badly formatted Operator. Key not found:"
			print e
			raise




def create(data,outpath,uses):
	try:
		name, ns= cu.get_adm_names(data)
		ns_upper = ns.upper()

		filename = initialize_file(name,outpath)

		sql_file = open(filename,"w")

	except KeyError, e:
		print "[Error] JSON does not include valid metadata"
		print e
		return

	except IOError, e:
		print "[Error] Failed to open ",filename,"for writing."
		print e
		return

	print "Working on ",filename,

	try:
		namespace=get_namespace(cu.get_metadata(data))
		write_insert_adm(sql_file,name,cu.get_metadata(data))
		write_insert_adm_nicknames(sql_file,namespace,cu.get_metadata(data))
		sql_file.write("\n\n#Metadata\n\n") 
		write_insert_meta(sql_file,name,cu.get_metadata(data),namespace) 
		sql_file.write("\n\n#EDD\n\n")
		write_insert_edd(sql_file,name,cu.get_edds(data),namespace)
		sql_file.write("\n\n#Operator\n\n")
		write_insert_op(sql_file,name,cu.get_operators(data),namespace)
		sql_file.write("\n\n#Constant\n\n")
		write_insert_constant(sql_file,name,cu.get_constants(data),namespace)
		sql_file.write("\n\n#Control\n\n")
		write_insert_control(sql_file,name,cu.get_controls(data),namespace)
		sql_file.write("\n\n#Variables\n\n")
		write_insert_var(sql_file,name,cu.get_variables(data),data,namespace, uses)
		sql_file.write("\n\n#Macro\n\n")
		write_insert_macro(sql_file,name,cu.get_macros(data), data, namespace, uses)
		sql_file.write("\n\n#Report\n\n")
		write_insert_reports(sql_file,name,cu.get_reports(data), data, namespace, uses)
		sql_file.write("\n\n#Table\n\n")
		write_insert_tables(sql_file,name,cu.get_tables(data),namespace)

	except KeyError,e:
		return

	# except Exception:
		# return

	finally:
		sql_file.close()

	print "\t[ DONE ]"

