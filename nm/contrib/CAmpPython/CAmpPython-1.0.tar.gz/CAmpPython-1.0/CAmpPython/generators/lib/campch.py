
# JHU/APL
#
# Description: library file for common functions related to the generation of
# .c and .h files
#
# Modification History:
#   YYYY-MM-DD     AUTHOR            DESCRIPTION
#   ----------     ---------------   -------------------------------
#   2017-11-21     Sarah             File creation
#
##############################################################################

import os
import re
import datetime

from common import camputil as cu
from common import campsettings as cs

##################### FUNCTIONS FOR COMMENTS AND HEADERS #####################

#
# Writes the standard c file header to the file
#
# fd: open file descriptor to write to
# filepath: the path to the of the file, where the basename will be included
# as part of the header
#
def write_c_file_header(fd, filepath):
	write_file_header(fd, filepath, "c")

#
# Writes the standard .h file header to the file
#
# fd: open file descriptor to write to
# filepath: the path to the of the file, where the basename will be included
# as part of the header
#
def write_h_file_header(fd, filepath):
	write_file_header(fd, filepath, "header")

#
# Helper function to make and return a string for wide comment headers
# 
# name is the string to be put in the comment header
# if c_open is True, adds opening comment indicator (/*) to beginning of returned string
# if c_close is True, adds closing comment indicator (*/) to end of returned string
# When c_open == c_close == True, returns:
# ```
# /*
#  * +-----------+
#  * |    name   +
#  * +-----------+
#  */
# ```
# spaced to 112 characters-wide
#
def make_formatted_comment_header(name, c_open, c_close):
	width_sans_ends = 107
	
	# This is the `* +---[...]---+` string that can be found at the beginning and end
	envelope_str = "\n * +" + ('-' * width_sans_ends) + "+\n"

	# This is the `* |   name    +` string to be surrounded by envelope str
	white_space  = (" " * int((width_sans_ends - len(name) ) / 2))
	content_str  = " * |" + white_space + name + white_space + "+"

	out = envelope_str + content_str + envelope_str

	if c_open :
		out = "\n/*" + out
	if c_close:
		out = out + " */\n"
	return out

############################ C-BASED UNTAINTING FUNCTIONS ##################################

#
# Takes the passed in string, and replaces any double quotes (")
# with (\"), any newlines with (\\n), and adds \" to the
# beginning and end of the string in an effort to make it safe
# for passing as a string parameter to a c function.
# tainted is the string to reformat, returns the result
#
def function_parameter_format(tainted):
	tainted = re.sub('\"', '\\"', tainted)
	tainted = re.sub('\\n', '\\\n', tainted)
	untainted = "\"" + tainted + "\""
	return untainted

#
# Takes the passed string, and adds c comment character to make it
# print well as a multi-line comment in a c file
#
def multiline_comment_format(tainted):
	comment_width = 100
	
	# replace any comment-ending characters with empty string
	tainted = re.sub('\*/', '', tainted)
	
	# replace newline with newline + comment character
	tainted = re.sub('\\n', '\\n *', tainted)

	# split the lines every x characters to wrap
	tainted_list = tainted.splitlines()
	untainted = []
	for line in tainted_list:
		while len(line) > comment_width:
			left, right = line[:comment_width], line[comment_width:]
			untainted.append("\n * " + left)
			line = right
		untainted.append("\n * " + line) 

	# Add opening and closing comment characters
	untainted = ("/*" + "".join(untainted) + "\n */")
	return untainted


############################# C CODE STRING GENERATION ##########################

#
# Given a list of files, creates the string neccessary to #include all of
# them in a .[ch] file
# Returns the completed string.
#
def make_includes(files):
	out = ""
	for f in files:
		out = out + "\n#include \"{}\"".format(f)
	out = out + "\n\n"

	return out

#
# Makes and returns the function call to UI_ADD_PARMSPEC_* for the item passed
# name is the name returned by the call to initialize_names, item is the edd,
# variable, etc. to call UI_ADD_PARMSPEC_ for, coll is the collection the
# item belongs to (cs.[edd|var|op..])
#
def make_ui_add_parmspec_call(name, coll, item):
	call_template  = "UI_ADD_PARMSPEC_{0}({1}"
	param_template = ", \"{0}\", {1}"

	# If there are no parameters, return
	params = cu.item_get_params(item)
	if params == []:
		return "\n\t"

	ari = cu.make_ari_name(name, coll, item)
	
	out = call_template.format(str(len(params)), ari)

	# Add each parameter to the function call
	for parameter in params:
		amp_type = cu.make_amp_type_name_from_str(parameter["type"])
		out = out + param_template.format(parameter["name"], amp_type)

	return out + ");\n\n\t"


#
# creates and returns the string for a call to ari_from_value()
#
def make_ari_from_value_call(name, coll, item_name):
	ari_str = cu.make_ari_name_from_str(name, coll, item_name)
	return make_ari_from_value_call_from_ari(ari_str)

#
# Makes and returns the function call string for adm_add_edd
# ari is the ari of this item
# the rest of the passed values are parameters to pass to the adm_add_edd function
#
def make_adm_add_edd_call(ari, amp_type, num_parms, collect, to_string, size):
	params = [amp_type, num_parms, collect, to_string, size]
	return make_adm_add_generic_call(cs.EDD, ari, params)

#
# Makes and returns the function call string for adm_add_ctrl
# ari is the ari string for this item 
# param is the parameter to pass to adm_add_macro
#
def make_adm_add_ctrl_call(ari, param):
	params = [param]
	return make_adm_add_generic_call(cs.CTRL, ari, params)

#
# Makes and returns the function call string for adm_add_const
# ari is the ari string for this item 
# param is the parameter to pass to adm_add_macro
#
def make_adm_add_const_call(ari, param):
	params = [param]
	return make_adm_add_generic_call(cs.CONST, ari, params)

#
# Makes and returns the function call string for adm_add_macro
# ari is the ari string for this item 
# param is the parameter to pass to adm_add_macro
#
def make_adm_add_macro_call(ari, param):
	params = [param]
	return make_adm_add_generic_call(cs.MACRO, ari, params)

#
# Makes and returns the function call string for adm_add_ops
# ari is the ari string for this item 
# param is the parameter to pass to adm_add_ops
#
def make_adm_add_op_call(ari, param):
	params = [param]
	return make_adm_add_generic_call(cs.OP, ari, params)

#
# Makes and returns the function call string for adm_add_var
# ari is the ari string for this item 
# param_type and param_expr are the other parameters to pass to adm_add_var
#
def make_adm_add_var_call(ari, param_type, param_expr):
	params = [param_type, param_expr]
	return make_adm_add_generic_call(cs.VAR, ari, params)

#
# Makes and returns the basename, fullname, and signature tuple for the edd
# collect functions; where basename = edd_<edd-name> and fullname = <name>_<basename>
#
def make_collect_function(name, edd):
	basename = "get_{}".format(edd["name"].lower())
	fullname = "{0}_{1}".format(name.lower(), basename)
	signature = "tnv_t *{}(tnvc_t *parms)".format(fullname)
	return basename, fullname, signature

#
# Makes and returns the basename, fullname, and signature tuple for the metadata
# collect functions; where basename = <keyword>_<meta-name> and fullname = <name>_<basename>
#
def make_meta_function(name, meta):
	keyword = cs.get_sname(cs.META)
	basename = "{0}_{1}".format(keyword, meta["name"].lower())
	fullname = "{0}_{1}".format(name.lower(), basename)
	signature = "tnv_t *{}(tnvc_t *parms)".format(fullname)
	return basename, fullname, signature

#
# Makes and returns the basename, fullname, and signature tuple for the constant
# function; where basename = <keyword>_<const-name> and fullname = <name>_<basename>
#
def make_constant_function(name, const):
	keyword = "get"
	basename = "{0}_{1}".format(keyword, const["name"].lower())
	fullname = "{0}_{1}".format(name.lower(), basename)
	signature = "tnv_t *{}(tnvc_t *parms)".format(fullname)
	return basename, fullname, signature

#
# Makes and returns the basename, fullname, and signature tuple for the control
# functions; where basename = <keyword>_<control-name> and fullname = <name>_<basename>
#
def make_control_function(name, control):
	keyword = cs.get_sname(cs.CTRL)
	basename = "{0}_{1}".format(keyword, control["name"].lower())
	fullname = "{0}_{1}".format(name.lower(), basename)
	signature = "tnv_t *{}(eid_t *def_mgr, tnvc_t *parms, int8_t *status)".format(fullname)
	return basename, fullname, signature

#
# Makes and returns the basename, fullname, and signature tuple for the operator
# functions; where basename = <keyword>_<op-name> and fullname = <name>_<basename>
#
def make_operator_function(name, op):
	keyword = "op" #XXX naming inconsistency. Fix. #cs.get_sname(cs.OP)
	basename = "{0}_{1}".format(keyword, op["name"].lower())
	fullname = "{0}_{1}".format(name.lower(), basename)
	signature = "tnv_t *{}(vector_t *stack)".format(fullname)
	return basename, fullname, signature

#
# Makes and returns the basename, fullname, and signature tuple for the table
# functions; where basename = tbl_<tbl-name> and fullname = <name>_<basename>
#
def make_table_function(name, tbl):
	keyword = cs.get_sname(cs.TBL)
	basename = "{0}_{1}".format(keyword, tbl["name"].lower())
	fullname = "{0}_{1}".format(name.lower(), basename)
	signature = "tbl_t *{}(ari_t *id)".format(fullname)
	return basename, fullname, signature

#
# Returns a string for a valid call to the names_add_name() function
# name is the name returned from a call to get_adm_names()
# coll is the collection the item belongs to cs.[EDD|VAR|...]
# item is the items to add. Assumes item contains a value for "name" and
# "description"
#
def make_names_add_name_call(name, coll, item):
	add_name_str = "names_add_name(\"{0}\", {1}, {2}, {3});\n\t"
	ari = cu.make_ari_name(name, coll, item)

	return add_name_str.format(item["name"].upper(),
				   function_parameter_format(item["description"]),
				   name.upper(), ari)


############################ C CODE WRITING TO FILE ###########################

#
# Writes an init function to the passed c_file.
# name is the name returned by a call to initialize_names,
# coll is the collection to make the init function for. Can be None
# body is the body of the function.
#
def write_formatted_init_function(c_file, name, coll, body):
	ttype = None
	if coll is not None:
		ttype = "_" + cs.get_sname(coll).replace("-","_")
	else:
		ttype = ""
		
	init_funct_string = (
		"void {0}_init{1}()"
		"\n{{"
		"\n{2}"
		"\n}}"
		"\n\n")

	c_file.write(init_funct_string.format(name, ttype, body))

#
# Builds the new parm format
# d is a definition of a macro or rptt
# uses is the uses dictionary passed from CAmpPython.py
#
def make_build_adm_build_ari_parm(d, uses, params):
	def_ari = cu.make_ari_name_from_ns_nm(d["ns"], d["nm"])
	def_coll = cs.name_get_coll(d["nm"].split('.')[0])
	def_g_var_idx = cu.make_g_var_idx(d["ns"])
	def_type = "AMP_TYPE_" + cs.get_sname(def_coll).upper()

	# actual params
	aps = d.get("ap", None)
	if aps:	
		# find params types in uses
		types = get_params_types(d, uses)
		
		ari_parm_str = "ADM_BUILD_ARI_PARM_{0}({1}, {2}[ADM_{3}_IDX], {4}".format(len(aps), def_type, def_g_var_idx,
											  cs.get_lname(def_coll).upper(), def_ari)

		# for each ap
		for idx, a in enumerate(aps):
			
			# find its type in it's collection
			ptype = types[idx].upper()

			# find the index in the params for this item
			for pidx, p in enumerate(params):
				if p["name"] == a["value"]:
					ari_parm_str = ari_parm_str + ", tnv_from_map(AMP_TYPE_{0}, {1})".format(ptype, pidx)

		return ari_parm_str + ")"

	# formal params
	elif len(d["nm"].split('(')) > 1 :
		# get the values between the parenthesis
		value = d["nm"].split('(')[1].split(')')[0]
		fps = value.split(',')		

		types = get_params_types(d, uses)
		
		ari_parm_str = "ADM_BUILD_ARI_PARM_{0}({1}, {2}[ADM_{3}_IDX], {4}".format(len(fps), def_type, def_g_var_idx,
											  cs.get_lname(def_coll).upper(), def_ari)

		for idx, f in enumerate(fps):
			ftype = types[idx].lower()
			ari_parm_str = ari_parm_str + ", tnv_from_{0}({1})".format(ftype, value)
			
		return ari_parm_str + ")"

	

	# no params
	else:
		return make_adm_build_ari_template(def_coll, def_g_var_idx, False).format("0", def_ari)
	
	

#
# Constructs and writes the init_macros function
#
# c_file is an open file descriptor to write to,
# name is the value returned from get_adm_names()
# macros is a list of macros to add
#
def write_init_macro_function(c_file, name, g_var_idx, macros, data, uses, mgr):
	body = ""
	meta_decl_str =	"\n\tmetadata_t *meta = NULL;\n"
	macdef_decl_str = "\n\tmacdef_t *def = NULL;\n"
	added_meta = False
	added_macdef = False
	
	macdef_create_template = "macdef_create({0}, {1});"
	add_macdef_ctrl_str = "\n\tadm_add_macdef_ctrl(def, {});"
	adm_add_macdef_str = "\n\tadm_add_macdef(def);"
	# XXX: this hardcoding should be fixed
	meta_add_macro_template = "\n\tmeta = meta_add_macro" + "(def->ari, " + "ADM_ENUM_" + name.upper() + ", \"{0}\", \"{1}\");"
	meta_add_parm_template = "\n\tmeta_add_parm(meta, \"{0}\", AMP_TYPE_{1});"
	
	build_ari_str_template = make_adm_build_ari_template(cs.MACRO, g_var_idx, False)
	
	for i in macros:
		try:
			ari = cu.make_ari_name(name, cs.MACRO, i)
			body = body + "\n\n\t/* {} */".format(i["name"].upper())

			macdef_create_str = "\n\t" + macdef_create_template
			
			params_tf = "0"
			params = cu.item_get_params(i)
			if params:
				params_tf = "1"

			build_ari_str = build_ari_str_template.format(params_tf, ari)

			defs = cu.item_get_def(i)
			defs_str = ""
			if defs:
				macdef_create_str = "\n\tdef = " + macdef_create_template
				added_macdef = True

			macdef_create_str = macdef_create_str.format(len(defs), build_ari_str)			

			for idx,d in enumerate(defs):
				def_build_ari_parm_str = make_build_adm_build_ari_parm(d, uses, params);
				defs_str = defs_str + add_macdef_ctrl_str.format(def_build_ari_parm_str)

			body = body +  macdef_create_str
			body = body + defs_str
			body = body + adm_add_macdef_str
			
			if mgr:
				added_meta = True
				body = body + meta_add_macro_template.format(i["name"], i["description"])
				for p in params:
					body = body + meta_add_parm_template.format(p["name"], p["type"].upper())
				
		except KeyError, e:
			print "[ Error ] Badly formatted macro. Key not found:"
			print e
			raise

	# only add these declarations if the variables will be used; to avoid compiler warnings
	if(added_macdef):
		body = macdef_decl_str + body
	if(added_meta):
		body = meta_decl_str + body

	write_formatted_init_function(c_file, name, cs.MACRO, body)

# 
# helper function for writing the function for 
# variable definitions 
# creates and writes the entries for the expression lyst to 
# c_file 
#
def make_parm_lyst_string(name, var, data, uses, default_adm):
	out             = "\tdef = lyst_create();\n\t"
	cur_ari_template = "cur_ari = {};\n\t"
	lyst_insert_str = "lyst_insert_last(def, cur_item);\n\n\t"

		
	try:
		for i in cu.item_get_postfix(var):
			adm, coll, item_name, d_params = cu.parse_definition(i, default_adm)
			adm = adm.replace("/","_")
			ari = make_ari_from_value_call(adm, coll, item_name) 
			out = out + cur_ari_template.format(ari)

			out = out + make_parm_calls(i, var.get("parmspec",[]), data, uses, name, "var")

			out = out + lyst_insert_str.format(ari)
	except KeyError, e:
		print "[Error ] Badly formatted variable. Key not found:"
		print e
		raise
	
	return out + "\n"

#
# Makes the adm_build_ari(..) template for the passed collection type and
# g_*_idx
# Caller should format the template with returned_str.format([0|1](whether params are present), ari_name)
#
# standalone is a boolean wheter or not the call needs to stand alone. If False, the call should be used
# as an argument to another function. 
#
def make_adm_build_ari_template(coll, g_var_idx, standalone):
	# XXX: need to fix the names in campsettings to avoid these conditionals
	type_keyword = cs.get_sname(coll).upper()
	idx_keyword = cs.get_lname(coll).upper()
	
	if(coll == cs.OP):
		type_keyword = cs.get_lname(coll).upper()
	elif (coll == cs.META):
		type_keyword = cs.get_sname(cs.CONST).upper()
		idx_keyword = cs.get_sname(coll).upper()	
		
	template = "adm_build_ari(AMP_TYPE_" + type_keyword + ", {0}, " + g_var_idx + "[ADM_" + idx_keyword + "_IDX], {1})"
	if standalone:
		template = "\n\tid = " + template + ";"
	return template

# Builds a template for the
# ```
# meta_add_...
# ```
# calls with passed collection type and adm name. Should be formatted in the calling
# function with:
# return_str.format(ari_amp_type, item[name], item[description])
#
# The intention behind this function is to only have to construct these parts once for each
# collection. Subset of formatted values that need to be substituted for_each_ item in the
# collection is much smaller.
#
# XXX needs refactored along with rest of this code. Ex: ADM_ENUM_ shouldn't be hardcoded
#
def make_std_meta_add_coll_template(coll, name):
	return "meta_add_" + cs.get_sname(coll).lower() + "({0}, id, ADM_ENUM_" + name.upper() + ", \"{1}\", \"{2}\");\n"

#
#
#
def def_get_names(d):
	adm = d["ns"].upper()
	coll, name = d["nm"].split('.')

	coll = cs.name_get_coll(coll)
	name = name.split('(')[0].upper()
	
	return adm, coll, name
	

#
#
# XXX something similar is in camputil, but not exactly the signature we want. Refactor
def get_params_types(pfx, uses):
	adm, coll, name = def_get_names(pfx)
	
	# find the right ADM
	adm = uses.get(adm, [])

	# find the right coll
	collection = cu.get_collection(adm, coll)

	# find the right item
	for item in collection:
		# if its name matches, return false if in_types are empty, true if not
		if item["name"].upper() == name:
			p = cu.item_get_params(item)

			# returns a list of the type keys found in parmspec
			return [d["type"] for d in p]
	return []

#
# Checks if the passed pfx has parameters. Returns tuple of (bool, string);
# (True, "1") if true (False, "0") if false.
#
def has_params(pfx, uses):
	adm, coll, name = def_get_names(pfx)
	# find the right ADM
	adm = uses.get(adm, [])
	
	# find the right coll
	collection = cu.get_collection(adm, coll)

	# find the right item
	for item in collection:
		# if its name matches, return false if in_types are empty, true if not
		if item["name"].upper() == name:
			p = cu.item_get_in_types(item)
			if not p :
				return False, "0"
			else:
				return True, "1"

#
# Writes the init_variables body 
# for each variable creates a lyst for its postfix-expr and writes 
# its appropriate adm_add_var function
#
# TODO: cur_ari in generated function is unused
#
def write_init_var_function(c_file, name, g_var_idx, variables, data, uses, mgr):
	body = ""
	coll_decl_str = "\n\tari_t *id = NULL;\n"
	expr_decl_str = "\n\texpr_t *expr = NULL;\n"

	expr_create_str = "\n\texpr = expr_create({});"
	expr_add_str    = "\n\texpr_add_item(expr, {});" 
	add_var_from_expr = "\n\tadm_add_var_from_expr(id, {}, expr);"
	
	# gives you the adm_build_ari(...)
	build_str_template = "\n" + make_adm_build_ari_template(cs.VAR, g_var_idx, True)
	# gives you the meta_add_var(... )
	meta_add_template = make_std_meta_add_coll_template(cs.VAR, name)

	added_coll = False
	added_expr = False

	for i in variables:
		try:
			ari = cu.make_ari_name(name, cs.VAR, i)
			amp_type = cu.make_amp_type_name(i)
			
			body = body + "\n\n\t/* {} */".format(i["name"].upper())
			body = body +  build_str_template.format("0", ari)

			expr_str = ""
			pfxs = cu.item_get_postfix(i)

			for pfx in pfxs:
				pfx_ari = cu.make_ari_name_from_ns_nm(pfx["ns"], pfx["nm"])
				pfx_coll = cs.name_get_coll(pfx["nm"].split('.')[0])
				pfx_g_var_idx = cu.make_g_var_idx(pfx["ns"])

				# Need to check if the var has parameters - find in uses
				_,param_flag = has_params(pfx, uses)

				pfx_build_ari = make_adm_build_ari_template(pfx_coll, pfx_g_var_idx, False).format(param_flag, pfx_ari)

				expr_str = expr_str + expr_add_str.format(pfx_build_ari)

			if pfxs:
				init_type = cu.make_amp_type_name(cu.item_get_initializer(i))
				# append the expr_create string
				expr_str = expr_create_str.format(init_type) + expr_str
				# prepand the adm_add_var_from_expr string
				expr_str = expr_str + add_var_from_expr.format(init_type)
				
				added_expr = True

			body = body + expr_str

			if mgr:
				body = body + "\n\t" + meta_add_template.format(amp_type, i["name"], i["description"])

			added_coll = True
			
		except KeyError, e:
			print "[ Error ] Badly formatted variable. Key not found:"
			print e
			raise

	# only add these declarations if the variables will be used; to avoid compiler warnings
	if(added_expr):
		body = expr_decl_str + body
	if(added_coll):
		body = coll_decl_str + body

	write_formatted_init_function(c_file, name, cs.VAR, body)


#
# Writes the init_reports() function to the open file descriptor passed as c_file
# name is the value returned from get_adm_names()
# data is the dictionary made from loading the JSON for this ADM. This function
# needs the entire dictionary in order to correctly parameterize the output.
# mgr is a boolean value which will result in the addition of the meta_add_*()
# function for every report if == True
# uses is the dictionary of imported JSON files
#
def write_parameterized_init_reports_function(c_file, name, g_var_idx, data, uses, mgr):
	body = ""
	rpt_decl_str = "\n\trpttpl_t *def = NULL;\n"
	meta_decl_str =	"\n\tmetadata_t *meta = NULL;\n"
	added_rpt = False
	added_meta = False
	
	rpt_create_template = "rpttpl_create_id({});"
	build_ari_str_template = make_adm_build_ari_template(cs.RPT, g_var_idx, False)
	
	add_item_template = "\n\trpttpl_add_item(def, {});"

	adm_add_str = "\n\tadm_add_rpttpl(def);"

	meta_add_rpt_template = "meta_add_rpttpl(def->id, ADM_ENUM_"+name.upper()+", \"{0}\", \"{1}\");"
	meta_add_parm_template = "\n\tmeta_add_parm(meta, \"{0}\", AMP_TYPE_{1});"

	for i in cu.get_reports(data):
		try:
			ari = cu.make_ari_name(name, cs.RPT, i)
			body = body + "\n\t/* {} */".format(i["name"].upper())
			
			rpt_create_str = "\n\t" + rpt_create_template
			params_tf = "0"
			params = cu.item_get_params(i)
			if params:
				params_tf = "1"	
				
			defs_str = ""
			defs = cu.item_get_def(i)
			if defs:
				rpt_create_str = "\n\tdef = " + rpt_create_template
				added_rpt = True
			for idx, d in enumerate(defs):
				def_build_ari_str = make_build_adm_build_ari_parm(d, uses, params)
				defs_str = defs_str + add_item_template.format(def_build_ari_str)

			body = body + rpt_create_str.format(build_ari_str_template.format(params_tf, ari))
			body = body + defs_str
			body = body + adm_add_str

			if mgr:
				meta_add_rpt_str = meta_add_rpt_template.format(i["name"], i["description"])
				meta_add_parm_str = ""

				if params:
					meta_add_rpt_str = "meta = " + meta_add_rpt_str
					added_meta = True
					
					for p in params:
						meta_add_parm_str += meta_add_parm_template.format(p["name"], p["type"].upper())
					
				body = body + "\n\t" + meta_add_rpt_str + meta_add_parm_str				

				
			added_rpt = True
		except KeyError, e:
			print "[ Error ] Badly formatted report. Key not found:"
			print e
			raise

	# only declare variables if they're going to be used
	if added_rpt:
		body = rpt_decl_str + body
	if added_meta:
		body = meta_decl_str + body
		
		
	write_formatted_init_function(c_file, name, cs.RPT, body)

#
#
#
def write_init_tables_function(c_file, name, g_var_idx, tables, mgr):
	body = ""
	tbl_decl_str = "\n\ttblt_t *def = NULL;"
	tbl_create_template = "\n\tdef = tblt_create({0}, {1});"
	
	build_ari_template = make_adm_build_ari_template(cs.TBL, g_var_idx, False)

	add_tblt_str = "\n\tadm_add_tblt(def);"
	meta_add_template = "\n\tmeta_add_tblt(def->id, ADM_ENUM_"+name.upper()+", \"{0}\", \"{1}\");"

	add_col_template = "\n\ttblt_add_col(def, {0}, \"{1}\");"
	
	added_table = False

	for i in tables:
		ari = cu.make_ari_name(name, cs.TBL, i)
		tbl_build_ari_str = build_ari_template.format("0", ari)

		body = body + "\n\n\t/* {} */\n".format(i["name"].upper())

		if mgr:
			body = body + tbl_create_template.format(tbl_build_ari_str, "NULL")
		else:
			body = body + tbl_create_template.format(tbl_build_ari_str, ari.lower())

		added_table = True
		
		cols = cu.item_get_columns(i)

		for c in cols:
			c_amp_type = cu.make_amp_type_name(c)
			body = body + add_col_template.format(c_amp_type, c["name"])

		body = body + add_tblt_str
		if mgr:
			body = body + meta_add_template.format(i["name"], i["description"])

	if added_table:
		body = tbl_decl_str + body

	write_formatted_init_function(c_file, name, cs.TBL, body)


	
############################### SHOULD BE MARKED STATIC ###########################

#
# Writes the standard file header to the file
#
# fd: open file descriptor to write to
# filepath: the path to the of the file, where the basename will be included
# as part of the header
# modifier: string indicating type of file this is ('c' or 'header' are common values)
#
def write_file_header(fd, filepath, modifier):
	standard_header = (
		"/****************************************************************************\n"
		" **\n"
		" ** File Name: {0}\n"
		" **\n"
		" ** Description: TODO\n"
		" **\n"
		" ** Notes: TODO\n"
		" **\n"
		" ** Assumptions: TODO\n"
		" **\n"
		" ** Modification History: \n"
		" **  YYYY-MM-DD  AUTHOR           DESCRIPTION\n"
		" **  ----------  --------------   --------------------------------------------\n"
		" **  {1}  AUTO             Auto-generated {2} file \n"
		" **\n"
		" ****************************************************************************/\n\n")

	fd.write(standard_header.format(os.path.basename(filepath), str(datetime.datetime.now().date()), modifier))

#
# Given a passed ari value, returns a formatted call to the ari_from_value()
# function.
#
def make_ari_from_value_call_from_ari(ari):
	return "ari_from_value({0})".format(ari)

#
# Generic function for making an adm_add_*() function call
# coll is the collection that the adm_add_function belongs to (cs.[EDD|VAR|...])
# ari is the ari of the item to add, params is a list of strings of
# any additional parameters to pass to the adm_add_*() function
#
def make_adm_add_generic_call(coll, ari, params):
	template = "adm_add_{0}({1}"
	param_template = ", {}"

	ari_from_value = make_ari_from_value_call_from_ari(ari)
	
	out = template.format(cs.get_sname(coll), ari_from_value)

	for p in params:
		out = out + param_template.format(p)
		
	out = out + ");\n\t"
	return out

#
# Creates and returns a string for the calls necessary to add and map parameters for a
# definition of a report template
# @definition is the unparsed string value of the definition to complete parms for
# @paramspec is the list of param dictionarys for this report
# @data is the dictionary for this JSON, created by a call to json_load
# @uses is the dictionary of imported JSON files
#
# XXX unused?
def make_parm_calls(definition, paramspec, data, uses, name, dtype):
	out = ""
	default_adm = data[cs.get_lname(cs.META)][1]["value"]
	ari_add_param_str      = "ari_add_param_from_value(cur_ari, val_from_{0}({1}));\n\t"
	cur_item_stat_parm_str = "cur_item = "+ dtype +"_item_create(cur_ari, {0});\n\t"
	add_parm_map_str       = dtype + "_item_add_parm_map(cur_item, {1}, {0});\n\t"
	d_adm, d_coll, d_name, parms = cu.parse_definition(definition, default_adm)

	mapping_dest = {}

	parm_types = []

	if len(parms) > 0:
		# Need to look for the types of the parameters in their original location, 
		# and default values if they exist  
		
		try:
			parm_types = cu.get_parm_types(d_adm, d_coll, d_name, data, uses)
			default = cu.get_default_values(d_adm, d_coll, d_name, data, uses)
		except Exception as e:
			return ""

		if parm_types == None:
			print "[Error] ", d_name, " not found in the supplied ADM"	
			raise e

		if( len(parm_types) != len(parms) ) :
			print "[Error] number of parameters provided for report does not match number expected by ", d_name
			raise Exception


		index = 0
		# For each parameter in this structure
		for info in parms:
			# the parms type and value 
			# if using string encoding
			if isinstance(info, unicode) or isinstance(info, str):
				match = re.match("^(.+=)?(.+)?$",info)
				type_enum = match.group(1) or None
				if type_enum != None:
					if " " in type_enum:
						type_enum=type_enum.split(" ")
						type_enum=type_enum[0]
					type_enum = (type_enum.replace("=","")).strip()
				valued_param = match.group(2) or None 
				
				if valued_param != None: 
					match = re.match("<(.+)>", valued_param)
					if (match):
						valued_param = match.group(1) 
						type_enum = "ParmName"
			else:
				type_enum, valued_param = info.get('type',None), info.get('value',None)

			if type_enum == None:
				type_enum = parm_types[index]

			# If the parameter is mapped, use the default value for now and save the mapping
			if type_enum == "ParmName":
				src = None 
				i = 0 
				for p in paramspec:
					if p['name'] == valued_param:
						src = i 
						break  
					i = i + 1

				if src == None:
					print "Error: could not find source for ", str(index), " parameter for " + dtype , str(name)
					raise Exception

				mapping_dest[index] = src
				type_enum = paramspec[i]['type']
				parm_value = cu.get_default_for_type(type_enum)
			# Otherwise, parse the given value to the right type to print or default value 
			# or if error if type mis match or not defined assumed right  
			elif type_enum == parm_types[index] :
				# if the parm is using the default value. 
				if valued_param == "" or valued_param == None:
					parm_value = default[index]
				else: 
				 	parm_value = valued_param
			else:
				print "Error: Type mismatch for: ", str(index), " parameter for " + dtype, str(name)
				raise Exception	

			# Add the ari_add_param_from_value() call for each parameter
			out = out + ari_add_param_str.format(type_enum.lower(), parm_value)

			index = index + 1

	# Create the dtype_item with the correct number of mapped items
	out = out + cur_item_stat_parm_str.format(str(len(mapping_dest.keys())))

	# For each mapped parameter, add the mapping.
	# NOTICE: indices for the called c function start at 1
	for dest, src in mapping_dest.items():
		out = out + add_parm_map_str.format(str(dest+1), str(src+1))


	return out
