# JHU/APL
# Description: creates the c file for the public version of the adm
# Modification History:
#   YYYY-MM-DD     AUTHOR            DESCRIPTION
#   ----------     ---------------   -------------------------------
#   2017-08-11		Evana
#	2017-12-28     David 			Metadata is in constants now
#
###############################################

import re
import os
import errno

from lib import campch
from lib.common import camputil as cu
from lib.common import campsettings as cs

#
# Constructs and returns the filename for this generated file. 
#
# Also creates the agent directory in the out directory
# if it doesn't exist.
#
# name is the name returned from a call to get_adm_names()
# outpath is the path to the output directory
#
def initialize_file(name, outpath):
	# Make the agent dir, only allow the 'directory exists' error
	try:
		os.mkdir(outpath + "/agent/")
	except OSError as ose:
		if(not ose.errno == errno.EEXIST):
			print "[ Error ] Failed to create subdirectory in ", outpath
			print ose
			exit(-1)
			
	filename = outpath + "/agent/" + name + "_agent.c"		
	return filename

#
# Writes all of the #includes for this c file
#
# c_file is an open file descriptor to be written to
# name is the name provided by get_adm_names()
#
def write_includes(c_file, name):
	files = ["ion.h", "platform.h",
		 "../shared/adm/{}.h".format(name), "../shared/utils/utils.h",
		 "../shared/primitives/report.h",   "../shared/primitives/blob.h",
		 "{}_impl.h".format(name),          "rda.h"]

	c_file.write(campch.make_includes(files))

#
#
#
def write_uses_includes(c_file, uses):
	c_file.write(campch.make_includes(cu.get_uses_files(uses)))

#
# Writes the init function to the file
# Includes a custom body tag with TODO
#
# c_file is an open file descriptor to write to
# name is the basic name provided by get_adm_names()
#
# XXX: very similar to function in create_mgr_c.py. consider combining
def write_init_function(c_file, name, g_var_idx, data):
	nupper = name.upper()

	vdb_adds = "\tadm_add_adm_info(\"" + name + "\", ADM_ENUM_"+name.upper()+");\n"

	init_calls = "\n\t" + name + "_setup();"

	vdb_add_template = "\n\tVDB_ADD_NN(((ADM_ENUM_"+name.upper()+" * 20) + ADM_{0}_IDX), &({1}[ADM_{0}_IDX]));"
	init_funct_template = "\n\t"+name+"_init_{0}();"

	# only generate NN's for elements that appear in the ADM
	for coll in data.keys():
		if coll.lower() == "uses": continue
		
		# Get the enum version of the coll instead of string
		coll = cs.name_get_coll(coll)

		# XXX: need to fix META hardcoding
		vdb_adds = vdb_adds + vdb_add_template.format(cs.get_lname(coll).upper(), g_var_idx).replace("MDAT", "META")
		
	# order of init functions matters.
	for coll in [cs.META, cs.CONST, cs.EDD, cs.OP, cs.VAR, cs.CTRL, cs.MACRO, cs.RPT, cs.TBL]:
		
		init_calls = init_calls + init_funct_template.format(cs.get_sname(coll).lower())
	
	body = vdb_adds + "\n\n" + init_calls
	
	campch.write_formatted_init_function(c_file, name, None, body)

#
#
#
def make_std_meta_adm_build_template(coll, g_var_idx):
	build_ari_template = campch.make_adm_build_ari_template(coll, g_var_idx, False)
	return "\n\tadm_add_" + cs.get_sname(coll).lower() + "(" + build_ari_template + ", {2});"

#
#
#
def write_agent_std_init_function(c_file, name, g_var_idx, coll_type, coll):
	body = ""
	add_str = make_std_meta_adm_build_template(coll_type, g_var_idx)

	for i in coll:
		try:
			ari = cu.make_ari_name(name, coll_type, i)
			parms_tf = "0"
			if cu.item_get_params(i) : parms_tf = "1"
			# XXX These .replaces are not ideal. Should be using make_*_function() utils in campch.py
			body = body + add_str.format(parms_tf, ari, ari.lower().replace("edd", "get").replace("cnst", "get"))
		except KeyError, e:
			print "[ Error ] Badly formatted "+cs.get_lname(coll_type).lower()+". Key not found:"
			print e
			raise
			
	campch.write_formatted_init_function(c_file, name, coll_type, body)
	
#
# Constructs and writes the init metadata function
#
# c_file is an open file descriptor to write to
# name is the name returned by a call to get_adm_names()
# metadata is a list of metadata to add
#
# XXX: This one could almost use the standard one if it weren't for the 'cnst' keyword
# being used everywhere. Note also that the 'std' function is only used by a couple, and
# had to have special cases to work for them. Re-evaluate
#
def write_init_metadata_function(c_file, name, g_var_idx, metadata):
	body = ""
	build_ari_template = campch.make_adm_build_ari_template(cs.CONST, g_var_idx, False).replace("ADM_CONST_IDX","ADM_META_IDX")
	add_str_template = "\n\tadm_add_cnst(" + build_ari_template + ", {2});"

	for i in metadata:
		try:
			ari = cu.make_ari_name(name, cs.META, i)
			body = body + add_str_template.format("0", ari, ari.lower())
		except KeyError, e:
			print "[ Error ] Badly formatted metadata. Key not found:"
			print e
			raise

	campch.write_formatted_init_function(c_file, name, cs.META, body)
	
#
# Constructs and writes the init_constants function
#
# c_file is an open file descriptor to write to,
# name is the value returned from get_adm_names()
# constants is a list of constants to add
#
def write_init_constant_function(c_file, name, g_var_idx, constants):
	write_agent_std_init_function(c_file, name, g_var_idx, cs.CONST, constants)
	
#
# Constructs and writes the init_edd function
#
# c_file is an open file descriptor to write to
# name is the value returned from get_adm_names()
# edds is a list of the edds to add
#
def write_init_edd_function(c_file, name, g_var_idx, edds):
	write_agent_std_init_function(c_file, name, g_var_idx, cs.EDD, edds)

#
# Constructs and writes the init_operators function
#
# c_file is an open file descriptor to write to,
# name is the value returned from get_adm_names()
# operators is a list of operatorss to add
#
# XXX: need to fix hardcoding
#
def write_init_op_function(c_file, name, g_var_idx, operators):
	body = ""
	adm_add_op_template = "\n\tadm_add_op(" + g_var_idx + "[ADM_"+cs.get_lname(cs.OP).upper()+"_IDX], {0}, {1}, {2});"

	for i in operators:
		try:
			ari = cu.make_ari_name(name, cs.OP, i)
			in_types = cu.item_get_in_types(i)
			body = body + adm_add_op_template.format(ari, len(in_types), ari.lower())
		except KeyError, e:
			print "[ Error ] Badly formatted operator. Key not found:"
			print e
			raise

	campch.write_formatted_init_function(c_file, name, cs.OP, body)

#
# Writes the init_variables body 
# for each variable creates a lyst for its postfix-expr and writes 
# its appropriate adm_add_var function
#
def write_init_var_function(c_file, name, g_var_idx, variables, data, uses):
	campch.write_init_var_function(c_file, name, g_var_idx, variables, data, uses, False)
	
#
# Constructs and writes the init_controls function
#
# c_file is an open file descriptor to write to,
# name is the value returned from get_adm_names()
# controls is a list of controls to add
#
def write_init_control_function(c_file, name, g_var_idx, controls):
	body = ""
	adm_add_op_template = "\n\tadm_add_ctrldef(" + g_var_idx + "[ADM_"+cs.get_lname(cs.CTRL).upper()+"_IDX], {0}, {1}, {2});"

	for i in controls:
		try:
			ari = cu.make_ari_name(name, cs.CTRL, i)
			parm = cu.item_get_params(i)
			body = body + adm_add_op_template.format(ari, len(parm), ari.lower())
		except KeyError, e:
			print "[ Error ] Badly formatted control. Key not found:"
			print e
			raise

	campch.write_formatted_init_function(c_file, name, cs.CTRL, body)

#
# Constructs and writes the init_macros function
#
# c_file is an open file descriptor to write to,
# name is the value returned from get_adm_names()
# macros is a list of macros to add
#
def write_init_macro_function(c_file, name, g_var_idx, macros, data, uses):
	campch.write_init_macro_function(c_file, name, g_var_idx, macros, data, uses, False)

#
# Constructs and writes the init reports function
#
# c_file is an open file descriptor to write to
# name is the name returned by the call to get_adm_names()
# data is a dictionary of the JSON file. This function needs
# the entire dictionary in order to determine the type of parameter in a
# statcially parameterized report
# uses is a dictionary of the JSON dictionaries imported with the 'uses'
# construct
#
def write_init_reports_function(c_file, name, g_var_idx, data, uses):
	campch.write_parameterized_init_reports_function(c_file, name, g_var_idx, data, uses, False)

#
#
#
def write_init_tables_function(c_file, name, g_var_idx, tables):
	campch.write_init_tables_function(c_file, name, g_var_idx, tables, False)
	
#
# Main function of this file, which calls helper functions
# to orchestrate creation of the generated file
#
# data: the dictionary from the parsed JSON file
# outpath: the output directory
# uses: the dictionary of the imported JSON files
#
def create(data, outpath, uses):
	try:
		name, ns = cu.get_adm_names(data)
		ns_upper = ns.upper()
		
		filename = initialize_file(name, outpath)

		c_file = open(filename, "w")
	except KeyError, e:
		print "[ Error ] JSON does not include valid metadata"
		print e
		return
	except IOError, e:
		print "[ Error ] Failed to open ", filename, " for writing."
		print e
		return

	print "Working on ", filename, 

	# Standard header comment, includes and #defines
	campch.write_c_file_header(c_file, filename)
	write_includes(c_file, name)

	write_uses_includes(c_file, cu.get_uses(data))

	c_file.write("#define _HAVE_"+ns_upper+"_ADM_\n")
	c_file.write("#ifdef _HAVE_"+ns_upper+"_ADM_\n\n")

	g_var_idx = cu.make_g_var_idx(ns)
	c_file.write("vec_idx_t {}[11];\n\n".format(g_var_idx))
	
	# Init function
	write_init_function(c_file, ns, g_var_idx, data)

	write_init_metadata_function(c_file, ns, g_var_idx, cu.get_metadata(data))
	write_init_constant_function(c_file, ns, g_var_idx, cu.get_constants(data))

	write_init_edd_function(c_file, ns, g_var_idx, cu.get_edds(data))
	write_init_op_function( c_file, ns, g_var_idx, cu.get_operators(data))
	
	write_init_var_function(    c_file, ns, g_var_idx, cu.get_variables(data), data, uses)
	write_init_control_function(c_file, ns, g_var_idx, cu.get_controls(data))
	write_init_macro_function(  c_file, ns, g_var_idx, cu.get_macros(data), data, uses)
	
	write_init_reports_function(c_file, ns, g_var_idx, data, uses)
	write_init_tables_function( c_file, ns, g_var_idx, cu.get_tables(data))

	c_file.write("#endif // _HAVE_"+ns_upper+"_ADM_\n")
	c_file.close()
	
	print "\t[ DONE ]"
