use amp_core;

CREATE OR REPLACE VIEW vw_obj_metadata AS
       SELECT om.*, adm.adm_name, adm.adm_enum, adm.adm_enum_label, adm.use_desc
       FROM obj_metadata om
       LEFT JOIN adm ON adm.namespace_id=om.namespace_id;
CREATE OR REPLACE VIEW vw_obj_formal_def AS
       SELECT vom.*, ofd.obj_formal_definition_id, ofd.use_desc AS "formal_desc", ofd.obj_enum
       FROM obj_formal_definition ofd
       LEFT JOIN vw_obj_metadata vom ON ofd.obj_metadata_id=vom.obj_metadata_id;
       
