#!/bin/bash
#  FILE:  start_SC.sh
#  NODE:  SC [ipn:21]
#  DESC:  SC ION node on SC
#  DATE:  2023-11-22T11:22
host=`uname -n`
wdir=`pwd`
echo "Clearing old ion.log"
echo > ion.log
echo "Starting ION node ipn:21 on $host from $wdir"
ionadmin  SC.ionrc
sleep  1
ionsecadmin  SC.ionsecrc
sleep  1
ltpadmin  SC.ltprc
sleep  1
bpadmin  SC.bpv7rc
sleep  1
# global contact graph
ionadmin  3node-rhel-graph.cg
echo "Startup of ION node ipn:21 on $host complete!"
echo "Starting bpecho on ipn:21.3."
bpecho   ipn:21.3 &
