# for testing the delete function 

USE amp_core;

set @p_obj_name = 'bundles_by_priority';
select * from obj_definition join obj_identifier on obj_definition.obj_id = obj_identifier.obj_id;
-- select definition_id from obj_definition where obj_id = (SELECT obj_id FROM amp_core.obj_identifier WHERE obj_name = @p_obj_name);

-- set  @fp_spec_id_control_definitionobj_definitionformal_parmspecedd1 = (select fp_spec_id from amp_core.edd_definition where definition_id = (select definition_id from obj_definition where obj_id = (SELECT obj_id FROM amp_core.obj_identifier WHERE obj_name = @p_obj_name)));
-- CALL SP__insert_actual_parms_set(1, @fp_spec_id_edd1, 'UINT', '1', @ap_spec_id); 
-- CALL SP__insert_edd_instance(@edd_definition_id_9, @ap_spec_id,NULL, @edd_inst_id_1);


-- Select * from amp_core.obj_definition;
-- SELECT obj_id FROM amp_core.obj_identifier WHERE obj_name = @p_obj_name;
-- SELECT * from amp_core.obj_definition where obj_id = (SELECT obj_id FROM amp_core.obj_identifier WHERE obj_name = @p_obj_name);

SELECT * FROM vw_edd_instance;
-- CALL SP__delete_obj_definition(0, null, @p_obj_name);
call SP__delete_edd_instance(null, 'bundles_by_priority');
-- CALL SP__delete_edd_instance(null, @p_o-- bj_name);

SELECT * FROM vw_edd_instance;


