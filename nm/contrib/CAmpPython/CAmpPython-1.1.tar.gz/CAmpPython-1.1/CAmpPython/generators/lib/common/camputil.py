# JHU/APL
#
# Description: library file for utility functions related to parsing the
#              JSON input file and creating ARIs
#
# Modification History:
#   YYYY-MM-DD     AUTHOR            DESCRIPTION
#   ----------     ---------------   -------------------------------
#   2017-11-30     Sarah             File creation
#   2018-01-02	   Evana	     Added functionality for tables
#   2018-01-05	   David	     Added new method for creating parameterized aris 
#
#############################################################################

import json
import re
import os
import errno

import campsettings as cs
import jsonutil

def print_error(message):
	print "[ ERROR ] ", message

#
# Class to handle retrieving values from JSON data
#
class Retriever:

	########### Top-level accessors ##############

	#
	# Accessor for the 'uses' construct in the data
	# Returns a list of the names of the ADMs this data 'uses', or an
	# empty list if none are present.
	#
	def get_uses(self):
		return self.data.get("uses", [])

	#
	# Returns the metadata from the JSON
	#
	def get_metadata(self):
		return self.data.get(cs.get_lname(cs.META), [])

	#
	# Accessor for the constants portion of the JSON data
	# returns a list of the requested data, or empty list if none are present
	#
	def get_constants(self):
		return self.data.get(cs.get_lname(cs.CONST), [])

	#
	# Accessor for the EDDs part of the JSON data
	# returns a list of the requested data, or an empty list if none are present
	#
	def get_edds(self):
		return self.data.get(cs.get_lname(cs.EDD), [])

	#
	# Accessor for the controls portion of the JSON data
	# returns a list of the requested data, or an empty list if none are present
	#
	def get_controls(self):
		return self.data.get(cs.get_lname(cs.CTRL), [])

	#
	# Accessor for the operators portion of the JSON data
	# returns a list of the requested data, or an empty list if none are present
	#
	def get_operators(self):
		return self.data.get(cs.get_lname(cs.OP), [])

	#
	# Accessor for the tables part of the data
	# returns a list of the requested data, or an empty list if none are present
	#
	def get_tables(self):
		return self.data.get(cs.get_lname(cs.TBLT), [])
	#
	# Accessor for the variables portion of the JSON data
	# returns a list of the requested data, or an empty list if none are present
	#
	def get_variables(self):
		return self.data.get(cs.get_lname(cs.VAR), [])

	#
	# Accessor for the macros portion of the JSON data
	# returns a list of the requested data, or an empty list if none are present
	#
	def get_macros(self):
		return self.data.get(cs.get_lname(cs.MACRO), [])

	#
	# Accessor for the report-templates portion of the JSON data
	# returns a list of the requested data, or an empty list if none are present
	#
	def get_reports(self):
		return self.data.get(cs.get_lname(cs.RPTT), [])

	#
	# Helper function to extract the collection of c from data.
	# Returns a list, or the empty list if not found or invalid.
	#
	def get_collection(self, coll):
		c_info = {}
		if coll == cs.META:
			return self.get_metadata()
		elif coll == cs.CONST:
			return self.get_constants()
		elif coll == cs.TBLT:
			return self.get_tables()
		elif coll == cs.EDD:
			return self.get_edds()		
		elif coll == cs.CTRL:
			return self.get_controls()
		elif coll == cs.OP:
			return self.get_operators()
		elif coll == cs.VAR:
			return self.get_variables()
		elif coll == cs.MACRO:
			return self.get_macros()
		elif coll == cs.RPTT:
			return self.get_reports()
		else:
			print_error("Invalid ttype")
			return []
	
	############ More granular accessors ############
	
	#
	# Returns the namespace
	#
	def get_ns(self):
		try:
			mdat = self.get_metadata()
			namespace = mdat[1]["value"]
		except KeyError, e:
			print_error("Incorrectly-formatted JSON: no namespace present in metadata\n")
			raise
		return namespace

	#
	# With the passed namespace, returns the g_.*_var_idx for this ADM
	#
	def ns_get_g_var_idx(self, ns):
		ns = ns.lower().replace("/", "_")
		return "g_" + ns + "_idx"

	#
	# Returns the g_.*_var_idx value for this ADM
	#
	def get_g_var_idx(self):
		return self.ns_get_g_var_idx(self.get_ns())
	
	#
	# Returns the name
	#
	def get_name(self):
		try:
			mdat = self.get_metadata()
			name = mdat[0]["value"]
		except KeyError, e:
			print_error("Incorrectly-formatted JSON: no name present in metadata\n")
			raise
		return name


	#
	# Gets specific metadata values from the metadata.
	# Returns a tuple (name, namespace, version, organization).
	# Assumes a specific order to the data (name in mdat[0], etc.)
	#
	def get_mdat_values(self):
		try:
			name = self.get_name()
			ns = self.get_ns()
			
			mdat = self.get_metadata()
			version = mdat[2]["value"]
			organization = mdat[3]["value"]
		except KeyError, e:
			print_error("Incorrectly-formatted JSON: invalid metadata\n")
			raise
		return name, ns, version, organization
	

	#
	# Finds and returns a tuple of (string, string) that is the C-friendly name and
	# the namespace of the ADM as found in the JSON-loaded dictionary.
	# XXX name has 'adm_' appended - re-evaluate this
	#
	# Throws a KeyError exception if JSON is incorrectly formatted (missing keys)
	#
	def get_adm_names(self):
		try:
			name = re.sub('\s', '_', self.get_name()).lower()
			ns = self.get_ns().lower().replace("/", "_")
		except KeyError, e:
			raise

		return "adm_" + name, ns

	#
	# Returns a list of all of the colls present in the JSON
	#
	def get_coll_list(self):
		return self.data.keys()

	def item_get_initializer(self, item):
		return item.get("initializer",{})
	
	#
	# Gets the postfix-expr for the passed item
	#
	def item_get_postfix(self, item):
		init = self.item_get_initializer(item)
		return init.get("postfix-expr",[])

	#
	# Gets the in-type for the passed item
	#
	def item_get_in_types(self, item):
		return item.get("in-type",[])

	#
	# Returns the parameters for the passed item as a list.
	# Returns the empty list [] if no parameters found.
	#
	def item_get_parms(self, item):
		return item.get("parmspec", [])

	def item_get_def(self, item):
		return item.get("definition",[])

	def item_get_columns(self, item):
		return item.get("columns",[])
	
	#
	# Returns the item at the passed adm, coll, name
	#
	def postfix_get_item(self, p):
		# split the pieces you need out of the definition
		a, c, n = self.def_get_names(p)

		# find the right adm
		adm = self.uses.get(a.upper(), [])

		# find the right collection within the adm
		collection = adm.get_collection(c)

		# find the requested item in the collection
		for item in collection:
			if item["name"].upper() == n.upper():
				return item
		return None

	#
	# Checks if the passed pfx has parameters. Returns tuple of (bool, string);
	# (True, "1") if true (False, "0") if false.
	#
	def postfix_has_params(self, p):
		item = self.postfix_get_item(p);
		if not item:
			raise Exception("Item not found\n")
		
		t = self.item_get_in_types(item)
		if not t :
			return False, "0"
		else:
			return True, "1"

	# Returns the ari of the postfix
	def pfx_get_ari(self, p):
		return self.def_get_ari(p)

	# Returns the collection type of the postfix
	def pfx_get_coll(self, p):
		return self.def_get_coll(p)

	# Get the g_var_idx for the postfix
	def pfx_get_g_var_idx(self, p):
		return self.def_get_g_var_idx(p)
	
	# Returns the ari of the definition
	def def_get_ari(self, d):
		ns,coll,name = self.def_get_names(d)
		return make_ari_name_from_str(ns, coll, name)

	# Returns the collection type of the definition
	def def_get_coll(self, d):
		return cs.name_get_coll(d["nm"].split('.')[0])

	def def_get_name(self, d):
		return d["nm"].split('.')[1].split('(')[0]

	# Get the g_var_idx for the definition
	def def_get_g_var_idx(self, d):
		return self.ns_get_g_var_idx(d["ns"])
	
	# Returns the actual parameters for a definition
	def def_get_ap(self, d):
		return d.get("ap", None)

	# Returns the index of the ap in the list of params,
	# returns -1 on error
	def get_index_ap(self, a, params):
		for pidx, p in enumerate(params):
			if p["name"] == a["value"]:
				return pidx
		return -1

	# Returns the formal parameters for a definition
	def def_get_fp(self, d):
		# check if there are parenthesis
		split = d["nm"].split('(')
		if len(split) == 1:
			return None

		# Take off the closing parenthesis
		fps = split[1].split(')')[0]
			
		# return the list of formal parameters
		return fps.split(',')

	def def_get_params_types(self, d):
		item = self.postfix_get_item(d)
		if not item:
			raise Exception("Item not found\n");
		
		p = self.item_get_parms(item)
				
		# returns a list of the type keys found in parmspec
		return [d["type"] for d in p]

	def def_get_params_values(self, d):
		item = self.postfix_get_item(d)
		if not item:
			raise Exception("Item not found\n");
		
		p = self.item_get_parms(item)
				
		# returns a list of the values found in parmspec
		return [d.get("value", None) for d in p]

	# Returns the name of the definition, does not trim any parenthesis
	def def_get_name_with_fp(self, d):
		return d["nm"].split(".")[1]
	
	############# Helper functions ####################

	#
	# Given a definition, returns a tuple that is the
	# (adm, collection, name)
	#
	def def_get_names(self, d):
		adm = d["ns"]
		coll, name = d["nm"].split('.')

		coll = cs.name_get_coll(coll)
		name = name.split('(')[0]
	
		return adm, coll, name	

	#
	# Returns a list of all of the files ending in .json in the passed directory.
	#
	def __find_json_files(self, path):
		json_files = []
		for file in os.listdir(path):
			if file.endswith(".json"):
				json_files.append(file)
		return json_files

	#
	# Loads all of the JSON files that are imported with the 'uses' construct,
	# and builds a dictionary of ADM_NAME : json_dict pairs.
	#
	# Prints an error message if a file can't be found or loaded.
	#
	def __build_uses_dict(self):
		uses = self.get_uses()
		if uses == []:
			return
		
		# XXX: we currently have to load every JSON file because 'uses' calls them by
	        # XXX- name, not filename. Should we switch to importing by filename?
		path = os.path.split(self.filename)[0]
		json_files = self.__find_json_files(path)
		all_dict = {}

		for jfile in json_files:
			try:
				r = Retriever(path+"/"+jfile, False)
				namespace = r.get_ns()
				all_dict[namespace.upper()] = r

			except Exception, e:
				pass

		# only return the ones that this JSON needs
		for name in uses:
			name = name.upper()
			if name in all_dict:
				print "\tLoading " + name + " for ", self.get_ns(), " ... [ DONE ]"
				self.uses[name] = all_dict[name]
			else:
				print ("[ ERROR ] Failed to load \"", name,
				       "\" used by JSON file, check to make sure it is formatted in accordance with AMA ADM")
				print "Issue my arise from objects that uses this ADM"

	#
	# Constructor, takes filename as input and loads JSON into
	# data dictionary if valid JSON.
        # load_uses is a boolean. True if the 'uses' construct should be loaded, False if not.
	# Raises exception if not valid JSON or if file cannot be found.
	#
	def __init__(self, jsonfile, load_uses):
		self.filename = None         # JSON file with the original contents
		self.data = None             # Dictionary of JSON loaded from <filename>
		self.uses = {}               # Dictionary of ADMs used by this ADM. Format: {'namespace':Retriever}

		if (not jsonutil.is_jsonFile(jsonfile)):
			raise Exception (jsonfile, " is not a valid JSON file\n")

		jfile = open(jsonfile, 'r')

		self.filename = jsonfile
		self.data = json.load(jfile)
		jfile.close()

		# Put self in the dict regardless
		self.uses[self.get_ns().upper()] = self

		if load_uses:
			self.__build_uses_dict()


################################## ARI CREATION FUNCTIONS ###########################

# 
# encode integers in cbor  
# 
def cbor_encode_int(val):
    convert = ("{:02x}".format(val))
    if val <= 23:
        return convert
    if val <= 0x0ff:
        return "18" + convert
    if val <= 0x0ffff:
        return "19" + convert    	
    if val <= 0x0ffffffff:
        return "1a" + convert    	
    if val <= 0x0ffffffffffffffff:
        return "1b" + convert

    raise Exception("value too big for CBOR unsigned number: {0!r}".format(val))

# 
# encode byteStrings in cbor  
#
def cbor_encode_byte(ari):
	length = len(ari)/2
	if length <= 15:
		return "4" + "{:01x}".format(length) + ari
	elif length <= 23: 
		return "5" + "{:01x}".format(length-16) + ari
	elif length <= 255:
		return "58" + "{:02x}".format(length) + ari
	else: 
		return "59" + "{:04x}".format(length) + ari

# 
# encode arrays in cbor
# XXX: unused
#
def cbor_encode_array(ac):
	length = len(ac)
	encode = ""
	
	if length <= 15:
		encode = "8" + "{:01x}".format(length)
	elif length <= 23:
		encode = "9" + "{:01x}".format(length-16)
	elif length <= 255:
		encode = "98" + "{:02x}".format(length)
	else:
		encode = "99" + "{:04x}".format(length)

	for a in ac:
		encode = encode + a

#
# Returns the CBOR-encoded nickname for the passed nickname and
# collection type
#
def cbor_encode_nickname(nn, coll):
	nickname = (nn*20) + cs.nn_type_enum(coll)
	return cbor_encode_int(nickname)

#
# Returns the CBOR-encoded ARI without the first two flag values
# cbor-encoded nickname + 41 + enumeration
#
def convert_ari_wo_flags(nn, coll, enum):
	cbor_nickname = cbor_encode_nickname(nn, coll)
	
	amp_ari = cbor_nickname + "41" +  "{:02x}".format(enum)
	
	return amp_ari
	
		
#
# Creates and returns a string that is the ari for the data object
# nn is the nickname
# coll is the collection type (EDD, VAR, RPT, etc.)
# enum is the enumaration of the object in the json
# data is the data object
# encoded in CBOR as byte string
#
def convert_ari((nn, coll, enum, data)):
	amp_ari = ""

	# since there will be no issuers or tags present and all the aris are compressed 
 	# only have to worry about if it is parameterized
	# XXX: not sure if this conditional is robust (is it correct to only use c flag for
	# these conditions? (ex: rptt also has definition field. Can a macro have an empty
	# definition list?)
	flag = "8"  
	if data.has_key("parmspec") or (coll is cs.MACRO and data.has_key("definition")):
		flag = "c"

	amp_ari = flag + cs.ari_type_enum(coll) + convert_ari_wo_flags(nn, coll, enum)

	return amp_ari


######################## GENERAL FUNCTIONS ####################

# XXX: when refactoring hard-coded JSON keys out of the generator code, these
# XXX- functions could be updated and put into the retriever class.

#
# Formats and returns a string for the ari
# name is the value returned from a call to initialize_names, coll is the
# collection the item belongs to (cs.[EDD|VAR|...]), item is the item to
# make the ari for i_name is the name of the item
#
def make_ari_name_from_str(name, coll, i_name):
	name = name.replace("/", "_")
	template = "{0}_{1}_{2}"
	return template.format(name.upper(), cs.get_sname(coll).upper(), i_name.upper())

#
# Formats and returns a string for the ari
# name is the value returned from a call to initialize_names, coll is the
# collection the item belongs to (VAR, EDD, etc), item is the item to make
# the ari for
# Assumes that the passed item has a valid "name" field
#
def make_ari_name(name, coll, item):
	return make_ari_name_from_str(name, coll, item["name"])

#
# Makes and returns the amp type string for the passed item
# t_name is the name of the type
#
def make_amp_type_name_from_str(t_name):
	return "AMP_TYPE_{}".format(t_name.upper())

#
# Makes and returns the amp type string for the passed item
# Assumes that the item has a valid "type" field
#
def make_amp_type_name(item):
	return make_amp_type_name_from_str(item["type"])

#
# Makes and returns the adm enum type string for the passed
# item. name is the name of the item
#
def make_enum_name_from_str(name):
	return "ADM_ENUM_{}".format(name.upper())

#
# Constructs the directory structure for the generated file
# (<outpath>/<dir_name>/) if it doesn't already exist, and
# creates and opens the filename for this generated file
# (<outpath>/<dir_name>/<name><suffix>. 
#
# Returns a tuple of (filename, file_descriptor) on success,
# (None, None) on error. 
#
# file_descriptor should be closed by the caller. 
#
def initialize_file(outpath, dir_name, name, suffix):
	# Make the shared dir, only want to allow the 'directory exists' error
	if dir_name:
		try:
			os.mkdir(outpath + "/" + dir_name + "/")
		except OSError as ose:
			if(not ose.errno == errno.EEXIST):
				print "[ Error ] Failed to create subdirectory in ", outpath
				print ose
				return None, None

		filename = outpath + "/" + dir_name + "/" + name + suffix
	else:
		filename = outpath + "/" + name + suffix
	
	try:
		fd = open(filename, "w")
	except IOError, e:
		print "[ Error ] Failed to open ", filename, " for writing."
		print e
		return None, None
	
	return filename, fd


