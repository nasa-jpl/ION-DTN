use amp_core;


-- view for table templates 

CREATE OR REPLACE VIEW `vw_tblt_actual` AS
    SELECT 
        obj_metadata.obj_metadata_id,
        obj_name,
        namespace_id,
        obj_actual_definition_id,
        tnvc_id,
        use_desc
    FROM
        obj_metadata
            INNER JOIN
        (SELECT 
            obj_actual_definition.obj_actual_definition_id,
                obj_actual_definition.obj_metadata_id,
                tnvc_id,
                use_desc
        FROM
            amp_core.obj_actual_definition
        JOIN amp_core.table_template_actual_definition ON obj_actual_definition.obj_actual_definition_id = table_template_actual_definition.obj_actual_definition_id) AS view1 ON 
        view1.obj_metadata_id = obj_metadata.obj_metadata_id;