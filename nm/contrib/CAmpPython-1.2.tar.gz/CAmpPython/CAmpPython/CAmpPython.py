#!/usr/bin/env python

# JHU/APL
# Description: Entrypoint into the CAmpPython program. Calls generators to
# create various files (i.e., C code for NASA ION) from the JSON representation
# of different ADMs for use by protocols in DTN
#
#   YYYY/MM/DD	    AUTHOR	   DESCRIPTION
#   ----------	  ------------	 ---------------------------------------------
#   2017-08-10	  David		 First implementation
#   2017-08-15	  Evana		 Clean up
#   2017-08-17	  David		 fixed mid converter
#   2017-08-23	  David		 Started convertion to command line tool
#   2017-11-01	  Sarah		 Documentation and minor fixups
##################################################################### 


import os
import argparse
import json
import re

# Import all generators
from generators import create_gen_h
from generators import create_agent_c
from generators import create_mgr_c
from generators import create_impl_h
from generators import create_impl_c
from generators import create_mysql
from generators import create_ace

from generators.lib.common import campsettings
from generators.lib.common.camputil import Retriever
from util import name_registry as NR

#
# Sets up the format of command line arguments for CAmpPython,
# validates and returns arguments input on the command line
#
# Return value is a tuple (args, jsonfilename)
#
def handle_command_line_arguments():
	p = argparse.ArgumentParser(description = 'C code generator for Asychronous management protocols')

	p.add_argument('-o', '--out',         help="The ouput directory",                          default="./")
	p.add_argument('-c', '--scrapeC',     help="Previously generated c file to be scraped",    default=None)
	p.add_argument('-s', '--scrapeH',     help="Previously generated h file to be scraped",    default=None)
	
	p.add_argument('-n', '--nickname',    help="The integer nickname to use for this file",    default=-1, type=int)
	p.add_argument('-u', '--update-nn',   help="If this flag is set, nickname will be updated in name registry. Requires Root", action='store_true')
	
	p.add_argument('json',                help="JSON file to use for file generation")
	p.add_argument('--only-sql', help="Set this flag to only produce the SQL files", action='store_true')
	p.add_argument('--only-ch', help="Set this flag to only produce the .c and .h files", action='store_true')
	p.add_argument('--only-ace', help="Set this flag to only produce the ACE files", action='store_true')

	args = p.parse_args()

	if args.only_sql and args.only_ace:
		print "Cannot have multiple --only-* flags. No files will be generated."
	elif args.only_sql and args.only_ch:
		print "Cannot have multiple --only-* flags. No files will be generated."
	elif args.only_ch and args.only_ace:
		print "Cannot have multiple --only-* flags. No files will be generated."

	return args

#
# Makes the output directory if it doesn't already exist
# d_name is the path to the output directory
#
def set_up_outputdir(d_name):
	if(not os.path.isdir(d_name)):
		try:
			os.makedirs(d_name)
		except OSError, e:
			print "[ Error ] Failed to make output directory\n",
			print e
			raise

	
#
# Main function of CAmpPython
#
# Calls helper functions to initialize settings, read command line arguments,
# parse the input JSON file, and generate files
#
def main():
	try:
		# Validate command line arguments, set up output dir, and load JSON
		# ADM into the Retriever. Handle any nickname discrepancies/updates.
		args = handle_command_line_arguments()

		if (not os.path.exists(args.json)):
		    raise Exception("Passed JSON file does not exist ({})".format(args.json))
		
		campsettings.init()

		set_up_outputdir(args.out)
		passed_nn = args.nickname

		print "\nLoading ", args.json, " ... "
		retriever = Retriever(args.json, True)

		nn = NR.handle_nickname(retriever.get_ns(), passed_nn, args.update_nn)
		
		print "[ DONE ]\n"
		
	except Exception, e:
		print "[ ERROR ] ", e
		return -1

	# Call each generator to generate files for the JSON ADM
	print "Generating files ..."

	if not args.only_sql and not args.only_ace:
		create_impl_h.create(retriever, args.out, args.scrapeH)
		create_impl_c.create(retriever, args.out, args.scrapeC)
		create_gen_h.create(retriever, args.out, nn)
		create_mgr_c.create(retriever, args.out)
		create_agent_c.create(retriever, args.out)
		
	if not args.only_sql and not args.only_ch:
		create_ace.create(retriever, args.out, nn)
		
	if not args.only_ch and not args.only_ace:
		create_mysql.create(retriever, args.out, nn)

	
	print "[ End of CAmpPython Execution ]\n"

	


if __name__ == '__main__':
	main()	
