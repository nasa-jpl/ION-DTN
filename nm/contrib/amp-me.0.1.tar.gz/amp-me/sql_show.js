#!/usr/bin/env node
import { CBOR } from "./lib/shared/cbor.js";
import * as AMP from "./lib/amp-sql.js";
//import yargsInteractive from "yargs-interactive";
import yargs from "yargs";


await main();

async function main() {
    var cfg = yargs.usage( './sql_show.js --type $TYPE --id $SQL_ID')
        .option('type', {
            alias: 't',
            type: 'string', // or enum?
            default: 'msgs',
            description: 'Type of data to query, ie: msgs, msg, ari, etc.'
        })
        .option('id', {
            type: 'number',
            'description': 'ID associated with this data type to query.  Omit to query all matching records'
        })
    // TODO: Other filtering options (ie: state and incoming/outgoing for msgs
    // verbose flag
        .argv;
    
    // TODO: If providing SQL functionality in this test, initialize DB here, AND a transaction

    await AMP.Registry.getInstance("lib/shared/adms");

    var db = await AMP.connectDb(); // todo; cfg options
    console.log("Connection established".green);

    AMP.trace.start();

    var obj;
    
    switch(cfg.type) {
    case 'msgs':
        obj = new AMP.MessageGroup();
        break;
    default:
        throw new Error(cfg.type + " type not currently supported by this script");
    }

    await obj.fromSql(cfg.id);

    console.log("Loaded");
    AMP.trace.save();

    if (obj.toJSON) {
        console.log("JSON: ", JSON.stringify(obj.toJSON(), null, 2) );

    }
    if (obj.toCbor) {
        console.log("CBOR: 0x", obj.toCbor(new CBOR()).toString())
    } else { console.log(obj.constructor.name + " does not support to cbor"); }

    //console.log("CBOR: " + obj.toCbor() );
    if (obj.toUri) {
        console.log("URI: ", obj.toUri() );
    }
    
    
    db.end();
}
