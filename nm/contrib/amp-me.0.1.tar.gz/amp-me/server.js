#!/usr/bin/env node

import express from "express";
import mysql from "mysql";
import fetch from "node-fetch";
import yargs from "yargs";

const app = express();

var cfg = yargs.usage( './server.js [--port 8080]')
        .option('port', {
            alias: 'p',
            type: 'number',
            default: 3000,
            description: 'Server port. Interface will be accessible at http://localhost:port'
        })
        .option('nmrest', {
            type: 'string',
            'description': 'URI for ION NM Mgr REST API (used as a pass-through to avoid cross-domain security issues)',
            default: "http://localhost:8089/"
        })
    .option('sql-user', {
            alias: 'u',
            type: 'string',
            default: 'amp',
            description: 'MySQL Username'
        })
    .option('sql-pass', {
            type: 'string',
            default: 'amp',
            description: 'MySQL Password'
        })
    .option('sql-db', {
            alias: 'd',
            type: 'string',
            default: 'amp_core',
            description: 'MySQL Datbase'
    })
    .option('sql-host', {
            alias: 'h',
            type: 'string',
            default: 'localhost',
            description: 'MySQL Host'
        })
    .argv;



console.log("Initializing NM UI at http://localhost:"+cfg.port);

// Info page
app.get('/version', (req, res) => res.send('AMP UI SQL Interface v0.0'))

// Serve static site
app.use(express.static('htdocs'))
app.use('/lib/shared', express.static('lib/shared'));

// Initialize Database
var db = createDb(cfg.user,cfg.pass,cfg.db,cfg.host); // TODO: Configurable options


app.get('/api/agents', function(req,res) {
    // TODO: Match MGR REST AI
    // TODO: Make routing path configurable, use routing file?
    // TODO: For simple queries, we can consolidate this with a wrapper, ie:
    //   app_query('agents','SELECT * FROM registered_agents');
    db.query('SELECT * FROM registered_agents', function (error, results, fields) {
        if (error) {
            res.send(error); // TODO/Verify
        } else {
            res.send(results);
        }
    });
    
});

// Note: Sending messages will use PUT type, which will use a seperate handler, with all being the fallback (for GET and POST)
app.all('/api/msgs', function(req,res) {
    var type = req.param('type');
    var where = [];
    
    // Base Query: Only show entries in the ready state (other options will be added later)
    if (type == 'incoming' || type == 'outgoing') {
        where.push('msgs.is_outgoing = ' + ((type=='outgoing') ? '1' : '0'));
    }
    var agents_query = "SELECT GROUP_CONCAT(a.agent_id_string) FROM vw_message_group_agents a WHERE a.group_id=msgs.group_id";
    var query = `SELECT msgs.*,ms.name,ms.description, (${agents_query}) AS agent FROM message_group msgs`;
    query += ' LEFT JOIN enum_message_group_states ms ON ms.state_id=msgs.state_id ';
    if (where.length > 0) {
        query += ' WHERE ' + where.join(' AND ');
    }
    w2ui_send_grid(req,res,query);

});
app.all('/api/logs', function(req,res) { // NM Mgr SQL Debug Logs
    
    var query = `SELECT * FROM nm_mgr_log ORDER BY id DESC`;
    w2ui_send_grid(req,res,query);

});

app.get('/nm/*', function(req,res) {
//    res.send('Got ' + req.route.path + ', original: ' + req.originalUrl );
    fetch(cfg.nmrest + req.originalUrl).then(response => response.json()).then(data => {
        res.send(data);
    }).catch((error) => { res.send(error); });
});

app.listen(cfg.port, () => console.log(`Example app listening at http://localhost:${cfg.port}`))

function createDb(user='amp',pass='amp',db='amp_core',host='localhost') {
    var connection = mysql.createConnection({
        host     : host,
        user     : user,
        password : pass,
        database : db
    });
 
    connection.connect();
    return connection;
}

// Given a W2UI Grid Request and base query, generate and send a resposne with the appropriate pagination
//  Note: Caller is responsible for search and sort requests
function w2ui_send_grid(req, res, query, params=[])
{
    if (req.limit) {
        query += " LIMIT ?";
        params.push(req.limit);
    }
    if (req.offset) {
        query += " OFFSET ?";
        params.push(req.offset);
    }
    db.query(query, params, function(error, results, fields) {
        if (error) {
            res.send(error);
        } else {
            res.send({
                records: results,
                // page? Why does w2ui give input in limit/offset but take result as page?
                // total: If this is needed, requires running query a second time with COUNT(*)
            });
        }
    });
}
