This configuration sets up bibect for data stream with label '12' from node 1 to 2
and '21' from node 2 to 1.

Due to limitation of BIBE which does not performance bundle fragmentation, using 
BIBE over UDPCL requires that the bundle be smaller than 64KBytes. 

To test this one can use bptrace command to send and bpsink to receive. For example:

In node 1, to send:

bptrace ipn:1.1 ipn:2.1 dtn:none 100 0.1.0.0.0.12 @testfile-05KB

or 

bptrace ipn:1.1 ipn:2.2 dtn:none 100 0.1.0.0.0.12 "message from node 1 to node 2!"

In node 2, to receive:

bpsink ipn:2.1

