# JHU/APL
# Description: Creates the h file for the implementation version of the adm
# Modification History:
#   YYYY-MM-DD    AUTHOR         DESCRIPTION
#   ----------    ------------   ---------------------------------------------
#   2017-08-09    David          First implementation
#   2017-11-01    Sarah          Making long strings easier to parse
#   2017-11-20    Evana		 Updates
#	2017-12-28    David 			Metadata is in constants now
#   2018-06-27   David 			Changed mids to aris	
#
##################################################################### 

import re

from lib import campch
from lib.campch_roundtrip import H_Scraper
from lib.common import camputil as cu


#
# Writes the #defines and ifdefs to the file
# new_h is an open file descriptor to write to
# name is the name returned from get_adm_names()
#
def write_defines(new_h, name):
	n_upper = name.upper()
	define_str = (
		"#ifndef {0}_IMPL_H_\n"
		"#define {0}_IMPL_H_\n\n")
	new_h.write(define_str.format(n_upper))

#
# Writes the #includes for the file
# new_h is an open file descriptor to write to
#
def write_includes(new_h):
	files = ["shared/utils/utils.h", "shared/primitives/ctrl.h",
		 "shared/primitives/table.h", "shared/primitives/tnv.h"]
	
	new_h.write(campch.make_includes(files))

#
# Writes the metadata functions to the passed new_h file
# name is the name returned from get_adm_names()
#
def write_metadata_functions(new_h, name, metadata):
	new_h.write("\n/* Metadata Functions */\n")
	for i in metadata:
		try:
			_,_,signature = campch.make_meta_function(name, i)
			new_h.write(signature + ";\n")
		except KeyError, e:
			print "[ Error ] Badly formatted metadata. Key not found:"
			print e
			raise

#
# Writes the constant functions to the passed new_h file
# name is the name returned from get_adm_names()
#
def write_constant_functions(new_h, name, constants):
	new_h.write("\n/* Constant Functions */\n")
	for i in constants:
		try:
			_,_,signature = campch.make_constant_function(name, i)
			new_h.write(signature + ";\n")
		except KeyError, e:
			print "[ Error ] Badly formatted constant. Key not found:"
			print e
			raise
		
#
# Writes the edd collect functions to the passed file, new_h
# name is the value returned from get_adm_names
# edds is a list of the edds to include
#
def write_collect_functions(new_h, name, edds):
	new_h.write("\n/* Collect Functions */\n")
	for i in edds:
		try:
			_,_,signature = campch.make_collect_function(name, i)
			new_h.write(signature + ";\n")
		except KeyError, e:
			print "[ Error ] Badly formatted edd. Key not found:"
			print e
			raise

#
# Writes the control functions to the passed file, new_h
# name is the value returned from get_adm_names
# controls is a list of the controls to include
#
def write_control_functions(new_h, name, controls):
	new_h.write("\n\n/* Control Functions */\n")
	for i in controls:
		try:
			_,_,signature = campch.make_control_function(name, i)
			new_h.write(signature + ";\n")
		except KeyError, e:
			print "[ Error ] Badly formatted control. Key not found:"
			print e
			raise

#
# Writes the operator functions to the passed file, new_h
# name is the value returned from get_adm_names
# ops is a list of operators to include
#
def write_operator_functions(new_h, name, ops):
	new_h.write("\n\n/* OP Functions */\n")
	for i in ops:
		try:
			_,_,signature = campch.make_operator_function(name, i)
			new_h.write(signature + ";\n")
		except KeyError, e:
			print "[ Error ] Badly formatted operator. Key not found:"
			print e
			raise

#
# Writes the table functions to the passed file, new_h
# name is the value returned from get_adm_names
# tables is a list of tables to include
#
def write_table_functions(new_h, name, tables):
	new_h.write("\n\n/* Table Build Functions */\n")
	for i in tables:
		try:
			_,_,signature = campch.make_table_function(name, i)
			new_h.write(signature + ";\n")
		except KeyError, e:
			print "[ Error ] Badly formatted table. Key not found:"
			print e
			raise
		
# 
# Main function of this file, which calls helper functions to orchestrate
# the creation of the generated file
#
# retriever: the Retriever class object for this JSON
# outpath: the output directory
# scrape_file: the name of the file to be scraped for roundtripping
#
def create(retriever, outpath, scrape_file):
	scraper = H_Scraper(scrape_file)

	try:
		name,ns   = retriever.get_adm_names()
		metadata = retriever.get_metadata()
	except KeyError, e:
		print "[ Error ] JSON does not include valid metadata"
		print e
		return

	filename, new_h = cu.initialize_file(outpath, "agent", name, "_impl.h")
	if not new_h:
		return
	
	print "Working on ", filename,
	
	campch.write_h_file_header(new_h, filename)
	write_defines(new_h, name)

	scraper.write_custom_includes(new_h)
	write_includes(new_h)
	
	scraper.write_custom_type_enums(new_h)

	# init agent function
	# TODO: not sure this is what we actually want here (results in "name_adm_init.." for all current JSONs
	new_h.write("void {}_adm_init_agent();\n\n\n".format(re.sub('\s','_', metadata[0].get("name", ""))))

	# Write this to divide up the file
	new_h.write(campch.make_formatted_comment_header("Retrieval Functions", True, True))
	
	# Write any custom functions found
	scraper.write_custom_functions(new_h)

	# The setup and clean up functions
	new_h.write("void "+ns+"_setup();\n")
	new_h.write("void "+ns+"_cleanup();\n\n")

	try: 
		write_metadata_functions(new_h,  ns, metadata)
		write_constant_functions(new_h,  ns, retriever.get_constants())
		write_collect_functions( new_h,  ns, retriever.get_edds())
		write_control_functions( new_h,  ns, retriever.get_controls())
		write_operator_functions( new_h, ns, retriever.get_operators())
		write_table_functions(new_h, ns, retriever.get_tables())

		new_h.write("\n#endif //{0}_IMPL_H_\n".format(name.upper()))	
	except KeyError, e:
		return
	finally:
		new_h.close()

	print "\t[ DONE ]"
