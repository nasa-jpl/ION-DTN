# JHU/APL
# Description: This creates the h file for the public portions of an adm
# Modification History:
# YYYY-MM-DD  AUTHOR     DESCRIPTION
# ----------  ---------- -----------------------------
# 2017-08-10  Evana       
#	      David      cleaning up
#	      Evana      fix formatting
# 2017-08-14  Evana      cleaning up
# 2017-08-15  Evana	 fix formatting
# 2017-08-15  David	 Added AMP aris
# 2017-08-17  David      fixed ariconverter
# 2017-08-22  Evana      cleaning up
# 2017-11-15  Sarah      error handling and cleaning up
# 2017-12-27  David  change constants to require types 
# 2017-12-28     David 			Metadata is in constants now
#   2018-06-27   David 			Changed mids to aris	
########################################################


from lib import campch
from lib.common import camputil as cu
from lib.common.camputil import Retriever
from lib.common import campsettings as cs

nickname = -1

#
# Writes the #defines for the generated file
# h_file is an open file descriptor to write to
# name and ns are the values returned from get_adm_names
#
def write_defines(h_file, name, ns):
	name_upper = name.upper();
	ns_upper = ns.upper();
	defines_str = (
		"\n#ifndef {0}_H_"
		"\n#define {0}_H_"
		"\n#define _HAVE_{1}_ADM_"
		"\n#ifdef _HAVE_{1}_ADM_"
		"\n")
	h_file.write(defines_str.format(name_upper, ns_upper))

#
# Writes the includes statements for this generated file
# h_file is an open file descriptor to write to
# ns is the ns returned from get_adm_names()
#
def write_includes(h_file, ns):
	files = ["shared/utils/nm_types.h", "shared/adm/adm.h" ]

	h_file.write(campch.make_includes(files))
	
#
# Writes the ADM template documentation for this generated file
# h_file is an open file descriptor to write to
# name is the colon-deliminated name returned from get_adm_names()
#
def write_adm_template_documentation(h_file, name):
	header_str = campch.make_formatted_comment_header("ADM TEMPLATE DOCUMENTATION", True, False)
	documentation_str = (
		"{} *"
		"\n * ADM ROOT STRING:{}"
		"\n */"
		"\n")
	h_file.write(documentation_str.format(header_str, name))

#
# Writes the agent nickname #defines enum to the file
#
def write_agent_nickname_definitions(h_file, ns, nn):
	enum_name = cu.make_enum_name_from_str(ns)
	h_file.write("#define {0} {1}".format(enum_name, nn))
	header_str = campch.make_formatted_comment_header("AGENT NICKNAME DEFINITIONS", True, True)
	h_file.write(header_str)

#
# Function for formatting the description field in the tables.
# Wraps the description nicely and fills other cells in the
# row with empty spaces. Returns the string result
#
# descr is the string to format as a description.
# desc_col_sz is the size of the description column to fit to
# col_sizes_before is an array of the sizes for the columns to the left of the description column
# col_sizes_after is an array of the sizes for the columns to the right of the description column
# 
def format_table_description(descr, desc_col_sz, col_sizes_before, col_sizes_after):
	result = []
	descr = descr.strip()

	# make the format for the description based on the size of the description column
	desc_fmt = '%-' + str(desc_col_sz) + '.' + str(desc_col_sz) + 's'
	
	# create string that will fill columns to the left of the description column with white space
	start_next_row = " * |"
	for col_sz in col_sizes_before:
		start_next_row = (start_next_row + (" " * col_sz) + "|") 
		
	# create string that will fill columns to the right of the description column with white space
	fill_this_row = "|"
	for col_sz in col_sizes_after:
		fill_this_row = (fill_this_row + (" " * col_sz) + "|")
	fill_this_row = fill_this_row + "\n"

	# split the description because descriptions may contain new lines
	lines = descr.splitlines()
	num_lines = len(lines)

	# For each line of the description, cut it to the right length,
	# and fill the columns before and after with empty space
	for line_idx in range(0, num_lines):
		
		# This to wrap nicely inside the column
		line = lines[line_idx].strip()
		
		while len(line) > desc_col_sz:
			left, right = line[:desc_col_sz], line[desc_col_sz:]
			
			result.append(desc_fmt % (left))
			result.append(fill_this_row)
			result.append(start_next_row)
			line = right

		result.append(desc_fmt % (line))
		
		# If there are still lines to write, fill the row and start a new one
		if(line_idx < num_lines-1):
			result.append(fill_this_row)
			result.append(start_next_row)
			
	return "".join(result)

#
# Formats and returns a table entry (with following divider line) with
# the passed name, ari, description, and type (ttype)
#
# XXX: ari isn't currently part of the table. Keeping as a parameter to this
# function because we might want to include it again in the future
#
# Centered is True if the entries should be centered in their columns, False
# if not.
#
# XXX: should update this function to be a general helper function that operates independent
# XXX- of the columns present (pass a list of values and sizes for columns, it creates the table)
# XXX- This would be straightforward, except the description column is treated differently for wrapping.
#
def format_table_entry(centered, name, ari, desc, ttype, value):

	columns = [name, desc, ttype]
	col_sizes = [21, 38, 7]
	if value:
		columns.append(value)
		col_sizes.append(24)

	desc_idx = 1 # index of the description column, since it needs to be treated slightly differently
		
	entry_row = " * |"
	divider   = " * +"
	for idx,item in enumerate(columns):
		col_sz = col_sizes[idx]
		item_len = len(item)

		# if it's bigger than the column, we need to truncate it
		if(item_len > col_sz):
			entry = item[:col_sz] 

			# Need to treat description differently unfortunately
			if (idx == desc_idx):
				entry = format_table_description(item, col_sz, col_sizes[:desc_idx], col_sizes[desc_idx+1:])

		# if the caller wanted it centered, calculate and add the whitespace for that
		elif centered:
			total_ws_sz = col_sz - item_len
			half_ws = (" " * int(total_ws_sz / 2))

			entry = half_ws + item + " " + half_ws

		# smaller than column and not centered
		else:
			trailing_ws = (" " * (col_sz - item_len))
			entry = item + trailing_ws

		entry_row = entry_row + entry + "|"
		divider = divider + ('-' * col_sz) + "+"
		
	entry_row = entry_row + "\n"
	divider   = divider   + "\n"		
		
	return entry_row + divider

#
# Calls helper functions to write the header for a definition table to the
# passed fd with the passed definitions string in the center area
# results in:
# ```
#  * +---------------------+
#  * |  definitions_str    +
#  * +---------------------+
#  * +----+-----------+----+
#  * |NAME|DESCRIPTION|TYPE|
#  * +----+-----------+----+
# ```
# but spaced to standard width for this file (defined in campch.py)
#
# If value_present is True, adds the VALUE column on the right of the TYPE column
#
def write_definition_table_header(fd, definitions_str, value_present):
	
	fd.write(campch.make_formatted_comment_header(definitions_str, True, False))

	if value_present:
		fd.write(format_table_entry(True, "NAME", "", "DESCRIPTION", "TYPE", "VALUE"))
	else:
		fd.write(format_table_entry(True, "NAME", "", "DESCRIPTION", "TYPE", ""))

#
# Writes the metadata definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names
# metadata is a list of the metadata to include
#
def write_metadata_definitions(h_file, ns, metadata):
	table   = ""  # the commented table of all metadata (string)
	defines = ""  # the #defines and for all metadata (string)

	# Create the strings for the #defines and preceeding commented table
	for idx, i in enumerate(metadata):
		try:
			hex_str = format(idx, '#04x')
			ari     = cu.convert_ari((nickname, cs.META, idx, i))
			ari_str = cu.make_ari_name(ns, cs.META, i)

			table   = table   + format_table_entry(False, i["name"], ari, i["description"], i["type"], i["value"])

			defines = defines + "// \"{}\"\n".format(i["name"])			
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
			
		except KeyError, e:
			print "[ Error ] Badly formatted metadata. Key not found: "
			print e
			raise

	# Write everything to file
	write_definition_table_header(h_file, ns.upper()+" META-DATA DEFINITIONS", True)
	h_file.write(table   + " */\n")
	h_file.write(defines + "\n")

#
# Writes the edd definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names
# edds is a list of edds to include
#
def write_edd_definitions(h_file, ns, edds):
	table   = ""  # the commented table of all edds (string)
	defines = ""  # the #defines and for all edds (string)

	# Create the strings for the #defines and preceeding commented table
	for idx,i in enumerate(edds):
		try:
			hex_str = format(idx, '#04x')
			ari     = cu.convert_ari((nickname, cs.EDD, idx, i))
			ari_str = cu.make_ari_name(ns, cs.EDD, i)
			
			table   = table   + format_table_entry(False, i["name"], ari, i["description"], i["type"], "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted EDD. Key not found: "
			print e
			raise

	# Write everything to file
	write_definition_table_header(h_file, ns.upper()+" EXTERNALLY DEFINED DATA DEFINITIONS", False)
	h_file.write(table   + " */\n")
	h_file.write(defines + "\n")

#
# Writes the variable definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names
# variables is a list of variables to include
#
def write_variable_definitions(h_file, ns, variables):
	table   = ""  # the commented table of all variables (string)
	defines = ""  # the #defines and for all variables (string)

	# Create the strings for the #defines and preceeding commented table
	for idx,i in enumerate(variables):
		try:
			hex_str = format(idx, '#04x')
			ari     = cu.convert_ari((nickname, cs.VAR, idx, i))
			ari_str = cu.make_ari_name(ns, cs.VAR, i)
			
			table   = table   + format_table_entry(False, i["name"], ari, i["description"], i["type"], "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted variable. Key not found: "
			print e
			raise

	# Write everything to file
	write_definition_table_header(h_file, ns.upper()+" VARIABLE DEFINITIONS", False)
	h_file.write(table + " */\n")
	h_file.write(defines + "\n")

#
# Writes the report template definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names()
# templates is a list of report templates to include
#
def write_rpt_definitions(h_file, ns, templates):
	table   = ""  # the commented table of all reports (string)
	defines = ""  # the #defines and for all reports (string)

	# Create the strings for the #defines and preceeding commented table
	for idx,i in enumerate(templates):
		try:
			hex_str = format(idx, '#04x')
			ari     = cu.convert_ari((nickname, cs.RPTT, idx, i))
			ari_str = cu.make_ari_name(ns, cs.RPTT, i)
			
			table   = table   + format_table_entry(False, i["name"], ari, i["description"], "TNVC", "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted report-template. Key not found: "
			print e
			raise

	# Write everything to file
	write_definition_table_header(h_file, ns.upper()+" REPORT DEFINITIONS", False)
	h_file.write(table   + " */\n")
	h_file.write(defines + "\n")

#
# Writes the table definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names()
# tbls is a list of tabels to include
#
def write_tbl_definitions(h_file, ns, tbls):
	table   = ""  # the commented table of all tables (string)
	defines = ""  # the #defines and for all tables (string)

	# Create the strings for the #defines and preceeding commented table
	for idx, i in enumerate(tbls):
		try:
			hex_str = format(idx, '#04x')
			ari     = cu.convert_ari((nickname, cs.TBLT, idx, i))
			ari_str = cu.make_ari_name(ns, cs.TBLT, i)
	
			table   = table   + format_table_entry(False, i["name"], ari, i["description"], "", "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted table. Key not found: "
			print e
			raise

	# Write everything to file
	write_definition_table_header(h_file, ns.upper()+" TABLE DEFINITIONS", False)
	h_file.write(table + " */\n")
	h_file.write(defines + "\n")
	
#
# Writes the control definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names()
# controls is a list of controls to include
#
def write_ctrl_definitions(h_file, ns, controls):
	table   = ""  # the commented table of all controls (string)
	defines = ""  # the #defines and for all controls (string)

	# Create the strings for the #defines and preceeding commented table
	for idx,i in enumerate(controls):
		try:
			hex_str = format(idx, '#04x')
			ari     = cu.convert_ari((nickname, cs.CTRL, idx, i))
			ari_str = cu.make_ari_name(ns, cs.CTRL, i)	

			table   = table   + format_table_entry(False, i["name"], ari, i["description"], "", "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted control. Key not found: "
			print e
			raise

	# write everything to file
	write_definition_table_header(h_file, ns.upper()+" CONTROL DEFINITIONS", False)
	h_file.write(table + " */\n")
	h_file.write(defines + "\n")

#
# Writes the constants definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names()
# constants is a list of constants to include
#
def write_const_definitions(h_file, ns, constants):
	table   = ""  # the commented table of all controls (string)
	defines = ""  # the #defines and for all controls (string)

	# Create the strings for the #defines and preceeding commented table
	for idx,i in enumerate(constants):
		try:
			hex_str = format(idx, '#04x')
			ari     = cu.convert_ari((nickname, cs.CONST, idx, i))
			ari_str = cu.make_ari_name(ns, cs.CONST, i)
			
			table   = table   + format_table_entry(False, i["name"], ari, i["description"], i["type"], i["value"])
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted constant. Key not found: "
			print e
			raise

	# write everything to file
	write_definition_table_header(h_file, ns.upper() + " CONSTANT DEFINITIONS", True)
	h_file.write(table   + " */\n")
	h_file.write(defines + "\n")

#
# Writes the operator definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names()
# operators is a list of operators to include
#
def write_op_definitions(h_file, ns, operators):
	table   = ""  # the commented table of all ops (string)
	defines = ""  # the #defines and for all ops (string)

	# Create the strings for the #defines and preceeding commented table
	for idx,i in enumerate(operators):
		try:
			hex_str = format(idx, '#04x')
			ari     = cu.convert_ari((nickname, cs.OP, idx, i))
			ari_str = cu.make_ari_name(ns,  cs.OP, i)
						      
			table   = table   + format_table_entry(False, i["name"], ari, i["description"], i["result-type"], "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted operator. Key not found: "
			print e
			raise

	# write everything to file
	write_definition_table_header(h_file, ns.upper()+" OPERATOR DEFINITIONS", False)
	h_file.write(table   + " */\n")
	h_file.write(defines + "\n")
	
#
# Writes the macro definitions and #defines to the file
# h_file is an open file descriptor to write to
# name and ns are the values returned by get_adm_names()
# macros is a list of macros to include
#
def write_macro_definitions(h_file, ns, macros):
	table   = ""  # the commented table of all macros (string)
	defines = ""  # the #defines and for all macros (string)

	# Create the strings for the #defines and preceeding commented table
	for idx,i in enumerate(macros):
		try:
			hex_str = format(idx, '#04x')
			ari     = cu.convert_ari((nickname, cs.MACRO, idx, i))
			ari_str = cu.make_ari_name(ns, cs.MACRO, i)
			
			table   = table   + format_table_entry(False, i["name"], ari, i["description"], "mc", "")
			defines = defines + "#define {0} {1}\n".format(ari_str, hex_str)
		except KeyError, e:
			print "[ Error ] Badly formatted macro. Key not found: "
			print e
			raise

	# write everything to file
	write_definition_table_header(h_file, ns.upper()+" MACRO DEFINITIONS", False)
	h_file.write(table   + " */\n")
	h_file.write(defines + "\n")

#
# Writes the initialization functions' forward declars to the file
# h_file is an open file descriptor to write to
# name is the name returned by get_adm_names()
#
def write_initialization_functions(h_file, name):
	body = 	(
		"/* Initialization functions. */\n"
		"void {0}_init();\n"
		).format(name.lower())
	
	decl_fun_template = "void "+name.lower()+"_init_{0}();\n"

	# XXX: consider changing this to only colls in the data; but would have to change
	# EVERYWHERE to only be the colls in the data (_agent.c, _mgr.c also)
	for coll in [cs.META, cs.CONST, cs.EDD, cs.OP, cs.VAR, cs.CTRL, cs.MACRO, cs.RPTT, cs.TBLT]:
		body = body + decl_fun_template.format(cs.get_sname(coll).lower())

	h_file.write(body.format(name))

#
# Writes the end ifs for at the end of the file
# h_file is an open file desciptor to write to
# name and ns are the names returned by get_adm_names()
#
def write_endifs(h_file, name, ns):
	endifs_str = (
		"#endif /* _HAVE_{0}_ADM_ */\n"
		"#endif //{1}_H_")
	h_file.write(endifs_str.format(ns.upper(), name.upper()))
	
#
# Main function of this file, which calls helper funtions to
# orchestrate the creation of the generated file
#
# data: the dictionary from the parsed JSON file
# outpath: the output directory
#
def create(retriever, outpath, nn):
	global nickname
	nickname = nn

	if nn < 0:
		print "[ Error ] Cannot create ", filename, ": ADM not included in NAME REGISTRY"
		return 
	
	try:
		name, ns = retriever.get_adm_names()
		namespace = retriever.get_ns()
	except KeyError, e:
		print "[ Error ] JSON does not include valid metadata"
		print e
		return

	filename, h_file = cu.initialize_file(outpath, "shared", name, ".h")
	if not h_file:
		return

	print "Working on ", filename, 
	
	campch.write_h_file_header(h_file, filename)

	write_defines(h_file, name, ns)	
	write_includes(h_file, ns)

#	g_var_idx = retriever.get_g_var_idx()
#	h_file.write("extern vec_idx_t {}[11];\n\n".format(g_var_idx))
	
	write_adm_template_documentation(h_file, namespace)
	
	write_agent_nickname_definitions(h_file, ns, nn)

	try:
		write_metadata_definitions(h_file, ns, retriever.get_metadata())

		write_edd_definitions(     h_file, ns, retriever.get_edds())
		write_variable_definitions(h_file, ns, retriever.get_variables())
		write_rpt_definitions(     h_file, ns, retriever.get_reports())
		write_tbl_definitions(     h_file, ns, retriever.get_tables())
		write_ctrl_definitions(    h_file, ns, retriever.get_controls())

		write_const_definitions(h_file, ns, retriever.get_constants())
		write_macro_definitions(h_file, ns, retriever.get_macros())
		write_op_definitions(   h_file, ns, retriever.get_operators())

		write_initialization_functions(h_file, ns)
		write_endifs(h_file, name, ns)
	except KeyError, e:
		return
	finally:
		h_file.close()


	print "\t\t[ DONE ]"	
	


