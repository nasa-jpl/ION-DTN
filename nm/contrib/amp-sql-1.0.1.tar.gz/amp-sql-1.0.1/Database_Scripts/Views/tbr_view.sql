
use amp_core;
CREATE OR REPLACE VIEW `vw_tbr_actual` AS
    SELECT 
        obj_metadata.obj_metadata_id,
        obj_name,
        namespace_id,
        obj_actual_definition_id,
        run_count, 
        start_time, 
        ac_id,
        use_desc
    FROM
        obj_metadata
            JOIN
        (SELECT 
            obj_actual_definition.obj_actual_definition_id,
                obj_metadata_id,
                use_desc,
                run_count, 
                start_time, 
                ac_id
        FROM
            obj_actual_definition
        JOIN tbr_actual_definition ON tbr_actual_definition.obj_actual_definition_id = obj_actual_definition.obj_actual_definition_id) join2 ON join2.obj_metadata_id = obj_metadata.obj_metadata_id;

 