#!/usr/bin/bash
rm -f core.*
rm -f bpacq.*
rm -f ion.log

ionadmin n2.ionrc
sleep 1
ionadmin contacts.ionrc
sleep 1
ionsecadmin n2.ionsecrc
sleep 1
bpadmin n2.bprc
sleep 1
